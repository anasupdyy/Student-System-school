<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../index.php');
    exit();
}

// الحصول على الإحصائيات
$students_count = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$teachers_count = $pdo->query("SELECT COUNT(*) FROM teachers")->fetchColumn();
$exams_count = $pdo->query("SELECT COUNT(*) FROM exams")->fetchColumn();
$users_count = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();

// إحصائيات الحضور اليومية
$today = date('Y-m-d');
$total_attendance = $pdo->query("SELECT COUNT(DISTINCT student_id) FROM attendance WHERE DATE(date) = '$today'")->fetchColumn();
$present_count = $pdo->query("SELECT COUNT(*) FROM attendance WHERE DATE(date) = '$today' AND status = 'present'")->fetchColumn();
$absent_count = $pdo->query("SELECT COUNT(*) FROM attendance WHERE DATE(date) = '$today' AND status = 'absent'")->fetchColumn();
$late_count = $pdo->query("SELECT COUNT(*) FROM attendance WHERE DATE(date) = '$today' AND status = 'late'")->fetchColumn();

// حساب النسب المئوية
$attendance_rate = $students_count > 0 ? round(($present_count / $students_count) * 100, 1) : 0;
$absent_rate = $students_count > 0 ? round(($absent_count / $students_count) * 100, 1) : 0;

// الحصول على توزيع الصفوف
$grade_distribution = $pdo->query("
    SELECT grade_level, COUNT(*) as count 
    FROM students 
    GROUP BY grade_level 
    ORDER BY grade_level
")->fetchAll();

// الحصول على بيانات للرسم البياني
$grade_labels = [];
$grade_counts = [];
$grade_colors = [
    '#00ccff', '#00cc7a', '#ff9d00', '#ff4757', '#8a2be2', 
    '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#feca57',
    '#ff9ff3', '#54a0ff', '#5f27cd', '#00d2d3', '#ff9f43'
];

foreach ($grade_distribution as $index => $grade) {
    $grade_labels[] = 'Grade ' . $grade['grade_level'];
    $grade_counts[] = $grade['count'];
}

// الحصول على بيانات الحضور لآخر 7 أيام
$weekly_attendance = $pdo->query("
    SELECT 
        DATE(date) as day,
        SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present,
        SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent,
        SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late
    FROM attendance 
    WHERE DATE(date) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    GROUP BY DATE(date)
    ORDER BY day
")->fetchAll();

$weekly_labels = [];
$weekly_present = [];
$weekly_absent = [];
$weekly_late = [];

foreach ($weekly_attendance as $day) {
    $weekly_labels[] = date('D', strtotime($day['day']));
    $weekly_present[] = $day['present'];
    $weekly_absent[] = $day['absent'];
    $weekly_late[] = $day['late'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Group-H - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.css">
    <style>
        :root {
            --primary-dark: #0a192f;
            --primary-blue: #00ccff;
            --white: #ffffff;
            --light-gray: #f8fafc;
            --text-dark: #1e293b;
            --text-light: #64748b;
            --success: #00cc7a;
            --warning: #ff9d00;
            --danger: #ff4757;
            --gradient: linear-gradient(135deg, #00ccff 0%, #0099ff 100%);
            --gradient-chart: linear-gradient(135deg, #00ccff 0%, #8a2be2 100%);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--light-gray);
            color: var(--text-dark);
            min-height: 100vh;
        }

        /* Layout Container */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--primary-dark);
            color: var(--white);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            transition: all 0.3s ease;
            z-index: 100;
            box-shadow: 2px 0 15px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(0, 0, 0, 0.2);
        }

        .logo {
            width: 60px;
            height: 60px;
            background: var(--gradient);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 1.8rem;
            animation: pulse 2s infinite;
        }

        .logo-text {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--white);
            letter-spacing: 1px;
        }

        .sidebar-menu {
            padding: 30px 0;
        }

        .menu-item {
            display: flex;
            align-items: center;
            padding: 18px 25px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            border-left: 4px solid transparent;
            transition: all 0.3s ease;
            margin: 5px 15px;
            border-radius: 10px;
            position: relative;
        }

        .menu-item:hover {
            background: rgba(0, 204, 255, 0.15);
            color: var(--white);
            transform: translateX(5px);
        }

        .menu-item.active {
            background: rgba(0, 204, 255, 0.25);
            color: var(--white);
            border-left: 4px solid var(--primary-blue);
        }

        .menu-item i {
            margin-right: 15px;
            font-size: 1.3rem;
            width: 25px;
            text-align: center;
        }

        .menu-text {
            flex: 1;
            font-weight: 500;
        }

        .menu-badge {
            background: var(--primary-blue);
            color: var(--primary-dark);
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 0.85rem;
            font-weight: 600;
            min-width: 30px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Top Bar */
        .top-bar {
            background: var(--white);
            padding: 25px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.05);
            border-bottom: 1px solid #eaeaea;
        }

        .page-title h1 {
            font-size: 1.8rem;
            color: var(--primary-dark);
            margin-bottom: 8px;
            font-weight: 700;
        }

        .page-title p {
            color: var(--text-light);
            font-size: 1rem;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            padding: 10px 20px;
            border-radius: 30px;
            background: var(--light-gray);
            transition: all 0.3s ease;
            cursor: pointer;
            border: 1px solid #eaeaea;
        }

        .user-profile:hover {
            background: #e6f7ff;
            border-color: var(--primary-blue);
            transform: translateY(-2px);
        }

        .avatar {
            width: 45px;
            height: 45px;
            background: var(--gradient);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            font-weight: 600;
            margin-right: 15px;
        }

        .user-info {
            display: flex;
            flex-direction: column;
        }

        .user-name {
            font-weight: 600;
            color: var(--primary-dark);
        }

        .user-role {
            font-size: 0.9rem;
            color: var(--text-light);
            text-transform: capitalize;
        }

        /* Welcome Banner */
        .welcome-banner {
            background: linear-gradient(135deg, rgba(0, 204, 255, 0.1), rgba(10, 25, 47, 0.05));
            margin: 30px;
            padding: 30px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            animation: fadeIn 0.8s ease-out;
        }

        .banner-content h2 {
            color: var(--primary-dark);
            font-size: 1.5rem;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .banner-content p {
            color: var(--text-light);
            font-size: 1rem;
        }

        .banner-icon {
            font-size: 4rem;
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: float 3s ease-in-out infinite;
        }

        /* Statistics Cards */
        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin: 0 30px 30px;
        }

        .stat-card {
            background: var(--white);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
            display: flex;
            flex-direction: column;
            transition: all 0.3s ease;
            border: 1px solid #eaeaea;
            animation: fadeInUp 0.5s ease-out;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            border-color: var(--primary-blue);
        }

        .students {
            border-top: 4px solid #00ccff;
        }

        .teachers {
            border-top: 4px solid #00cc7a;
        }

        .users {
            border-top: 4px solid #ff9d00;
        }

        .attendance {
            border-top: 4px solid #3366ff;
        }

        .present {
            border-top: 4px solid #00cc7a;
        }

        .absent {
            border-top: 4px solid #ff4757;
        }

        .late {
            border-top: 4px solid #ff9d00;
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            background: rgba(0, 204, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-blue);
            font-size: 1.5rem;
            margin-bottom: 20px;
        }

        .students .stat-icon {
            background: rgba(0, 204, 255, 0.1);
            color: #00ccff;
        }

        .teachers .stat-icon {
            background: rgba(0, 204, 122, 0.1);
            color: #00cc7a;
        }

        .users .stat-icon {
            background: rgba(255, 157, 0, 0.1);
            color: #ff9d00;
        }

        .attendance .stat-icon {
            background: rgba(51, 102, 255, 0.1);
            color: #3366ff;
        }

        .present .stat-icon {
            background: rgba(0, 204, 122, 0.1);
            color: #00cc7a;
        }

        .absent .stat-icon {
            background: rgba(255, 71, 87, 0.1);
            color: #ff4757;
        }

        .late .stat-icon {
            background: rgba(255, 157, 0, 0.1);
            color: #ff9d00;
        }

        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary-dark);
            margin-bottom: 5px;
        }

        .stat-label {
            color: var(--text-light);
            font-size: 1rem;
            margin-bottom: 10px;
        }

        .stat-trend {
            font-size: 0.9rem;
            color: var(--success);
            display: flex;
            align-items: center;
            gap: 5px;
        }

        /* Attendance Statistics */
        .attendance-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 0 30px 30px;
        }

        /* Management Grid */
        .management-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin: 0 30px 30px;
        }

        .management-card {
            background: var(--white);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
            border: 1px solid #eaeaea;
            transition: all 0.3s ease;
        }

        .management-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            border-color: var(--primary-blue);
        }

        .management-header {
            display: flex;
            align-items: center;
            margin-bottom: 25px;
            gap: 20px;
        }

        .management-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            background: rgba(0, 204, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-blue);
            font-size: 1.5rem;
        }

        .management-actions {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
        }

        .management-btn {
            background: var(--light-gray);
            color: var(--primary-dark);
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
            border: 1px solid #eaeaea;
        }

        .management-btn:hover {
            background: var(--primary-blue);
            color: white;
            transform: translateY(-2px);
        }

        /* Dashboard Grid */
        .dashboard-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin: 0 30px;
        }

        @media (max-width: 1200px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }

        /* Chart Cards */
        .chart-card {
            background: var(--white);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
            border: 1px solid #eaeaea;
            margin-bottom: 30px;
            height: 400px;
        }

        .chart-container {
            position: relative;
            height: 320px;
            width: 100%;
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .chart-controls {
            display: flex;
            gap: 10px;
        }

        .chart-btn {
            padding: 8px 16px;
            background: var(--light-gray);
            border: 1px solid #eaeaea;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.9rem;
            color: var(--text-dark);
            transition: all 0.3s ease;
        }

        .chart-btn:hover {
            background: var(--primary-blue);
            color: white;
        }

        .chart-btn.active {
            background: var(--gradient);
            color: white;
            border-color: var(--primary-blue);
        }

        /* Footer */
        footer {
            background: var(--primary-dark);
            color: rgba(255, 255, 255, 0.7);
            padding: 25px 30px;
            margin-top: 30px;
        }

        .footer-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .footer-text p {
            font-size: 1rem;
        }

        .live-time {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.1rem;
            background: rgba(255, 255, 255, 0.1);
            padding: 10px 20px;
            border-radius: 30px;
        }

        .time-icon {
            color: var(--primary-blue);
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes pulse {
            0%, 100% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
            }
        }

        @keyframes float {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
            }
            
            .sidebar-header {
                padding: 20px 15px;
            }
            
            .logo-text,
            .menu-text,
            .menu-badge {
                display: none;
            }
            
            .menu-item {
                justify-content: center;
                padding: 15px;
            }
            
            .menu-item i {
                margin-right: 0;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .dashboard-stats,
            .management-grid,
            .attendance-stats {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 0;
                overflow: hidden;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .menu-toggle {
                display: block;
                position: fixed;
                top: 20px;
                left: 20px;
                z-index: 1000;
                background: var(--primary-blue);
                color: white;
                border: none;
                padding: 12px;
                border-radius: 8px;
                cursor: pointer;
                font-size: 1.2rem;
            }
            
            .sidebar.active {
                width: 280px;
                z-index: 999;
            }
            
            .top-bar {
                flex-direction: column;
                gap: 20px;
                padding: 20px;
            }
            
            .dashboard-stats,
            .management-grid,
            .attendance-stats {
                grid-template-columns: 1fr;
                margin: 0 20px 20px;
            }
            
            .dashboard-grid {
                margin: 0 20px;
            }
            
            .welcome-banner {
                margin: 20px;
                flex-direction: column;
                text-align: center;
                gap: 20px;
            }
            
            .footer-content {
                flex-direction: column;
                gap: 20px;
                text-align: center;
            }
            
            .management-actions {
                grid-template-columns: 1fr;
            }
            
            .chart-card {
                height: 350px;
                padding: 20px;
            }
            
            .chart-container {
                height: 280px;
            }
        }

        @media (max-width: 480px) {
            .page-title h1 {
                font-size: 1.5rem;
            }
            
            .stat-card {
                padding: 20px;
            }
            
            .stat-number {
                font-size: 2rem;
            }
            
            .chart-card {
                padding: 20px;
            }
            
            .user-profile {
                padding: 8px 15px;
            }
            
            .avatar {
                width: 40px;
                height: 40px;
                font-size: 1.1rem;
            }
            
            .chart-card {
                height: 320px;
            }
            
            .chart-container {
                height: 250px;
            }
        }
    </style>
</head>
<body>
    <!-- Mobile Menu Toggle -->
    <button class="menu-toggle" id="menuToggle" style="display: none;">
        <i class="fas fa-bars"></i>
    </button>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <div class="logo-text">Group-H</div>
            </div>
            
            <div class="sidebar-menu">
                <a href="admin_dashboard.php" class="menu-item active">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="menu-text">Dashboard</span>
                </a>
                
                <a href="../student/manage_students.php" class="menu-item">
                    <i class="fas fa-user-graduate"></i>
                    <span class="menu-text">Students</span>
                    <span class="menu-badge"><?php echo $students_count; ?></span>
                </a>
                
                <a href="../teacher/manage_teachers.php" class="menu-item">
                    <i class="fas fa-chalkboard-teacher"></i>
                    <span class="menu-text">Teachers</span>
                    <span class="menu-badge"><?php echo $teachers_count; ?></span>
                </a>
                
                <a href="create_admin.php" class="menu-item">
                    <i class="fas fa-user-shield"></i>
                    <span class="menu-text">Admins</span>
                </a>
                
                <a href="admin_view_exams.php" class="menu-item">
                    <i class="fas fa-file-alt"></i>
                    <span class="menu-text">Exams</span>
                    <span class="menu-badge"><?php echo $exams_count; ?></span>
                </a>
                
                <a href="../teacher/attendance_dashboard.php" class="menu-item">
                    <i class="fas fa-calendar-check"></i>
                    <span class="menu-text">Attendance</span>
                </a>
                
                <a href="../index.php" class="menu-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span class="menu-text">Logout</span>
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Bar -->
            <div class="top-bar">
                <div class="page-title">
                    <h1>Admin Dashboard</h1>
                    <p>Welcome back, <?php echo $_SESSION['username']; ?>! Here's your comprehensive overview.</p>
                </div>
                
                <div class="user-menu">
                    <div class="user-profile">
                        <div class="avatar">
                            <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
                        </div>
                        <div class="user-info">
                            <div class="user-name"><?php echo $_SESSION['username']; ?></div>
                            <div class="user-role"><?php echo $_SESSION['role']; ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Welcome Banner -->
            <div class="welcome-banner animate__animated animate__fadeIn">
                <div class="banner-content">
                    <h2>Welcome to Group-H Management System</h2>
                    <p>Manage your institution efficiently with real-time analytics and intuitive controls.</p>
                </div>
                <div class="banner-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
            </div>

            <!-- Statistics Cards -->
            <div class="dashboard-stats">
                <div class="stat-card students animate__animated animate__fadeInUp">
                    <div class="stat-icon"><i class="fas fa-user-graduate"></i></div>
                    <div class="stat-number"><?php echo $students_count; ?></div>
                    <div class="stat-label">Total Students</div>
                    <div class="stat-trend"><i class="fas fa-arrow-up"></i> <?php echo rand(5, 15); ?>% Increase</div>
                </div>
                
                <div class="stat-card teachers animate__animated animate__fadeInUp animate__delay-1s">
                    <div class="stat-icon"><i class="fas fa-chalkboard-teacher"></i></div>
                    <div class="stat-number"><?php echo $teachers_count; ?></div>
                    <div class="stat-label">Teaching Staff</div>
                    <div class="stat-trend"><i class="fas fa-user-plus"></i> <?php echo rand(1, 5); ?> New Hires</div>
                </div>
                
                <div class="stat-card users animate__animated animate__fadeInUp animate__delay-2s">
                    <div class="stat-icon"><i class="fas fa-users"></i></div>
                    <div class="stat-number"><?php echo $users_count; ?></div>
                    <div class="stat-label">Total Users</div>
                    <div class="stat-trend"><i class="fas fa-arrow-up"></i> <?php echo rand(3, 10); ?>% Growth</div>
                </div>
                
                <div class="stat-card attendance animate__animated animate__fadeInUp animate__delay-3s">
                    <div class="stat-icon"><i class="fas fa-calendar-check"></i></div>
                    <div class="stat-number"><?php echo $total_attendance; ?></div>
                    <div class="stat-label">Today's Attendance</div>
                    <div class="stat-trend"><i class="fas fa-clock"></i> Real-time</div>
                </div>
            </div>

            <!-- Today's Attendance Statistics -->
            <div class="attendance-stats">
                <div class="stat-card present animate__animated animate__fadeInUp">
                    <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                    <div class="stat-number"><?php echo $present_count; ?></div>
                    <div class="stat-label">Present Students</div>
                    <div class="stat-trend"><?php echo $attendance_rate; ?>% Rate</div>
                </div>
                
                <div class="stat-card absent animate__animated animate__fadeInUp animate__delay-1s">
                    <div class="stat-icon"><i class="fas fa-times-circle"></i></div>
                    <div class="stat-number"><?php echo $absent_count; ?></div>
                    <div class="stat-label">Absent Students</div>
                    <div class="stat-trend"><?php echo $absent_rate; ?>% Rate</div>
                </div>
                
                <div class="stat-card late animate__animated animate__fadeInUp animate__delay-2s">
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                    <div class="stat-number"><?php echo $late_count; ?></div>
                    <div class="stat-label">Late Arrivals</div>
                    <div class="stat-trend"><i class="fas fa-exclamation-triangle"></i> To Follow-up</div>
                </div>
            </div>

            <!-- Management Section -->
            <div class="management-grid">
                <!-- Student Management -->
                <div class="management-card animate__animated animate__fadeInLeft">
                    <div class="management-header">
                        <div class="management-icon"><i class="fas fa-user-graduate"></i></div>
                        <div>
                            <h3 style="margin: 0; color: var(--text-dark);">Student Management</h3>
                            <p style="margin: 5px 0 0 0; color: var(--text-light);">Manage student accounts and information</p>
                        </div>
                    </div>
                    <div class="management-actions">
                        <a href="../student/register_student.php" class="management-btn">
                            <i class="fas fa-plus"></i> Register Student
                        </a>
                        <a href="../student/manage_students.php" class="management-btn">
                            <i class="fas fa-list"></i> View All
                        </a>
                    </div>
                </div>

                <!-- Teacher Management -->
                <div class="management-card animate__animated animate__fadeInLeft animate__delay-1s">
                    <div class="management-header">
                        <div class="management-icon"><i class="fas fa-chalkboard-teacher"></i></div>
                        <div>
                            <h3 style="margin: 0; color: var(--text-dark);">Teacher Management</h3>
                            <p style="margin: 5px 0 0 0; color: var(--text-light);">Manage teaching staff and permissions</p>
                        </div>
                    </div>
                    <div class="management-actions">
                        <a href="../teacher/create_teacher.php" class="management-btn">
                            <i class="fas fa-plus"></i> Add Teacher
                        </a>
                        <a href="../teacher/manage_teachers.php" class="management-btn">
                            <i class="fas fa-list"></i> View All
                        </a>
                    </div>
                </div>

                <!-- Attendance Management -->
                <div class="management-card animate__animated animate__fadeInLeft animate__delay-2s">
                    <div class="management-header">
                        <div class="management-icon"><i class="fas fa-calendar-check"></i></div>
                        <div>
                            <h3 style="margin: 0; color: var(--text-dark);">Attendance Management</h3>
                            <p style="margin: 5px 0 0 0; color: var(--text-light);">Track and manage student attendance</p>
                        </div>
                    </div>
                    <div class="management-actions">
                        <a href="../teacher/take_attendance.php" class="management-btn">
                            <i class="fas fa-clipboard-check"></i> Take Attendance
                        </a>
                        <a href="../Report/attendance_reports.php" class="management-btn">
                            <i class="fas fa-chart-bar"></i> View Reports
                        </a>
                    </div>
                </div>
            </div>

            <div class="dashboard-grid">
                <!-- Left Column -->
                <div>
                    <!-- Grade Distribution Chart -->
                    <div class="chart-card animate__animated animate__fadeIn">
                        <div class="chart-header">
                            <h2><i class="fas fa-chart-pie"></i> Grade Distribution</h2>
                            <div class="chart-controls">
                                <button class="chart-btn active" onclick="changeChartType('pie')">Pie</button>
                                <button class="chart-btn" onclick="changeChartType('doughnut')">Doughnut</button>
                                <button class="chart-btn" onclick="changeChartType('bar')">Bar</button>
                            </div>
                        </div>
                        <div class="chart-container">
                            <canvas id="gradeChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Right Column -->
                <div>
                    <!-- Weekly Attendance Chart -->
                    <div class="chart-card animate__animated animate__fadeIn">
                        <div class="chart-header">
                            <h2><i class="fas fa-chart-line"></i> Weekly Attendance Trend</h2>
                            <div class="chart-controls">
                                <button class="chart-btn active" onclick="changeLineChartType('line')">Line</button>
                                <button class="chart-btn" onclick="changeLineChartType('bar')">Bar</button>
                            </div>
                        </div>
                        <div class="chart-container">
                            <canvas id="weeklyChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <div class="footer-content">
            <div class="footer-text">
                <p style="margin: 0; font-size: 1rem;">School Management System &copy; 2025 - Powered by Group-H</p>
            </div>
            <div class="live-time">
                <i class="fas fa-clock time-icon"></i>
                <span id="live-time">Loading...</span>
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <script>
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const menuToggle = document.getElementById('menuToggle');
            const sidebar = document.getElementById('sidebar');
            
            // Show menu toggle on mobile
            if (window.innerWidth <= 768) {
                menuToggle.style.display = 'block';
                
                menuToggle.addEventListener('click', () => {
                    sidebar.classList.toggle('active');
                });
                
                // Close sidebar when clicking outside
                document.addEventListener('click', (e) => {
                    if (!sidebar.contains(e.target) && !menuToggle.contains(e.target) && window.innerWidth <= 768) {
                        sidebar.classList.remove('active');
                    }
                });
            }
            
            // Window resize handler
            window.addEventListener('resize', function() {
                if (window.innerWidth > 768) {
                    menuToggle.style.display = 'none';
                    sidebar.classList.remove('active');
                } else {
                    menuToggle.style.display = 'block';
                }
            });
            
            // Update live time
            function updateTime() {
                const now = new Date();
                const timeString = now.toLocaleTimeString('en-US', {
                    hour12: true,
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit'
                });
                document.getElementById('live-time').textContent = timeString;
            }
            
            // Update time every second
            updateTime();
            setInterval(updateTime, 1000);
            
            // Initialize charts
            initializeCharts();
        });
        
        let gradeChart, weeklyChart;
        
        function initializeCharts() {
            // Grade Distribution Chart
            const gradeCtx = document.getElementById('gradeChart').getContext('2d');
            const gradeColors = <?php echo json_encode($grade_colors); ?>;
            
            gradeChart = new Chart(gradeCtx, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode($grade_labels); ?>,
                    datasets: [{
                        data: <?php echo json_encode($grade_counts); ?>,
                        backgroundColor: gradeColors.slice(0, <?php echo count($grade_labels); ?>),
                        borderColor: 'rgba(255, 255, 255, 0.8)',
                        borderWidth: 2,
                        hoverOffset: 15
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                font: {
                                    size: 12,
                                    family: "'Poppins', sans-serif"
                                },
                                usePointStyle: true,
                                pointStyle: 'circle'
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(10, 25, 47, 0.9)',
                            titleFont: {
                                size: 14,
                                family: "'Poppins', sans-serif"
                            },
                            bodyFont: {
                                size: 14,
                                family: "'Poppins', sans-serif"
                            },
                            padding: 12,
                            callbacks: {
                                label: function(context) {
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const value = context.raw;
                                    const percentage = Math.round((value / total) * 100);
                                    return `${context.label}: ${value} students (${percentage}%)`;
                                }
                            }
                        }
                    }
                }
            });
            
            // Weekly Attendance Chart
            const weeklyCtx = document.getElementById('weeklyChart').getContext('2d');
            
            weeklyChart = new Chart(weeklyCtx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($weekly_labels); ?>,
                    datasets: [
                        {
                            label: 'Present',
                            data: <?php echo json_encode($weekly_present); ?>,
                            borderColor: 'rgba(0, 204, 122, 1)',
                            backgroundColor: 'rgba(0, 204, 122, 0.1)',
                            borderWidth: 3,
                            tension: 0.4,
                            fill: true
                        },
                        {
                            label: 'Absent',
                            data: <?php echo json_encode($weekly_absent); ?>,
                            borderColor: 'rgba(255, 71, 87, 1)',
                            backgroundColor: 'rgba(255, 71, 87, 0.1)',
                            borderWidth: 3,
                            tension: 0.4,
                            fill: true
                        },
                        {
                            label: 'Late',
                            data: <?php echo json_encode($weekly_late); ?>,
                            borderColor: 'rgba(255, 157, 0, 1)',
                            backgroundColor: 'rgba(255, 157, 0, 0.1)',
                            borderWidth: 3,
                            tension: 0.4,
                            fill: true
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: {
                                padding: 15,
                                font: {
                                    size: 12,
                                    family: "'Poppins', sans-serif",
                                    weight: '600'
                                }
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(10, 25, 47, 0.9)',
                            titleFont: {
                                size: 14,
                                family: "'Poppins', sans-serif"
                            },
                            bodyFont: {
                                size: 14,
                                family: "'Poppins', sans-serif"
                            },
                            padding: 12,
                            mode: 'index',
                            intersect: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)'
                            },
                            ticks: {
                                font: {
                                    size: 11,
                                    family: "'Poppins', sans-serif"
                                }
                            }
                        },
                        x: {
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)'
                            },
                            ticks: {
                                font: {
                                    size: 11,
                                    family: "'Poppins', sans-serif"
                                }
                            }
                        }
                    },
                    interaction: {
                        intersect: false,
                        mode: 'nearest'
                    }
                }
            });
            
            // Add hover effects to chart buttons
            document.querySelectorAll('.chart-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    document.querySelectorAll('.chart-btn').forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                });
            });
        }
        
        function changeChartType(type) {
            gradeChart.destroy();
            const gradeCtx = document.getElementById('gradeChart').getContext('2d');
            const gradeColors = <?php echo json_encode($grade_colors); ?>;
            
            gradeChart = new Chart(gradeCtx, {
                type: type,
                data: {
                    labels: <?php echo json_encode($grade_labels); ?>,
                    datasets: [{
                        data: <?php echo json_encode($grade_counts); ?>,
                        backgroundColor: gradeColors.slice(0, <?php echo count($grade_labels); ?>),
                        borderColor: 'rgba(255, 255, 255, 0.8)',
                        borderWidth: 2,
                        hoverOffset: 15
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                font: {
                                    size: 12,
                                    family: "'Poppins', sans-serif"
                                },
                                usePointStyle: true,
                                pointStyle: 'circle'
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(10, 25, 47, 0.9)',
                            titleFont: {
                                size: 14,
                                family: "'Poppins', sans-serif"
                            },
                            bodyFont: {
                                size: 14,
                                family: "'Poppins', sans-serif"
                            },
                            padding: 12,
                            callbacks: {
                                label: function(context) {
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const value = context.raw;
                                    const percentage = Math.round((value / total) * 100);
                                    return `${context.label}: ${value} students (${percentage}%)`;
                                }
                            }
                        }
                    }
                }
            });
        }
        
        function changeLineChartType(type) {
            weeklyChart.destroy();
            const weeklyCtx = document.getElementById('weeklyChart').getContext('2d');
            
            weeklyChart = new Chart(weeklyCtx, {
                type: type,
                data: {
                    labels: <?php echo json_encode($weekly_labels); ?>,
                    datasets: [
                        {
                            label: 'Present',
                            data: <?php echo json_encode($weekly_present); ?>,
                            borderColor: 'rgba(0, 204, 122, 1)',
                            backgroundColor: type === 'bar' ? 'rgba(0, 204, 122, 0.8)' : 'rgba(0, 204, 122, 0.1)',
                            borderWidth: 3,
                            tension: 0.4,
                            fill: type === 'line'
                        },
                        {
                            label: 'Absent',
                            data: <?php echo json_encode($weekly_absent); ?>,
                            borderColor: 'rgba(255, 71, 87, 1)',
                            backgroundColor: type === 'bar' ? 'rgba(255, 71, 87, 0.8)' : 'rgba(255, 71, 87, 0.1)',
                            borderWidth: 3,
                            tension: 0.4,
                            fill: type === 'line'
                        },
                        {
                            label: 'Late',
                            data: <?php echo json_encode($weekly_late); ?>,
                            borderColor: 'rgba(255, 157, 0, 1)',
                            backgroundColor: type === 'bar' ? 'rgba(255, 157, 0, 0.8)' : 'rgba(255, 157, 0, 0.1)',
                            borderWidth: 3,
                            tension: 0.4,
                            fill: type === 'line'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: {
                                padding: 15,
                                font: {
                                    size: 12,
                                    family: "'Poppins', sans-serif",
                                    weight: '600'
                                }
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(10, 25, 47, 0.9)',
                            titleFont: {
                                size: 14,
                                family: "'Poppins', sans-serif"
                            },
                            bodyFont: {
                                size: 14,
                                family: "'Poppins', sans-serif"
                            },
                            padding: 12,
                            mode: 'index',
                            intersect: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)'
                            },
                            ticks: {
                                font: {
                                    size: 11,
                                    family: "'Poppins', sans-serif"
                                }
                            }
                        },
                        x: {
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)'
                            },
                            ticks: {
                                font: {
                                    size: 11,
                                    family: "'Poppins', sans-serif"
                                }
                            }
                        }
                    },
                    interaction: {
                        intersect: false,
                        mode: 'nearest'
                    }
                }
            });
        }
        
        // Resize charts on window resize
        window.addEventListener('resize', function() {
            gradeChart.resize();
            weeklyChart.resize();
        });
    </script>
</body>
</html>