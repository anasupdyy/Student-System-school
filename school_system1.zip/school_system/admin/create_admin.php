<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = $_POST['email'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];

    try {
        $stmt = $pdo->prepare("INSERT INTO users (username, password, email, role, first_name, last_name) VALUES (?, ?, ?, 'admin', ?, ?)");
        $stmt->execute([$username, $password, $email, $first_name, $last_name]);
        
        $_SESSION['success'] = "✅ Admin account created successfully!<br>
                               <strong>Username:</strong> $username<br>
                               <strong>Email:</strong> $email<br>
                               <strong>Role:</strong> Administrator";
        header('Location: create_admin.php');
        exit();
    } catch (Exception $e) {
        $error = "❌ Error creating admin account: " . $e->getMessage();
    }
}

// Get existing admins
$admins = $pdo->query("SELECT * FROM users WHERE role = 'admin' ORDER BY created_at DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Admin Account | EduFlow Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-dark: #0a192f;
            --primary-blue: #00ccff;
            --white: #ffffff;
            --light-gray: #f8fafc;
            --text-dark: #1e293b;
            --text-light: #64748b;
            --success: #00cc7a;
            --warning: #ff9d00;
            --danger: #ff4757;
            --gradient: linear-gradient(135deg, #00ccff 0%, #0099ff 100%);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--light-gray);
            color: var(--text-dark);
            min-height: 100vh;
        }

        /* Layout Container */
        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--primary-dark);
            color: var(--white);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            transition: all 0.3s ease;
            z-index: 100;
            box-shadow: 2px 0 15px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(0, 0, 0, 0.2);
        }

        .sidebar-header h3 {
            font-size: 1.6rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            color: var(--white);
            font-weight: 700;
        }

        .sidebar-header h3 i {
            color: var(--primary-blue);
            font-size: 1.8rem;
        }

        .sidebar-header p {
            color: var(--primary-blue);
            font-size: 0.9rem;
            opacity: 0.8;
            margin-top: 8px;
        }

        .sidebar-menu {
            padding: 30px 0;
        }

        .sidebar-menu ul {
            list-style: none;
        }

        .sidebar-menu li {
            margin: 5px 20px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 18px 20px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            border-left: 4px solid transparent;
            transition: all 0.3s ease;
            border-radius: 10px;
            font-weight: 500;
        }

        .sidebar-menu a:hover {
            background: rgba(0, 204, 255, 0.15);
            color: var(--white);
            transform: translateX(5px);
        }

        .sidebar-menu a.active {
            background: rgba(0, 204, 255, 0.25);
            color: var(--white);
            border-left: 4px solid var(--primary-blue);
        }

        .sidebar-menu a i {
            margin-right: 15px;
            width: 25px;
            text-align: center;
            font-size: 1.3rem;
        }

        .sidebar-menu a.active i {
            color: var(--primary-blue);
        }

        .sidebar-footer {
            position: absolute;
            bottom: 0;
            width: 100%;
            padding: 20px;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            font-size: 0.9rem;
            color: rgba(255, 255, 255, 0.6);
            background: rgba(0, 0, 0, 0.2);
        }

        .sidebar-footer i {
            color: var(--primary-blue);
            margin-right: 8px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            animation: fadeIn 0.8s ease-out;
        }

        /* Header */
        .header {
            background: var(--white);
            padding: 25px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.05);
            border-bottom: 1px solid #eaeaea;
        }

        .header-title h1 {
            font-size: 1.8rem;
            color: var(--primary-dark);
            display: flex;
            align-items: center;
            gap: 15px;
            font-weight: 700;
        }

        .header-title h1 i {
            color: var(--primary-blue);
            font-size: 2rem;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            padding: 12px 22px;
            border-radius: 30px;
            background: var(--light-gray);
            transition: all 0.3s ease;
            cursor: pointer;
            border: 1px solid #eaeaea;
        }

        .user-profile:hover {
            background: #e6f7ff;
            border-color: var(--primary-blue);
            transform: translateY(-2px);
        }

        .user-profile img {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            margin-right: 15px;
            border: 2px solid var(--primary-blue);
        }

        .user-profile span {
            font-weight: 600;
            color: var(--primary-dark);
        }

        /* Content Area */
        .content {
            flex: 1;
            padding: 30px;
            background: var(--light-gray);
        }

        /* Welcome Banner */
        .welcome-banner {
            background: linear-gradient(135deg, rgba(0, 204, 255, 0.1), rgba(10, 25, 47, 0.05));
            margin-bottom: 30px;
            padding: 25px 30px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            animation: fadeIn 0.8s ease-out;
            border: 1px solid rgba(0, 204, 255, 0.2);
        }

        .banner-content h2 {
            color: var(--primary-dark);
            font-size: 1.5rem;
            margin-bottom: 8px;
            font-weight: 600;
        }

        .banner-content p {
            color: var(--text-light);
            font-size: 1rem;
        }

        .banner-icon {
            font-size: 3.5rem;
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: float 3s ease-in-out infinite;
        }

        /* Two Column Layout */
        .two-column {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }

        /* Registration Card */
        .registration-card {
            background: var(--white);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.05);
            border: 1px solid #eaeaea;
            animation: fadeInLeft 0.8s ease-out;
        }

        .registration-card h2 {
            color: var(--primary-dark);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 600;
        }

        .registration-card p {
            color: var(--text-light);
            margin-bottom: 25px;
            font-size: 1rem;
        }

        /* Alerts */
        .alert {
            padding: 20px 25px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 15px;
            animation: slideInRight 0.5s ease-out;
        }

        .alert-success {
            background: rgba(0, 204, 122, 0.1);
            border-left: 4px solid var(--success);
            color: #006644;
        }

        .alert-danger {
            background: rgba(255, 71, 87, 0.1);
            border-left: 4px solid var(--danger);
            color: #cc3342;
        }

        .alert i {
            font-size: 1.3rem;
        }

        .alert-success i {
            color: var(--success);
        }

        .alert-danger i {
            color: var(--danger);
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            color: var(--primary-dark);
            font-weight: 600;
            font-size: 1rem;
        }

        .form-control {
            width: 100%;
            padding: 15px 20px;
            border-radius: 10px;
            border: 2px solid #eaeaea;
            font-size: 1rem;
            background: var(--white);
            transition: all 0.3s ease;
            color: var(--text-dark);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(0, 204, 255, 0.15);
        }

        /* Admin List Card */
        .admin-list-card {
            background: var(--white);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.05);
            border: 1px solid #eaeaea;
            animation: fadeInRight 0.8s ease-out;
        }

        .admin-list-card h2 {
            color: var(--primary-dark);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 600;
        }

        /* Table */
        .table-container {
            overflow-x: auto;
        }

        .table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            font-size: 1rem;
        }

        .table thead {
            background: linear-gradient(to right, rgba(0, 204, 255, 0.1), rgba(10, 25, 47, 0.1));
        }

        .table th {
            padding: 18px 20px;
            text-align: left;
            font-weight: 600;
            color: var(--primary-dark);
            border-bottom: 2px solid #eaeaea;
            white-space: nowrap;
        }

        .table td {
            padding: 18px 20px;
            border-bottom: 1px solid #eaeaea;
            color: var(--text-dark);
            vertical-align: middle;
        }

        .table tbody tr {
            transition: all 0.3s ease;
        }

        .table tbody tr:hover {
            background: rgba(0, 204, 255, 0.05);
            transform: translateX(5px);
        }

        .admin-badge {
            background: rgba(0, 153, 255, 0.1);
            color: #0066cc;
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border: 1px solid rgba(0, 153, 255, 0.2);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 50px 20px;
        }

        .empty-state i {
            font-size: 3.5rem;
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 20px;
            display: inline-block;
            animation: pulse 2s infinite;
        }

        .empty-state h3 {
            color: var(--primary-dark);
            margin-bottom: 10px;
            font-size: 1.5rem;
            font-weight: 600;
        }

        .empty-state p {
            color: var(--text-light);
            margin-bottom: 25px;
            max-width: 350px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.6;
        }

        /* Buttons */
        .btn {
            padding: 14px 28px;
            border-radius: 10px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            text-decoration: none;
            font-size: 1rem;
            gap: 12px;
        }

        .btn-primary {
            background: var(--gradient);
            color: var(--white);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 204, 255, 0.3);
        }

        .btn-secondary {
            background: var(--light-gray);
            color: var(--text-dark);
            border: 1px solid #eaeaea;
        }

        .btn-secondary:hover {
            background: #e6f7ff;
            border-color: var(--primary-blue);
            transform: translateY(-3px);
        }

        /* Footer */
        .footer {
            background: var(--primary-dark);
            padding: 25px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.95rem;
        }

        .footer-links {
            display: flex;
            gap: 25px;
        }

        .footer-links a {
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            transition: color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
        }

        .footer-links a:hover {
            color: var(--primary-blue);
            transform: translateY(-2px);
        }

        .footer-links a i {
            font-size: 1.1rem;
        }

        .footer-copyright {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .footer-copyright i {
            color: var(--danger);
            animation: heartbeat 1.5s infinite;
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInLeft {
            from {
                opacity: 0;
                transform: translateX(-30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes fadeInRight {
            from {
                opacity: 0;
                transform: translateX(30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes float {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-8px);
            }
        }

        @keyframes pulse {
            0%, 100% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
            }
        }

        @keyframes heartbeat {
            0%, 100% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.2);
            }
        }

        /* Responsive Styles */
        @media (max-width: 1200px) {
            .sidebar {
                width: 80px;
            }
            
            .sidebar-header h3 span,
            .sidebar-header p,
            .sidebar-menu a span,
            .sidebar-footer span {
                display: none;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .sidebar:hover {
                width: 280px;
            }
            
            .sidebar:hover .sidebar-header h3 span,
            .sidebar:hover .sidebar-header p,
            .sidebar:hover .sidebar-menu a span,
            .sidebar:hover .sidebar-footer span {
                display: inline;
            }
        }

        @media (max-width: 992px) {
            .two-column {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 20px;
                padding: 20px;
            }
            
            .content {
                padding: 20px;
            }
            
            .welcome-banner {
                flex-direction: column;
                text-align: center;
                gap: 20px;
                padding: 20px;
            }
            
            .registration-card,
            .admin-list-card {
                padding: 25px;
            }
            
            .footer {
                flex-direction: column;
                text-align: center;
                gap: 20px;
                padding: 20px;
            }
            
            .footer-links {
                flex-wrap: wrap;
                justify-content: center;
                gap: 15px;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
                margin-bottom: 10px;
            }
        }

        @media (max-width: 480px) {
            .sidebar {
                width: 0;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .sidebar.active {
                width: 280px;
                z-index: 1000;
            }
            
            .menu-toggle {
                display: block;
                position: fixed;
                top: 20px;
                left: 20px;
                z-index: 1001;
                background: var(--primary-blue);
                color: white;
                border: none;
                padding: 12px;
                border-radius: 8px;
                cursor: pointer;
                font-size: 1.2rem;
            }
            
            .header-title h1 {
                font-size: 1.4rem;
            }
        }
    </style>
</head>
<body>
    <!-- Mobile Menu Toggle -->
    <button class="menu-toggle" id="menuToggle" style="display: none;">
        <i class="fas fa-bars"></i>
    </button>

    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h3><i class="fas fa-user-shield"></i> <span>EduFlow</span></h3>
                <p><span>Admin Management</span></p>
            </div>
            
            <div class="sidebar-menu">
                <ul>
                    <li>
                        <a href="admin_dashboard.php">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="../student/manage_students.php">
                            <i class="fas fa-user-graduate"></i>
                            <span>Students</span>
                        </a>
                    </li>
                    <li>
                        <a href="../teacher/manage_teachers.php">
                            <i class="fas fa-chalkboard-teacher"></i>
                            <span>Teachers</span>
                        </a>
                    </li>
                    <li>
                        <a href="create_admin.php" class="active">
                            <i class="fas fa-user-plus"></i>
                            <span>Create Admin</span>
                        </a>
                    </li>
                    <li>
                        <a href="../index.php">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
            
            <div class="sidebar-footer">
                <p><i class="fas fa-code"></i> <span>EduFlow v1.0</span></p>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <div class="header-title">
                    <h1><i class="fas fa-user-plus"></i> Create Admin Account</h1>
                </div>
                
                <div class="header-actions">
                    <div class="user-profile">
                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['username']); ?>&background=00ccff&color=fff&size=128" alt="Admin">
                        <span><?php echo $_SESSION['username']; ?></span>
                    </div>
                </div>
            </div>

            <!-- Content -->
            <div class="content">
                <!-- Welcome Banner -->
                <div class="welcome-banner">
                    <div class="banner-content">
                        <h2>Create New Administrator</h2>
                        <p>Fill in the administrator's information below to create their account with full system access.</p>
                    </div>
                    <div class="banner-icon">
                        <i class="fas fa-user-shield"></i>
                    </div>
                </div>

                <!-- Two Column Layout -->
                <div class="two-column">
                    <!-- Registration Form -->
                    <div class="registration-card">
                        <h2><i class="fas fa-user-plus"></i> Admin Information</h2>
                        <p>Enter the administrator's details to create their account</p>

                        <?php if (isset($_SESSION['success'])): ?>
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle"></i> 
                                <span><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></span>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger">
                                <i class="fas fa-exclamation-circle"></i> 
                                <span><?php echo $error; ?></span>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="">
                            <div class="form-group">
                                <label for="first_name">First Name</label>
                                <input type="text" id="first_name" name="first_name" class="form-control" required 
                                       placeholder="Enter first name">
                            </div>

                            <div class="form-group">
                                <label for="last_name">Last Name</label>
                                <input type="text" id="last_name" name="last_name" class="form-control" required 
                                       placeholder="Enter last name">
                            </div>

                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" id="username" name="username" class="form-control" required 
                                       placeholder="Choose a username">
                            </div>

                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" id="password" name="password" class="form-control" required 
                                       placeholder="Set a strong password">
                            </div>

                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" id="email" name="email" class="form-control" required 
                                       placeholder="admin@school.com">
                            </div>

                            <div style="display: flex; gap: 15px; margin-top: 30px;">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-user-plus"></i> Create Admin Account
                                </button>
                                
                                <a href="admin_dashboard.php" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                            </div>
                        </form>
                    </div>

                    <!-- Admin List -->
                    <div class="admin-list-card">
                        <h2><i class="fas fa-users"></i> Existing Administrators</h2>
                        
                        <?php if (count($admins) > 0): ?>
                            <div class="table-container">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Username</th>
                                            <th>Email</th>
                                            <th>Created</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($admins as $admin): ?>
                                            <tr>
                                                <td>
                                                    <div style="font-weight: 600; margin-bottom: 4px;">
                                                        <?php echo htmlspecialchars(($admin['first_name'] ?? '') . ' ' . ($admin['last_name'] ?? $admin['username'])); ?>
                                                    </div>
                                                    <span class="admin-badge">Admin</span>
                                                </td>
                                                <td>
                                                    <div style="font-weight: 600; color: var(--primary-dark);">
                                                        <?php echo htmlspecialchars($admin['username']); ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php echo htmlspecialchars($admin['email']); ?>
                                                </td>
                                                <td>
                                                    <?php 
                                                        if (isset($admin['created_at'])) {
                                                            echo date('M d, Y', strtotime($admin['created_at']));
                                                        } else {
                                                            echo 'N/A';
                                                        }
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div style="text-align: center; margin-top: 20px;">
                                <div style="font-size: 0.9rem; color: var(--text-light);">
                                    <i class="fas fa-info-circle"></i>
                                    <?php echo count($admins); ?> administrator<?php echo count($admins) != 1 ? 's' : ''; ?> in system
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-user-shield"></i>
                                <h3>No Administrators</h3>
                                <p>There are currently no administrators in the system. Create the first admin account!</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <div class="footer">
                <div class="footer-links">
                    <a href="admin_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
                    <a href="#"><i class="fas fa-question-circle"></i> Help</a>
                    <a href="../index.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
                
                <div class="footer-copyright">
                    <i class="fas fa-heart"></i>
                    2023 EduFlow Admin Management System. All rights reserved.
                </div>
            </div>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const menuToggle = document.getElementById('menuToggle');
            const sidebar = document.getElementById('sidebar');
            
            // Show menu toggle on mobile
            if (window.innerWidth <= 480) {
                menuToggle.style.display = 'block';
                
                menuToggle.addEventListener('click', () => {
                    sidebar.classList.toggle('active');
                });
                
                // Close sidebar when clicking outside
                document.addEventListener('click', (e) => {
                    if (!sidebar.contains(e.target) && !menuToggle.contains(e.target) && window.innerWidth <= 480) {
                        sidebar.classList.remove('active');
                    }
                });
            }
            
            // Window resize handler
            window.addEventListener('resize', function() {
                if (window.innerWidth > 480) {
                    menuToggle.style.display = 'none';
                    sidebar.classList.remove('active');
                } else {
                    menuToggle.style.display = 'block';
                }
            });
            
            // Auto-hide alerts after 8 seconds
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    alert.style.transform = 'translateX(30px)';
                    alert.style.transition = 'all 0.5s ease';
                    
                    setTimeout(() => {
                        alert.style.display = 'none';
                    }, 500);
                }, 8000);
            });
            
            // Password strength indicator
            const passwordInput = document.getElementById('password');
            const passwordHelp = document.createElement('div');
            passwordHelp.style.fontSize = '0.85rem';
            passwordHelp.style.marginTop = '8px';
            passwordHelp.style.color = 'var(--text-light)';
            passwordInput.parentNode.appendChild(passwordHelp);
            
            passwordInput.addEventListener('input', function() {
                const password = this.value;
                let strength = 0;
                let message = '';
                let color = 'var(--text-light)';
                
                if (password.length >= 8) strength++;
                if (/[A-Z]/.test(password)) strength++;
                if (/[0-9]/.test(password)) strength++;
                if (/[^A-Za-z0-9]/.test(password)) strength++;
                
                switch(strength) {
                    case 0:
                    case 1:
                        message = 'Weak password';
                        color = 'var(--danger)';
                        break;
                    case 2:
                        message = 'Fair password';
                        color = 'var(--warning)';
                        break;
                    case 3:
                        message = 'Good password';
                        color = 'var(--success)';
                        break;
                    case 4:
                        message = 'Strong password';
                        color = 'var(--success)';
                        break;
                }
                
                passwordHelp.textContent = message;
                passwordHelp.style.color = color;
            });
        });
    </script>
</body>
</html>