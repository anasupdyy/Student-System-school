// ===== Dhammaan JavaScript-ka =====

// 1. DOM Ready Function
document.addEventListener('DOMContentLoaded', function() {
    console.log('School Management System - JavaScript Loaded');
    
    // Initialize all components
    initDashboardAnimations();
    initLiveTime();
    initSearchFunctionality();
    initAttendanceButtons();
    initFormValidations();
    initTooltips();
    initSmoothScroll();
    initResponsiveSidebar();
    initChartAnimations();
    initNotifications();
    initUserMenu();
    initThemeManager();
});

// 2. Dashboard Animations
function initDashboardAnimations() {
    // Animate stat cards
    const statCards = document.querySelectorAll('.stat-card');
    statCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px)';
            this.style.boxShadow = '0 20px 40px rgba(45, 51, 59, 0.15)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = 'var(--shadow)';
        });
    });
    
    // Animate management cards
    const managementCards = document.querySelectorAll('.management-card');
    managementCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
    
    // Animate portfolio cards
    const portfolioCards = document.querySelectorAll('.portfolio-card');
    portfolioCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
    });
    
    // Add scroll animation observer
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // Observe animated elements
    document.querySelectorAll('.stat-card, .management-card, .portfolio-card, .card').forEach(el => {
        observer.observe(el);
    });
}

// 3. Live Time Function
function initLiveTime() {
    function updateLiveTime() {
        const now = new Date();
        const options = {
            weekday: 'short',
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
        };
        
        const timeString = now.toLocaleDateString('en-US', options);
        const liveTimeElement = document.getElementById('live-time');
        if (liveTimeElement) {
            liveTimeElement.textContent = timeString;
        }
    }
    
    // Update immediately and every second
    updateLiveTime();
    setInterval(updateLiveTime, 1000);
}

// 4. Search Functionality
function initSearchFunctionality() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        // Debounce search function
        const debouncedSearch = debounce(function() {
            searchStudents(this.value);
        }, 300);
        
        searchInput.addEventListener('input', debouncedSearch);
    }
}

function searchStudents(searchTerm) {
    const table = document.getElementById('studentsTable');
    if (!table) return;
    
    const rows = table.getElementsByTagName('tr');
    const term = searchTerm.toLowerCase().trim();
    
    for (let i = 1; i < rows.length; i++) { // Start from 1 to skip header
        const row = rows[i];
        const cells = row.getElementsByTagName('td');
        let found = false;
        
        for (let j = 0; j < cells.length; j++) {
            const cellText = cells[j].textContent.toLowerCase();
            if (cellText.includes(term)) {
                found = true;
                break;
            }
        }
        
        row.style.display = found ? '' : 'none';
    }
}

// 5. Attendance Buttons
function initAttendanceButtons() {
    document.querySelectorAll('.attendance-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const studentId = this.getAttribute('data-student-id');
            const status = this.getAttribute('data-status');
            
            if (studentId && status) {
                setAttendance(studentId, status);
            }
        });
    });
}

function setAttendance(studentId, status) {
    const input = document.getElementById(`attendance_${studentId}`);
    if (!input) return;
    
    // Update hidden input value
    input.value = status;
    
    // Update button states
    const row = input.closest('tr');
    if (row) {
        // Remove active class from all buttons in this row
        row.querySelectorAll('.attendance-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Add active class to clicked button
        const activeBtn = row.querySelector(`.attendance-btn[data-status="${status}"]`);
        if (activeBtn) {
            activeBtn.classList.add('active');
            
            // Add visual feedback
            activeBtn.style.transform = 'scale(1.1)';
            setTimeout(() => {
                activeBtn.style.transform = '';
            }, 300);
        }
    }
    
    // Show success message
    showToast(`Attendance marked as ${status}`, 'success');
}

// 6. Form Validations
function initFormValidations() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!validateForm(this)) {
                e.preventDefault();
            }
        });
    });
    
    // Add real-time validation
    document.querySelectorAll('[data-validate]').forEach(input => {
        input.addEventListener('blur', function() {
            validateField(this);
        });
        
        input.addEventListener('input', function() {
            clearFieldError(this);
        });
    });
}

function validateForm(form) {
    let isValid = true;
    const requiredFields = form.querySelectorAll('[required]');
    
    requiredFields.forEach(field => {
        if (!validateField(field)) {
            isValid = false;
        }
    });
    
    return isValid;
}

function validateField(field) {
    const value = field.value.trim();
    let isValid = true;
    let errorMessage = '';
    
    // Clear previous error
    clearFieldError(field);
    
    // Required validation
    if (field.required && !value) {
        isValid = false;
        errorMessage = 'This field is required';
    }
    
    // Email validation
    if (field.type === 'email' && value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            isValid = false;
            errorMessage = 'Please enter a valid email address';
        }
    }
    
    // Password validation
    if (field.type === 'password' && value) {
        if (value.length < 6) {
            isValid = false;
            errorMessage = 'Password must be at least 6 characters';
        }
    }
    
    // Phone validation
    if (field.getAttribute('data-validate') === 'phone' && value) {
        const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
        const cleanPhone = value.replace(/[\s\-\(\)]/g, '');
        if (!phoneRegex.test(cleanPhone)) {
            isValid = false;
            errorMessage = 'Please enter a valid phone number';
        }
    }
    
    // Show error if invalid
    if (!isValid) {
        showFieldError(field, errorMessage);
    }
    
    return isValid;
}

function showFieldError(field, message) {
    field.classList.add('error');
    
    // Create error element
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    errorDiv.style.cssText = `
        color: var(--danger-color);
        font-size: 0.85rem;
        margin-top: 4px;
    `;
    
    // Insert after field
    field.parentNode.insertBefore(errorDiv, field.nextSibling);
}

function clearFieldError(field) {
    field.classList.remove('error');
    
    // Remove error message
    const errorDiv = field.parentNode.querySelector('.field-error');
    if (errorDiv) {
        errorDiv.remove();
    }
}

// 7. Tooltips
function initTooltips() {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    tooltipElements.forEach(el => {
        el.addEventListener('mouseenter', function(e) {
            const tooltip = document.createElement('div');
            tooltip.className = 'tooltip';
            tooltip.textContent = this.getAttribute('data-tooltip');
            
            // Style tooltip
            tooltip.style.cssText = `
                position: fixed;
                background: var(--slate-dark);
                color: var(--cream-white);
                padding: 8px 12px;
                border-radius: var(--radius);
                font-size: 0.8rem;
                z-index: 9999;
                max-width: 200px;
                pointer-events: none;
                opacity: 0;
                transform: translateY(10px);
                transition: opacity 0.2s, transform 0.2s;
            `;
            
            document.body.appendChild(tooltip);
            
            // Position tooltip
            const rect = this.getBoundingClientRect();
            tooltip.style.left = rect.left + rect.width / 2 - tooltip.offsetWidth / 2 + 'px';
            tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
            
            // Show tooltip
            setTimeout(() => {
                tooltip.style.opacity = '1';
                tooltip.style.transform = 'translateY(0)';
            }, 10);
            
            // Store reference
            this._tooltip = tooltip;
        });
        
        el.addEventListener('mouseleave', function() {
            if (this._tooltip) {
                this._tooltip.style.opacity = '0';
                this._tooltip.style.transform = 'translateY(10px)';
                
                setTimeout(() => {
                    if (this._tooltip && this._tooltip.parentNode) {
                        this._tooltip.parentNode.removeChild(this._tooltip);
                    }
                    delete this._tooltip;
                }, 200);
            }
        });
    });
}

// 8. Smooth Scroll
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// 9. Responsive Sidebar
function initResponsiveSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    
    if (!sidebar || !mainContent) return;
    
    // Toggle sidebar on mobile
    const toggleBtn = document.createElement('button');
    toggleBtn.className = 'sidebar-toggle';
    toggleBtn.innerHTML = '<i class="fas fa-bars"></i>';
    toggleBtn.style.cssText = `
        position: fixed;
        top: 20px;
        left: 20px;
        z-index: 1001;
        background: var(--primary-color);
        color: white;
        border: none;
        width: 40px;
        height: 40px;
        border-radius: var(--radius);
        display: none;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        box-shadow: var(--shadow);
    `;
    
    document.body.appendChild(toggleBtn);
    
    toggleBtn.addEventListener('click', function() {
        sidebar.classList.toggle('open');
        this.classList.toggle('open');
        
        if (sidebar.classList.contains('open')) {
            this.innerHTML = '<i class="fas fa-times"></i>';
        } else {
            this.innerHTML = '<i class="fas fa-bars"></i>';
        }
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 768 && 
            !sidebar.contains(e.target) && 
            !toggleBtn.contains(e.target) &&
            sidebar.classList.contains('open')) {
            sidebar.classList.remove('open');
            toggleBtn.classList.remove('open');
            toggleBtn.innerHTML = '<i class="fas fa-bars"></i>';
        }
    });
    
    // Update on window resize
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768) {
            sidebar.classList.remove('open');
            toggleBtn.style.display = 'none';
        } else {
            toggleBtn.style.display = 'flex';
        }
    });
    
    // Initial check
    if (window.innerWidth <= 768) {
        toggleBtn.style.display = 'flex';
    }
}

// 10. Chart Animations
function initChartAnimations() {
    // Animate grade bars
    const gradeFills = document.querySelectorAll('.grade-fill');
    gradeFills.forEach(fill => {
        const originalWidth = fill.style.width;
        fill.style.width = '0';
        
        setTimeout(() => {
            fill.style.width = originalWidth;
        }, 500);
    });
    
    // Animate progress bars
    const progressBars = document.querySelectorAll('.progress-bar');
    progressBars.forEach(bar => {
        const width = bar.getAttribute('data-width');
        if (width) {
            bar.style.width = '0';
            
            setTimeout(() => {
                bar.style.width = width + '%';
            }, 300);
        }
    });
}

// 11. Notifications
function initNotifications() {
    const notificationIcon = document.querySelector('.notification-icon');
    if (!notificationIcon) return;
    
    notificationIcon.addEventListener('click', function() {
        // Toggle notifications panel
        const panel = document.querySelector('.notifications-panel');
        if (panel) {
            panel.classList.toggle('show');
        } else {
            createNotificationsPanel();
        }
    });
    
    // Mark all as read
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('mark-read')) {
            const badge = document.querySelector('.notification-badge');
            if (badge) {
                badge.style.display = 'none';
            }
            showToast('All notifications marked as read', 'success');
        }
    });
}

function createNotificationsPanel() {
    const panel = document.createElement('div');
    panel.className = 'notifications-panel';
    panel.innerHTML = `
        <div class="panel-header">
            <h3>Notifications</h3>
            <button class="mark-read">Mark all as read</button>
        </div>
        <div class="panel-body">
            <div class="notification-item">
                <i class="fas fa-user-plus"></i>
                <div>
                    <strong>New student registered</strong>
                    <p>John Doe registered for Grade 10</p>
                    <small>2 minutes ago</small>
                </div>
            </div>
            <div class="notification-item">
                <i class="fas fa-file-alt"></i>
                <div>
                    <strong>Exam scheduled</strong>
                    <p>Mathematics final exam scheduled for tomorrow</p>
                    <small>1 hour ago</small>
                </div>
            </div>
            <div class="notification-item">
                <i class="fas fa-chart-line"></i>
                <div>
                    <strong>Attendance report ready</strong>
                    <p>Monthly attendance report is now available</p>
                    <small>3 hours ago</small>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(panel);
    
    // Style panel
    panel.style.cssText = `
        position: fixed;
        top: 70px;
        right: 20px;
        width: 350px;
        background: var(--cream-white);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-xl);
        z-index: 1000;
        display: none;
    `;
    
    // Show panel
    setTimeout(() => {
        panel.style.display = 'block';
        panel.classList.add('show');
    }, 10);
    
    // Close when clicking outside
    document.addEventListener('click', function(e) {
        if (!panel.contains(e.target) && !e.target.closest('.notification-icon')) {
            panel.classList.remove('show');
            setTimeout(() => {
                if (panel.parentNode) {
                    panel.parentNode.removeChild(panel);
                }
            }, 300);
        }
    });
}

// 12. User Menu
function initUserMenu() {
    const userProfile = document.querySelector('.user-profile');
    if (!userProfile) return;
    
    userProfile.addEventListener('click', function(e) {
        e.stopPropagation();
        
        // Toggle user menu
        const menu = document.querySelector('.user-menu-dropdown');
        if (menu) {
            menu.classList.toggle('show');
        } else {
            createUserMenu(this);
        }
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', function() {
        const menu = document.querySelector('.user-menu-dropdown');
        if (menu) {
            menu.classList.remove('show');
            setTimeout(() => {
                if (menu.parentNode) {
                    menu.parentNode.removeChild(menu);
                }
            }, 300);
        }
    });
}

function createUserMenu(profileElement) {
    const menu = document.createElement('div');
    menu.className = 'user-menu-dropdown';
    menu.innerHTML = `
        <a href="profile.php">
            <i class="fas fa-user"></i>
            <span>My Profile</span>
        </a>
        <a href="settings.php">
            <i class="fas fa-cog"></i>
            <span>Settings</span>
        </a>
        <div class="divider"></div>
        <a href="../index.php" class="logout">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    `;
    
    document.body.appendChild(menu);
    
    // Position menu
    const rect = profileElement.getBoundingClientRect();
    menu.style.left = rect.right - 200 + 'px';
    menu.style.top = rect.bottom + 10 + 'px';
    
    // Style menu
    menu.style.cssText = `
        position: fixed;
        width: 200px;
        background: var(--cream-white);
        border: 1px solid var(--border-color);
        border-radius: var(--radius);
        box-shadow: var(--shadow-xl);
        z-index: 1000;
        display: none;
    `;
    
    // Show menu
    setTimeout(() => {
        menu.style.display = 'block';
        menu.classList.add('show');
    }, 10);
}

// 13. Theme Manager
function initThemeManager() {
    // Check for saved theme preference
    const savedTheme = localStorage.getItem('theme') || 'light';
    setTheme(savedTheme);
    
    // Create theme toggle button
    const themeToggle = document.createElement('button');
    themeToggle.className = 'theme-toggle';
    themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
    themeToggle.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 50px;
        height: 50px;
        background: var(--primary-color);
        color: white;
        border: none;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        box-shadow: var(--shadow);
        z-index: 999;
        transition: var(--transition);
    `;
    
    document.body.appendChild(themeToggle);
    
    themeToggle.addEventListener('click', function() {
        const currentTheme = document.body.classList.contains('dark-theme') ? 'dark' : 'light';
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        
        setTheme(newTheme);
        localStorage.setItem('theme', newTheme);
        
        // Update button icon
        this.innerHTML = newTheme === 'dark' ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
        
        showToast(`Theme changed to ${newTheme} mode`, 'info');
    });
}

function setTheme(theme) {
    if (theme === 'dark') {
        document.body.classList.add('dark-theme');
        document.body.classList.remove('light-theme');
        
        // Update CSS variables for dark theme
        document.documentElement.style.setProperty('--body-bg', '#1a1a1a');
        document.documentElement.style.setProperty('--card-bg', '#2d2d2d');
        document.documentElement.style.setProperty('--text-dark', '#e0e0e0');
        document.documentElement.style.setProperty('--text-muted', '#a0a0a0');
        document.documentElement.style.setProperty('--border-color', 'rgba(255, 255, 255, 0.1)');
    } else {
        document.body.classList.add('light-theme');
        document.body.classList.remove('dark-theme');
        
        // Reset to default theme
        document.documentElement.style.setProperty('--body-bg', '#FDFCF8');
        document.documentElement.style.setProperty('--card-bg', '#FFFEFB');
        document.documentElement.style.setProperty('--text-dark', '#2D333B');
        document.documentElement.style.setProperty('--text-muted', '#6E7681');
        document.documentElement.style.setProperty('--border-color', 'rgba(68, 76, 86, 0.15)');
    }
}

// 14. Utility Functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function showToast(message, type = 'info') {
    // Remove existing toast
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    // Create toast
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-${getToastIcon(type)}"></i>
            <span>${message}</span>
        </div>
        <button class="toast-close">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    document.body.appendChild(toast);
    
    // Style toast
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${getToastColor(type)};
        color: white;
        padding: 12px 20px;
        border-radius: var(--radius);
        box-shadow: var(--shadow-xl);
        display: flex;
        align-items: center;
        gap: 10px;
        z-index: 9999;
        transform: translateX(150%);
        transition: transform 0.3s ease;
    `;
    
    // Show toast
    setTimeout(() => {
        toast.style.transform = 'translateX(0)';
    }, 10);
    
    // Auto hide after 3 seconds
    setTimeout(() => {
        hideToast(toast);
    }, 3000);
    
    // Close button
    const closeBtn = toast.querySelector('.toast-close');
    closeBtn.addEventListener('click', () => hideToast(toast));
    
    function hideToast(toastElement) {
        toastElement.style.transform = 'translateX(150%)';
        setTimeout(() => {
            if (toastElement.parentNode) {
                toastElement.parentNode.removeChild(toastElement);
            }
        }, 300);
    }
}

function getToastIcon(type) {
    const icons = {
        success: 'check-circle',
        error: 'times-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    return icons[type] || 'info-circle';
}

function getToastColor(type) {
    const colors = {
        success: 'var(--success-color)',
        error: 'var(--danger-color)',
        warning: 'var(--warning-color)',
        info: 'var(--info-color)'
    };
    return colors[type] || 'var(--info-color)';
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function formatDateTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        weekday: 'short',
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function calculateGrade(marks, totalMarks) {
    const percentage = (marks / totalMarks) * 100;
    
    if (percentage >= 90) return { grade: 'A', color: '#2DA44E' };
    if (percentage >= 80) return { grade: 'B', color: '#3FB950' };
    if (percentage >= 70) return { grade: 'C', color: '#D9822B' };
    if (percentage >= 60) return { grade: 'D', color: '#F778BA' };
    return { grade: 'F', color: '#CF222E' };
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showToast('Copied to clipboard!', 'success');
    }).catch(err => {
        console.error('Failed to copy: ', err);
        showToast('Failed to copy', 'error');
    });
}

function confirmAction(message) {
    return new Promise((resolve) => {
        const confirmed = confirm(message);
        resolve(confirmed);
    });
}

// 15. Export Functions for Global Use
window.searchStudents = searchStudents;
window.setAttendance = setAttendance;
window.showToast = showToast;
window.formatDate = formatDate;
window.formatDateTime = formatDateTime;
window.calculateGrade = calculateGrade;
window.copyToClipboard = copyToClipboard;
window.confirmAction = confirmAction;

// 16. Window Load Event
window.addEventListener('load', function() {
    // Add loading animation
    document.body.classList.add('loaded');
    
    // Initialize any lazy-loaded content
    initLazyContent();
});

function initLazyContent() {
    // Lazy load images
    const lazyImages = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.getAttribute('data-src');
                img.classList.add('loaded');
                imageObserver.unobserve(img);
            }
        });
    });
    
    lazyImages.forEach(img => imageObserver.observe(img));
}