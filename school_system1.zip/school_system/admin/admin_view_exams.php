<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../index.php');
    exit();
}

// Initialize variables
$student_data = null;
$exam_results = [];
$error = '';
$success = '';
$multiple_results = [];
$search_term = '';

// ========== SAXIDKA LOGIC-KA SEARCH-KA ==========

// Handle POST search (from search form)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search'])) {
    $search_term = trim($_POST['search_term'] ?? '');
    
    if (!empty($search_term)) {
        // Clean search term
        $search_term = strtoupper(trim($search_term));
        
        // LOGIC 1: Hadii ay tahay STU-ID (STU001, STU002, iwm)
        if (preg_match('/^STU\d+$/i', $search_term)) {
            // Raadi STU-ID-ga si sax ah
            $search_stmt = $pdo->prepare("
                SELECT 
                    s.id,
                    s.first_name,
                    s.last_name,
                    s.grade_level,
                    s.user_id,
                    u.username as stu_id
                FROM students s
                JOIN users u ON s.user_id = u.id
                WHERE u.username = ?
                AND u.role = 'student'
            ");
            $search_stmt->execute([$search_term]);
            $results = $search_stmt->fetchAll();
            
            if (count($results) > 0) {
                $student_data = $results[0];
                $success = "Student found with STU-ID: " . htmlspecialchars($student_data['stu_id']);
            } else {
                $error = 'No student found with STU-ID: ' . htmlspecialchars($search_term);
            }
        }
        // LOGIC 2: Hadii ay tahay tiro kaliya (1, 2, 3, 4, iwm)
        elseif (preg_match('/^\d+$/', $search_term)) {
            // Tiro ka dhigi 3 xaraf (001, 002, iwm)
            $padded_id = str_pad($search_term, 3, '0', STR_PAD_LEFT);
            $stu_id = 'STU' . $padded_id;
            
            // LOGIC 2A: Raadi STU-ID-ga saxda ah
            $search_stmt = $pdo->prepare("
                SELECT 
                    s.id,
                    s.first_name,
                    s.last_name,
                    s.grade_level,
                    s.user_id,
                    u.username as stu_id
                FROM students s
                JOIN users u ON s.user_id = u.id
                WHERE u.username = ?
                AND u.role = 'student'
            ");
            $search_stmt->execute([$stu_id]);
            $results = $search_stmt->fetchAll();
            
            if (count($results) > 0) {
                $student_data = $results[0];
                $success = "Student found with STU-ID: " . htmlspecialchars($student_data['stu_id']);
            } else {
                // LOGIC 2B: Hadii aan la helin, raadi magaca
                $search_pattern = "%$search_term%";
                $search_stmt = $pdo->prepare("
                    SELECT 
                        s.id,
                        s.first_name,
                        s.last_name,
                        s.grade_level,
                        s.user_id,
                        u.username as stu_id
                    FROM students s
                    JOIN users u ON s.user_id = u.id
                    WHERE (
                        s.first_name LIKE ? OR 
                        s.last_name LIKE ? OR 
                        CONCAT(s.first_name, ' ', s.last_name) LIKE ? OR
                        u.username LIKE ?
                    )
                    AND u.role = 'student'
                    ORDER BY 
                        CASE 
                            WHEN u.username = ? THEN 1
                            WHEN u.username LIKE ? THEN 2
                            WHEN s.first_name LIKE ? THEN 3
                            ELSE 4
                        END,
                        s.last_name, 
                        s.first_name
                    LIMIT 20
                ");
                $search_stmt->execute([
                    $search_pattern, 
                    $search_pattern, 
                    $search_pattern,
                    "%$search_term%",
                    $stu_id,
                    "%$search_term%",
                    "$search_term%"
                ]);
                $results = $search_stmt->fetchAll();
                
                if (count($results) === 1) {
                    $student_data = $results[0];
                } elseif (count($results) > 1) {
                    $multiple_results = $results;
                } else {
                    $error = 'No student found with that search term.';
                }
            }
        }
        // LOGIC 3: Magac ka raadi
        else {
            $search_pattern = "%$search_term%";
            $search_stmt = $pdo->prepare("
                SELECT 
                    s.id,
                    s.first_name,
                    s.last_name,
                    s.grade_level,
                    s.user_id,
                    u.username as stu_id
                FROM students s
                JOIN users u ON s.user_id = u.id
                WHERE (
                    s.first_name LIKE ? OR 
                    s.last_name LIKE ? OR 
                    CONCAT(s.first_name, ' ', s.last_name) LIKE ? OR
                    u.username LIKE ?
                )
                AND u.role = 'student'
                ORDER BY 
                    CASE 
                        WHEN s.first_name LIKE ? THEN 1
                        WHEN s.last_name LIKE ? THEN 2
                        WHEN CONCAT(s.first_name, ' ', s.last_name) LIKE ? THEN 3
                        ELSE 4
                    END,
                    s.last_name, 
                    s.first_name
                LIMIT 20
            ");
            $search_stmt->execute([
                $search_pattern, 
                $search_pattern, 
                $search_pattern,
                "%$search_term%",
                "$search_term%",
                "$search_term%",
                "$search_term%"
            ]);
            $results = $search_stmt->fetchAll();
            
            if (count($results) === 1) {
                $student_data = $results[0];
            } elseif (count($results) > 1) {
                $multiple_results = $results;
            } else {
                $error = 'No student found with that search term.';
            }
        }
    } else {
        $error = 'Please enter a search term.';
    }
}

// Handle GET search (direct STU-ID from URL) - SI DHAQSO LEH
if (isset($_GET['stu_id']) && !empty($_GET['stu_id'])) {
    $stu_id_param = trim(strtoupper($_GET['stu_id']));
    
    // Hadii ay tahay tiro kaliya, ku dar prefix-ka STU
    if (preg_match('/^\d+$/', $stu_id_param)) {
        $stu_id_param = 'STU' . str_pad($stu_id_param, 3, '0', STR_PAD_LEFT);
    }
    // Hadii aanay ka bilabin STU, ku dar
    elseif (!preg_match('/^STU/', $stu_id_param)) {
        $stu_id_param = 'STU' . str_pad($stu_id_param, 3, '0', STR_PAD_LEFT);
    }
    
    // Raadi si dhaqso leh
    $stu_stmt = $pdo->prepare("
        SELECT 
            s.id,
            s.first_name,
            s.last_name,
            s.grade_level,
            s.user_id,
            u.username as stu_id
        FROM students s
        JOIN users u ON s.user_id = u.id
        WHERE u.username = ?
        AND u.role = 'student'
    ");
    
    $stu_stmt->execute([$stu_id_param]);
    $student_data = $stu_stmt->fetch();
    
    if (!$student_data) {
        $error = "No student found with STU-ID: " . htmlspecialchars($stu_id_param);
    } else {
        $success = "Student found with STU-ID: " . htmlspecialchars($student_data['stu_id']);
    }
}

// Handle direct student ID from GET - SI DHAQSO LEH
if (isset($_GET['student_id']) && is_numeric($_GET['student_id'])) {
    $student_id = (int)$_GET['student_id'];
    
    // Same query, different parameter
    $student_stmt = $pdo->prepare("
        SELECT 
            s.id,
            s.first_name,
            s.last_name,
            s.grade_level,
            s.user_id,
            u.username as stu_id
        FROM students s
        JOIN users u ON s.user_id = u.id
        WHERE s.id = ?
    ");
    
    $student_stmt->execute([$student_id]);
    $student_data = $student_stmt->fetch();
    
    if (!$student_data) {
        $error = 'Student not found.';
    } else {
        $success = "Student found: " . htmlspecialchars($student_data['first_name'] . ' ' . $student_data['last_name']);
    }
}

// ========== CACHE SYSTEM ==========
// Si loo sameeyo search-ka dhaqso leh, waxaan ku daraynaa caching system
if ($student_data) {
    // Store in session cache for quick access
    $cache_key = 'student_' . $student_data['id'];
    $_SESSION[$cache_key] = [
        'data' => $student_data,
        'timestamp' => time()
    ];
    
    // Keep only last 5 students in cache
    $cache_keys = array_keys($_SESSION);
    $student_cache_keys = array_filter($cache_keys, function($key) {
        return strpos($key, 'student_') === 0;
    });
    
    if (count($student_cache_keys) > 5) {
        // Remove oldest cache
        $oldest_key = null;
        $oldest_time = time();
        
        foreach ($student_cache_keys as $key) {
            if (isset($_SESSION[$key]['timestamp']) && $_SESSION[$key]['timestamp'] < $oldest_time) {
                $oldest_time = $_SESSION[$key]['timestamp'];
                $oldest_key = $key;
            }
        }
        
        if ($oldest_key) {
            unset($_SESSION[$oldest_key]);
        }
    }
}

// Preserve search term when switching students
if (isset($_SESSION['last_search_term']) && empty($_POST['search_term'])) {
    $search_term = $_SESSION['last_search_term'];
}

// ========== FUNCTIONS ==========
function getGrade($percentage) {
    if ($percentage >= 90) return ['A', '#10b981'];
    if ($percentage >= 80) return ['B', '#3b82f6'];
    if ($percentage >= 70) return ['C', '#f59e0b'];
    if ($percentage >= 60) return ['D', '#ef4444'];
    return ['F', '#6b7280'];
}

function getPositionSuffix($position) {
    if ($position == 1) return 'st';
    if ($position == 2) return 'nd';
    if ($position == 3) return 'rd';
    return 'th';
}

function getWeightedGrade($weighted_score) {
    return getGrade($weighted_score);
}

function getPassFailStatus($overall_average) {
    if ($overall_average >= 60) {
        return ['PASS', '#10b981', 'rgba(16, 185, 129, 0.15)'];
    } else {
        return ['FAIL', '#ef4444', 'rgba(239, 68, 68, 0.15)'];
    }
}

// If we have student data, get their exam results
if ($student_data) {
    $student_id = $student_data['id'];
    $grade_level = $student_data['grade_level'];
    
    // Get all exam results for this student
    $exams_stmt = $pdo->prepare("
        SELECT 
            e.id as exam_id,
            e.exam_name,
            e.subject,
            LOWER(e.exam_type) as exam_type,
            e.total_marks,
            e.exam_date,
            e.target_class,
            er.marks_obtained,
            t.first_name as teacher_first,
            t.last_name as teacher_last
        FROM exams e
        JOIN exam_results er ON e.id = er.exam_id
        LEFT JOIN teachers t ON e.created_by = t.user_id
        WHERE er.student_id = ?
        AND e.target_class = ?
        ORDER BY e.subject, e.exam_date
    ");
    
    $exams_stmt->execute([$student_id, $grade_level]);
    $exam_results = $exams_stmt->fetchAll();
    
    // ========== CALCULATE SUBJECT RESULTS ==========
    $subject_results = [];
    
    foreach ($exam_results as $exam) {
        $subject = $exam['subject'];
        $exam_type = $exam['exam_type'];
        
        if (!isset($subject_results[$subject])) {
            $subject_results[$subject] = [
                'mid_term_marks' => null,
                'mid_term_total' => 0,
                'final_marks' => null,
                'final_total' => 0,
                'mid_term_weighted' => 0,
                'final_weighted' => 0,
                'total_score' => 0
            ];
        }
        
        if ($exam_type == 'mid-term' || $exam_type == 'mid term') {
            $marks = (float)$exam['marks_obtained'];
            $total = (float)$exam['total_marks'];
            
            $subject_results[$subject]['mid_term_marks'] = $marks;
            $subject_results[$subject]['mid_term_total'] = $total;
            $subject_results[$subject]['mid_term_weighted'] = $total > 0 ? ($marks / $total) * 40 : 0;
        } elseif ($exam_type == 'final') {
            $marks = (float)$exam['marks_obtained'];
            $total = (float)$exam['total_marks'];
            
            $subject_results[$subject]['final_marks'] = $marks;
            $subject_results[$subject]['final_total'] = $total;
            $subject_results[$subject]['final_weighted'] = $total > 0 ? ($marks / $total) * 60 : 0;
        }
        
        $subject_results[$subject]['total_score'] = 
            $subject_results[$subject]['mid_term_weighted'] + 
            $subject_results[$subject]['final_weighted'];
    }
    
    // Calculate statistics
    $total_exams = count($exam_results);
    $total_score_sum = 0;
    $subjects_with_exams = 0;
    
    foreach ($subject_results as $subject => $data) {
        if ($data['total_score'] > 0) {
            $total_score_sum += $data['total_score'];
            $subjects_with_exams++;
        }
    }
    
    $overall_average = $subjects_with_exams > 0 ? 
        $total_score_sum / $subjects_with_exams : 0;
    
    list($pass_fail_status, $pass_fail_color, $pass_fail_bg) = getPassFailStatus($overall_average);
    
    // ========== CALCULATE CLASS POSITION ==========
    $all_students_stmt = $pdo->prepare("
        SELECT s.id, s.first_name, s.last_name, s.grade_level
        FROM students s
        WHERE s.grade_level = ?
        ORDER BY s.last_name, s.first_name
    ");
    
    $all_students_stmt->execute([$grade_level]);
    $all_students = $all_students_stmt->fetchAll();
    
    $students_with_scores = [];
    
    foreach ($all_students as $student) {
        $student_id_for_calc = $student['id'];
        
        $student_exams_stmt = $pdo->prepare("
            SELECT 
                e.subject,
                LOWER(e.exam_type) as exam_type,
                e.total_marks,
                er.marks_obtained
            FROM exams e
            JOIN exam_results er ON e.id = er.exam_id
            WHERE er.student_id = ?
            AND e.target_class = ?
        ");
        
        $student_exams_stmt->execute([$student_id_for_calc, $grade_level]);
        $student_exams = $student_exams_stmt->fetchAll();
        
        $student_subject_results = [];
        
        foreach ($student_exams as $exam) {
            $subject = $exam['subject'];
            $exam_type = $exam['exam_type'];
            
            if (!isset($student_subject_results[$subject])) {
                $student_subject_results[$subject] = [
                    'mid_term_weighted' => 0,
                    'final_weighted' => 0,
                    'total_score' => 0
                ];
            }
            
            if ($exam_type == 'mid-term' || $exam_type == 'mid term') {
                $marks = (float)$exam['marks_obtained'];
                $total = (float)$exam['total_marks'];
                $student_subject_results[$subject]['mid_term_weighted'] = $total > 0 ? ($marks / $total) * 40 : 0;
            } elseif ($exam_type == 'final') {
                $marks = (float)$exam['marks_obtained'];
                $total = (float)$exam['total_marks'];
                $student_subject_results[$subject]['final_weighted'] = $total > 0 ? ($marks / $total) * 60 : 0;
            }
            
            $student_subject_results[$subject]['total_score'] = 
                $student_subject_results[$subject]['mid_term_weighted'] + 
                $student_subject_results[$subject]['final_weighted'];
        }
        
        $student_total_score = 0;
        $student_subjects_count = 0;
        
        foreach ($student_subject_results as $subject_data) {
            if ($subject_data['total_score'] > 0) {
                $student_total_score += $subject_data['total_score'];
                $student_subjects_count++;
            }
        }
        
        $student_average_score = $student_subjects_count > 0 ? 
            $student_total_score / $student_subjects_count : 0;
        
        if ($student_subjects_count > 0) {
            $students_with_scores[] = [
                'student_id' => $student_id_for_calc,
                'first_name' => $student['first_name'],
                'last_name' => $student['last_name'],
                'total_score' => $student_total_score,
                'subjects_count' => $student_subjects_count,
                'average_score' => $student_average_score,
                'pass_fail' => $student_average_score >= 60 ? 'PASS' : 'FAIL'
            ];
        }
    }
    
    usort($students_with_scores, function($a, $b) {
        return $b['average_score'] <=> $a['average_score'];
    });
    
    $class_total_students = count($students_with_scores);
    $student_position = 'N/A';
    $rankings = [];
    
    $current_rank = 1;
    $previous_score = null;
    $skip_counter = 0;
    
    foreach ($students_with_scores as $index => $student) {
        $current_score = $student['average_score'];
        
        if ($previous_score !== null && abs($current_score - $previous_score) < 0.01) {
            $skip_counter++;
        } else {
            $current_rank = $current_rank + $skip_counter;
            $skip_counter = 0;
        }
        
        $position = $current_rank;
        
        $rankings[] = [
            'position' => $position,
            'student_id' => $student['student_id'],
            'first_name' => $student['first_name'],
            'last_name' => $student['last_name'],
            'total_score' => $student['total_score'],
            'subjects_count' => $student['subjects_count'],
            'average_score' => $student['average_score'],
            'pass_fail' => $student['pass_fail']
        ];
        
        if ($student['student_id'] == $student_id) {
            $student_position = $position;
            $student_total_score = $student['total_score'];
            $student_average_score = $student['average_score'];
        }
        
        $previous_score = $current_score;
        $current_rank++;
    }
    
    // ========== CALCULATE SUBJECT POSITIONS ==========
    $subject_positions = [];
    
    foreach ($subject_results as $subject => $data) {
        $subject_scores = [];
        
        foreach ($all_students as $student) {
            $student_id_for_subject = $student['id'];
            
            $subject_score_stmt = $pdo->prepare("
                SELECT 
                    SUM(
                        CASE 
                            WHEN LOWER(e.exam_type) IN ('mid-term', 'mid term') 
                            THEN (er.marks_obtained / e.total_marks) * 40
                            WHEN LOWER(e.exam_type) = 'final' 
                            THEN (er.marks_obtained / e.total_marks) * 60
                            ELSE 0
                        END
                    ) as subject_total_score
                FROM exam_results er
                JOIN exams e ON er.exam_id = e.id
                WHERE er.student_id = ?
                AND e.subject = ?
                AND e.target_class = ?
            ");
            
            $subject_score_stmt->execute([$student_id_for_subject, $subject, $grade_level]);
            $subject_score_result = $subject_score_stmt->fetch();
            $subject_score = (float)$subject_score_result['subject_total_score'];
            
            if ($subject_score > 0) {
                $subject_scores[] = [
                    'student_id' => $student_id_for_subject,
                    'score' => $subject_score
                ];
            }
        }
        
        usort($subject_scores, function($a, $b) {
            return $b['score'] <=> $a['score'];
        });
        
        $position = 1;
        $found = false;
        $previous_subject_score = null;
        $subject_skip_counter = 0;
        $actual_position = 1;
        
        foreach ($subject_scores as $index => $score_data) {
            $current_subject_score = $score_data['score'];
            
            if ($previous_subject_score !== null && abs($current_subject_score - $previous_subject_score) < 0.01) {
                $subject_skip_counter++;
            } else {
                $actual_position = $actual_position + $subject_skip_counter;
                $subject_skip_counter = 0;
            }
            
            if ($score_data['student_id'] == $student_id) {
                $subject_positions[$subject] = $actual_position;
                $found = true;
                break;
            }
            
            $previous_subject_score = $current_subject_score;
            $actual_position++;
        }
        
        if (!$found) {
            $subject_positions[$subject] = 'N/A';
        }
    }
}

// Get all students for dropdown (limited for performance)
$all_students_dropdown = $pdo->query("
    SELECT s.id, s.first_name, s.last_name, s.grade_level, u.username as stu_id
    FROM students s
    JOIN users u ON s.user_id = u.id
    WHERE u.role = 'student'
    ORDER BY s.grade_level, s.last_name, s.first_name
    LIMIT 50
")->fetchAll();

// Get all STU-IDs for autocomplete
$stu_ids = $pdo->query("
    SELECT DISTINCT u.username as stu_id
    FROM users u 
    WHERE u.role = 'student' 
    AND u.username LIKE 'STU%'
    ORDER BY u.username
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Student Exams | Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #0a192f;
            --primary-blue: #00ccff;
            --white: #ffffff;
            --light-gray: #f8fafc;
            --medium-gray: #e2e8f0;
            --dark-gray: #64748b;
            --text-dark: #1e293b;
            --text-light: #64748b;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --gradient: linear-gradient(135deg, #00ccff 0%, #0099ff 100%);
            --gold: #FFD700;
            --silver: #C0C0C0;
            --bronze: #CD7F32;
            --midterm-blue: #00ccff;
            --final-purple: #9d4edd;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--light-gray);
            color: var(--text-dark);
            min-height: 100vh;
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 280px;
            background: var(--primary-dark);
            color: var(--white);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            transition: all 0.3s ease;
            z-index: 100;
            box-shadow: 2px 0 15px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(0, 0, 0, 0.2);
        }

        .logo {
            width: 60px;
            height: 60px;
            background: var(--gradient);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 1.8rem;
        }

        .logo-text {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--white);
            letter-spacing: 1px;
        }

        .sidebar-menu {
            padding: 30px 0;
        }

        .menu-item {
            display: flex;
            align-items: center;
            padding: 18px 25px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            border-left: 4px solid transparent;
            transition: all 0.3s ease;
            margin: 5px 15px;
            border-radius: 10px;
            position: relative;
        }

        .menu-item:hover {
            background: rgba(0, 204, 255, 0.15);
            color: var(--white);
            transform: translateX(5px);
        }

        .menu-item.active {
            background: rgba(0, 204, 255, 0.25);
            color: var(--white);
            border-left: 4px solid var(--primary-blue);
        }

        .menu-item i {
            margin-right: 15px;
            font-size: 1.3rem;
            width: 25px;
            text-align: center;
        }

        .menu-text {
            flex: 1;
            font-weight: 500;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .top-bar {
            background: var(--white);
            padding: 25px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.05);
            border-bottom: 1px solid #eaeaea;
        }

        .page-title h1 {
            font-size: 1.8rem;
            color: var(--primary-dark);
            margin-bottom: 8px;
            font-weight: 700;
        }

        .page-title p {
            color: var(--text-light);
            font-size: 1rem;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            padding: 10px 20px;
            border-radius: 30px;
            background: var(--light-gray);
            transition: all 0.3s ease;
            cursor: pointer;
            border: 1px solid #eaeaea;
        }

        .user-profile:hover {
            background: #e6f7ff;
            border-color: var(--primary-blue);
            transform: translateY(-2px);
        }

        .avatar {
            width: 45px;
            height: 45px;
            background: var(--gradient);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            font-weight: 600;
            margin-right: 15px;
        }

        .user-info {
            display: flex;
            flex-direction: column;
        }

        .user-name {
            font-weight: 600;
            color: var(--primary-dark);
        }

        .user-role {
            font-size: 0.9rem;
            color: var(--text-light);
            text-transform: capitalize;
        }

        .content-container {
            padding: 30px;
            flex: 1;
        }

        .search-section {
            background: var(--white);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
        }

        .search-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 25px;
        }

        .search-header h2 {
            color: var(--primary-dark);
            font-size: 1.5rem;
            font-weight: 600;
        }

        .search-header i {
            color: var(--primary-blue);
            font-size: 1.5rem;
        }

        .search-form {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            position: relative;
        }

        .search-input {
            flex: 1;
            padding: 15px 20px;
            border: 2px solid var(--medium-gray);
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .search-input:focus {
            outline: none;
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(0, 204, 255, 0.1);
        }

        .search-btn {
            background: var(--gradient);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
        }

        .search-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 204, 255, 0.3);
        }

        .multiple-results {
            background: var(--white);
            border-radius: 15px;
            padding: 30px;
            margin-top: 20px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
        }

        .multiple-results h3 {
            color: var(--primary-dark);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .result-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 15px;
        }

        .result-item {
            background: var(--light-gray);
            border-radius: 10px;
            padding: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }

        .result-item:hover {
            background: var(--white);
            border-color: var(--primary-blue);
            transform: translateY(-2px);
        }

        .message {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .error-message {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
            border-left: 4px solid var(--danger);
        }

        .success-message {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
            border-left: 4px solid var(--success);
        }

        .info-message {
            background: rgba(0, 204, 255, 0.1);
            color: var(--primary-blue);
            border-left: 4px solid var(--primary-blue);
        }

        .student-info-card {
            background: var(--white);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 25px;
        }

        .info-item {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .info-label {
            color: var(--dark-gray);
            font-size: 0.9rem;
            font-weight: 500;
        }

        .info-value {
            color: var(--primary-dark);
            font-size: 1.1rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .info-badge {
            display: inline-flex;
            align-items: center;
            background: var(--gradient);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
            gap: 8px;
        }

        .pass-fail-status {
            padding: 10px 20px;
            border-radius: 30px;
            font-weight: 700;
            font-size: 1rem;
            text-align: center;
            display: inline-block;
            min-width: 100px;
            letter-spacing: 0.5px;
        }

        .pass-status {
            background: rgba(16, 185, 129, 0.15);
            color: var(--success);
            border: 2px solid var(--success);
        }

        .fail-status {
            background: rgba(239, 68, 68, 0.15);
            color: var(--danger);
            border: 2px solid var(--danger);
        }

        .summary-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .summary-card {
            background: var(--white);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
            text-align: center;
            transition: all 0.3s ease;
        }

        .summary-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .summary-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: rgba(0, 204, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            color: var(--primary-blue);
            font-size: 1.5rem;
        }

        .summary-number {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary-dark);
            margin-bottom: 5px;
        }

        .summary-label {
            color: var(--dark-gray);
            font-size: 1rem;
        }

        .position-number {
            font-size: 28px;
            font-weight: 800;
        }

        .position-1 { color: var(--gold); text-shadow: 0 0 10px rgba(255, 215, 0, 0.3); }
        .position-2 { color: var(--silver); text-shadow: 0 0 10px rgba(192, 192, 192, 0.3); }
        .position-3 { color: var(--bronze); text-shadow: 0 0 10px rgba(205, 127, 50, 0.3); }
        .position-other { color: var(--primary-dark); }

        .results-section {
            background: var(--white);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .section-header h2 {
            color: var(--primary-dark);
            font-size: 1.5rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 900px;
        }

        thead {
            background: linear-gradient(135deg, var(--primary-dark) 0%, #0c2040 100%);
        }

        th {
            padding: 18px 20px;
            text-align: left;
            color: white;
            font-weight: 600;
            font-size: 0.95rem;
            border: none;
        }

        th:first-child {
            border-radius: 10px 0 0 0;
        }

        th:last-child {
            border-radius: 0 10px 0 0;
        }

        tbody tr {
            border-bottom: 1px solid var(--medium-gray);
            transition: all 0.3s ease;
        }

        tbody tr:hover {
            background: rgba(0, 204, 255, 0.05);
        }

        td {
            padding: 18px 20px;
            text-align: left;
            font-size: 0.95rem;
        }

        .exam-cell {
            font-weight: 600;
            color: var(--primary-dark);
        }

        .marks-cell {
            font-weight: 600;
            font-size: 1.1rem;
        }

        .percentage-cell {
            font-weight: 700;
        }

        .midterm-cell { 
            color: var(--midterm-blue); 
            font-weight: 600;
        }

        .final-cell { 
            color: var(--final-purple); 
            font-weight: 600;
        }

        .total-cell {
            color: var(--primary-dark);
            font-weight: 700;
            font-size: 1.1rem;
        }

        .grade-badge {
            padding: 6px 14px;
            border-radius: 20px;
            font-weight: 700;
            font-size: 0.9rem;
            display: inline-block;
            min-width: 50px;
            text-align: center;
        }

        .grade-a { background: rgba(16, 185, 129, 0.15); color: var(--success); border: 1px solid rgba(16, 185, 129, 0.3); }
        .grade-b { background: rgba(59, 130, 246, 0.15); color: #3b82f6; border: 1px solid rgba(59, 130, 246, 0.3); }
        .grade-c { background: rgba(245, 158, 11, 0.15); color: var(--warning); border: 1px solid rgba(245, 158, 11, 0.3); }
        .grade-d { background: rgba(239, 68, 68, 0.15); color: var(--danger); border: 1px solid rgba(239, 68, 68, 0.3); }
        .grade-f { background: rgba(107, 114, 128, 0.15); color: #6b7280; border: 1px solid rgba(107, 114, 128, 0.3); }

        .position-column {
            text-align: center;
            font-weight: 700;
            min-width: 90px;
        }

        .position-badge-small {
            padding: 4px 12px;
            border-radius: 15px;
            font-weight: 700;
            font-size: 0.8rem;
            display: inline-block;
            text-align: center;
        }

        .pass-fail-column {
            text-align: center;
            font-weight: 700;
            min-width: 90px;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            flex-wrap: wrap;
        }

        .action-btn {
            padding: 12px 25px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
            border: 2px solid transparent;
            cursor: pointer;
            font-size: 0.95rem;
        }

        .print-btn {
            background: var(--gradient);
            color: white;
            border: none;
        }

        .print-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 204, 255, 0.3);
        }

        .back-btn {
            background: var(--white);
            color: var(--primary-dark);
            border-color: var(--medium-gray);
        }

        .back-btn:hover {
            background: var(--light-gray);
            border-color: var(--primary-blue);
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--dark-gray);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            color: var(--medium-gray);
        }

        .empty-state h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: var(--text-dark);
        }

        .empty-state p {
            font-size: 1rem;
            max-width: 500px;
            margin: 0 auto;
        }

        .copy-btn {
            background: none;
            border: none;
            color: var(--primary-blue);
            cursor: pointer;
            padding: 4px 8px;
            border-radius: 4px;
            transition: all 0.3s ease;
        }

        .copy-btn:hover {
            background: rgba(0, 204, 255, 0.1);
        }

        tfoot tr {
            background: rgba(0, 204, 255, 0.05);
            font-weight: 600;
        }

        tfoot td {
            padding: 20px;
            border-top: 2px solid var(--primary-blue);
        }

        .calculation-note {
            margin-top: 20px;
            padding: 15px;
            background: rgba(0, 204, 255, 0.05);
            border-radius: 10px;
            border-left: 4px solid var(--primary-blue);
            font-size: 0.9rem;
            color: var(--dark-gray);
        }

        .position-badge {
            padding: 6px 14px;
            border-radius: 20px;
            font-weight: 700;
            font-size: 0.9rem;
            display: inline-block;
            min-width: 60px;
            text-align: center;
        }

        .position-1 { background: rgba(255, 215, 0, 0.2); color: #ffd700; border: 1px solid rgba(255, 215, 0, 0.3); }
        .position-2 { background: rgba(192, 192, 192, 0.2); color: #c0c0c0; border: 1px solid rgba(192, 192, 192, 0.3); }
        .position-3 { background: rgba(205, 127, 50, 0.2); color: #cd7f32; border: 1px solid rgba(205, 127, 50, 0.3); }
        .position-top { background: rgba(16, 185, 129, 0.15); color: var(--success); border: 1px solid rgba(16, 185, 129, 0.3); }
        .position-middle { background: rgba(59, 130, 246, 0.15); color: #3b82f6; border: 1px solid rgba(59, 130, 246, 0.3); }
        .position-bottom { background: rgba(239, 68, 68, 0.15); color: var(--danger); border: 1px solid rgba(239, 68, 68, 0.3); }

        .subject-pass-fail {
            padding: 5px 10px;
            border-radius: 15px;
            font-weight: 600;
            font-size: 0.8rem;
            display: inline-block;
            min-width: 50px;
            text-align: center;
        }

        /* Autocomplete styles */
        .autocomplete-container {
            position: relative;
            flex: 1;
        }

        .autocomplete-dropdown {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 1px solid #ddd;
            border-radius: 10px;
            max-height: 300px;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-top: 5px;
        }

        .autocomplete-item {
            padding: 12px 15px;
            cursor: pointer;
            border-bottom: 1px solid #f0f0f0;
            transition: all 0.2s ease;
        }

        .autocomplete-item:hover,
        .autocomplete-item.selected {
            background: rgba(0, 204, 255, 0.1);
            border-left: 3px solid #00ccff;
        }

        .autocomplete-item:last-child {
            border-bottom: none;
        }

        /* Loading overlay */
        #loadingOverlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255,255,255,0.9);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            flex-direction: column;
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid #00ccff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Quick navigation */
        .quick-navigation {
            margin-bottom: 20px;
        }

        .quick-navigation .action-btn {
            margin-bottom: 10px;
        }

        /* Quick search buttons */
        .quick-search-buttons {
            display: flex;
            gap: 10px;
            margin-top: 10px;
            flex-wrap: wrap;
        }

        @media (max-width: 1024px) {
            .sidebar {
                width: 80px;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .logo-text,
            .menu-text {
                display: none;
            }
            
            .menu-item {
                justify-content: center;
                padding: 15px;
            }
            
            .menu-item i {
                margin-right: 0;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 0;
                overflow: hidden;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .menu-toggle {
                display: block;
                position: fixed;
                top: 20px;
                left: 20px;
                z-index: 1000;
                background: var(--primary-blue);
                color: white;
                border: none;
                padding: 12px;
                border-radius: 8px;
                cursor: pointer;
                font-size: 1.2rem;
            }
            
            .sidebar.active {
                width: 280px;
                z-index: 999;
            }
            
            .content-container {
                padding: 20px;
            }
            
            .search-form {
                flex-direction: column;
            }
            
            .summary-cards {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .student-info-card {
                grid-template-columns: 1fr;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .action-btn {
                width: 100%;
                justify-content: center;
            }
            
            .section-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .quick-search-buttons {
                justify-content: center;
            }
        }

        @media (max-width: 480px) {
            .summary-cards {
                grid-template-columns: 1fr;
            }
            
            .top-bar {
                flex-direction: column;
                gap: 15px;
                padding: 20px;
                text-align: center;
            }
            
            .user-profile {
                align-self: center;
            }
            
            .result-list {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Loading Overlay -->
    <div id="loadingOverlay">
        <div class="spinner"></div>
        <p style="margin-top: 20px; color: #333; font-weight: 600;">Loading student data...</p>
    </div>

    <button class="menu-toggle" id="menuToggle" style="display: none;">
        <i class="fas fa-bars"></i>
    </button>

    <div class="dashboard-container">
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <div class="logo-text">Group-H</div>
            </div>
            
            <div class="sidebar-menu">
                <a href="admin_dashboard.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="menu-text">Dashboard</span>
                </a>
                
                <a href="../student/manage_students.php" class="menu-item">
                    <i class="fas fa-user-graduate"></i>
                    <span class="menu-text">Students</span>
                </a>
                
                <a href="../teacher/manage_teachers.php" class="menu-item">
                    <i class="fas fa-chalkboard-teacher"></i>
                    <span class="menu-text">Teachers</span>
                </a>
                
                <a href="view_exams.php" class="menu-item active">
                    <i class="fas fa-file-alt"></i>
                    <span class="menu-text">View Exams</span>
                </a>
                
                <a href="create_admin.php" class="menu-item">
                    <i class="fas fa-user-shield"></i>
                    <span class="menu-text">Admins</span>
                </a>
                
                <a href="../index.php" class="menu-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span class="menu-text">Logout</span>
                </a>
            </div>
        </div>

        <div class="main-content">
            <div class="top-bar">
                <div class="page-title">
                    <h1>View Student Exam Results</h1>
                    <p>Search and view detailed exam results for any student</p>
                </div>
                
                <div class="user-menu">
                    <div class="user-profile">
                        <div class="avatar">
                            <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
                        </div>
                        <div class="user-info">
                            <div class="user-name"><?php echo $_SESSION['username']; ?></div>
                            <div class="user-role"><?php echo $_SESSION['role']; ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="content-container">
                <div class="search-section">
                    <div class="search-header">
                        <i class="fas fa-search"></i>
                        <h2>Search Student</h2>
                    </div>
                    
                    <form method="POST" class="search-form" id="searchForm">
                        <div class="autocomplete-container">
                            <input 
                                type="text" 
                                name="search_term" 
                                class="search-input" 
                                placeholder="Enter STU-ID (e.g., 1, 2, STU001) or student name..."
                                value="<?php echo htmlspecialchars($search_term); ?>"
                                id="searchInput"
                                autocomplete="off"
                                autofocus
                            >
                            <div id="autocompleteDropdown" class="autocomplete-dropdown" style="display: none;"></div>
                        </div>
                        
                        <button type="submit" name="search" class="search-btn">
                            <i class="fas fa-search"></i> Search
                        </button>
                    </form>

                    <?php if (!empty($multiple_results)): ?>
                        <div class="multiple-results">
                            <h3><i class="fas fa-users"></i> Multiple Students Found</h3>
                            <p style="color: var(--dark-gray); margin-bottom: 20px;">Click on a student to view their exam results:</p>
                            <div class="result-list">
                                <?php foreach ($multiple_results as $student): ?>
                                    <div class="result-item" onclick="quickSearchStudent('<?php echo urlencode($student['stu_id']); ?>')">
                                        <div style="font-weight: 600; margin-bottom: 8px; color: var(--primary-dark);">
                                            <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                                        </div>
                                        <div style="color: var(--dark-gray); font-size: 0.9rem;">
                                            <div>Grade <?php echo htmlspecialchars($student['grade_level']); ?></div>
                                            <div style="color: var(--primary-blue); margin-top: 5px; font-weight: 600;">
                                                <i class="fas fa-id-card"></i> <?php echo htmlspecialchars($student['stu_id']); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($error)): ?>
                        <div class="message error-message">
                            <i class="fas fa-exclamation-circle"></i>
                            <span><?php echo htmlspecialchars($error); ?></span>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($success) && $student_data): ?>
                        <div class="message success-message">
                            <i class="fas fa-check-circle"></i>
                            <div>
                                <strong>STU-ID Found!</strong>
                                <div style="margin-top: 5px; font-size: 0.95rem;">
                                    Displaying results for: <strong><?php echo htmlspecialchars($student_data['stu_id']); ?></strong>
                                    <span style="color: var(--dark-gray); margin-left: 10px;">
                                        (<?php echo htmlspecialchars($student_data['first_name'] . ' ' . $student_data['last_name']); ?>)
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if ($student_data): ?>
                    <!-- Quick Navigation -->
                    <div class="quick-navigation">
                        <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                            <button onclick="searchAgain()" class="action-btn" style="background: #f0f8ff; color: #0066cc; border: 1px solid #b3e0ff;">
                                <i class="fas fa-redo"></i> Search Another Student
                            </button>
                            
                            <button onclick="copyStudentLink()" class="action-btn" style="background: #f3e5f5; color: #9c27b0; border: 1px solid #ce93d8;">
                                <i class="fas fa-link"></i> Copy Student Link
                            </button>
                            
                            <!-- Quick Search Buttons -->
                            <div class="quick-search-buttons">
                                <small style="color: var(--dark-gray); align-self: center;">Quick Search:</small>
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <button onclick="quickSearch(<?php echo $i; ?>)" class="action-btn" style="padding: 8px 15px; background: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7;">
                                        STU<?php echo str_pad($i, 3, '0', STR_PAD_LEFT); ?>
                                    </button>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>

                    <div class="student-info-card">
                        <div class="info-item">
                            <div class="info-label">Student Name</div>
                            <div class="info-value">
                                <?php echo htmlspecialchars($student_data['first_name'] . ' ' . $student_data['last_name']); ?>
                            </div>
                        </div>
                        
                        <div class="info-item">
                            <div class="info-label">Student ID</div>
                            <div class="info-value">
                                <span class="info-badge" id="stuIdBadge">
                                    <i class="fas fa-id-card"></i> <?php echo htmlspecialchars($student_data['stu_id']); ?>
                                </span>
                                <button class="copy-btn" onclick="copySTUId('<?php echo htmlspecialchars($student_data['stu_id']); ?>')" 
                                        title="Copy STU-ID">
                                    <i class="fas fa-copy"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="info-item">
                            <div class="info-label">Grade Level</div>
                            <div class="info-value">
                                Grade <?php echo htmlspecialchars($student_data['grade_level']); ?>
                            </div>
                        </div>
                        
                        <div class="info-item">
                            <div class="info-label">Class Position</div>
                            <div class="info-value">
                                <?php if (isset($student_position) && $student_position !== 'N/A'): ?>
                                    <?php 
                                    $position_class = '';
                                    if ($student_position == 1) $position_class = 'position-1';
                                    elseif ($student_position == 2) $position_class = 'position-2';
                                    elseif ($student_position == 3) $position_class = 'position-3';
                                    elseif ($student_position <= 10) $position_class = 'position-top';
                                    elseif ($student_position <= 20) $position_class = 'position-middle';
                                    else $position_class = 'position-bottom';
                                    ?>
                                    <span class="position-badge <?php echo $position_class; ?>">
                                        <?php echo $student_position . getPositionSuffix($student_position); ?>
                                        <small style="font-size: 0.8rem; color: var(--dark-gray);">
                                            / <?php echo $class_total_students; ?>
                                        </small>
                                    </span>
                                <?php else: ?>
                                    <span style="color: var(--dark-gray);">N/A</span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="info-item">
                            <div class="info-label">Overall Status</div>
                            <div class="info-value">
                                <span class="pass-fail-status <?php echo $pass_fail_status == 'PASS' ? 'pass-status' : 'fail-status'; ?>">
                                    <i class="fas <?php echo $pass_fail_status == 'PASS' ? 'fa-check-circle' : 'fa-times-circle'; ?>"></i>
                                    <?php echo $pass_fail_status; ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="summary-cards">
                        <div class="summary-card">
                            <div class="summary-icon">
                                <i class="fas fa-file-alt"></i>
                            </div>
                            <div class="summary-number">
                                <?php echo count($exam_results); ?>
                            </div>
                            <div class="summary-label">Total Exams</div>
                        </div>
                        
                        <div class="summary-card">
                            <div class="summary-icon">
                                <i class="fas fa-chart-line"></i>
                            </div>
                            <div class="summary-number">
                                <?php echo number_format($overall_average, 1); ?>%
                            </div>
                            <div class="summary-label">Average Score</div>
                        </div>
                        
                        <div class="summary-card">
                            <div class="summary-icon">
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="summary-number">
                                <?php 
                                    list($grade_letter, $grade_color) = getWeightedGrade($overall_average);
                                    echo $grade_letter;
                                ?>
                            </div>
                            <div class="summary-label">Overall Grade</div>
                        </div>
                        
                        <div class="summary-card">
                            <div class="summary-icon">
                                <i class="fas fa-book"></i>
                            </div>
                            <div class="summary-number">
                                <?php echo count($subject_results); ?>
                            </div>
                            <div class="summary-label">Subjects</div>
                        </div>
                    </div>

                    <div class="results-section">
                        <div class="section-header">
                            <h2><i class="fas fa-table"></i> Exam Results Details (Weighted Scoring)</h2>
                            <div class="action-buttons">
                                <button onclick="printResults()" class="action-btn print-btn">
                                    <i class="fas fa-print"></i> Print Results
                                </button>
                                <a href="view_exams.php" class="action-btn back-btn">
                                    <i class="fas fa-arrow-left"></i> Back to Search
                                </a>
                            </div>
                        </div>
                        
                        <?php if (!empty($subject_results)): ?>
                            <div class="table-container">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Subject</th>
                                            <th>Mid-term (40%)</th>
                                            <th>Final (60%)</th>
                                            <th>Total Score</th>
                                            <th>Grade</th>
                                            <th>Position</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $mid_term_weighted_sum = 0;
                                        $final_weighted_sum = 0;
                                        $total_score_sum = 0;
                                        $subjects_count = 0;
                                        $pass_subjects = 0;
                                        $fail_subjects = 0;
                                        ?>
                                        <?php foreach ($subject_results as $subject => $data): ?>
                                            <?php 
                                            $mid_term_marks = $data['mid_term_marks'];
                                            $mid_term_total = $data['mid_term_total'];
                                            $final_marks = $data['final_marks'];
                                            $final_total = $data['final_total'];
                                            $mid_term_weighted = $data['mid_term_weighted'];
                                            $final_weighted = $data['final_weighted'];
                                            $total_score = $data['total_score'];
                                            $subject_position = $subject_positions[$subject] ?? 'N/A';
                                            
                                            list($grade_letter, $_) = getWeightedGrade($total_score);
                                            $grade_class = strtolower('grade-' . $grade_letter);
                                            
                                            $subject_pass_fail = $total_score >= 60 ? 'PASS' : 'FAIL';
                                            if ($subject_pass_fail == 'PASS') {
                                                $pass_subjects++;
                                            } else {
                                                $fail_subjects++;
                                            }
                                            
                                            if ($mid_term_weighted > 0) {
                                                $mid_term_weighted_sum += $mid_term_weighted;
                                                $final_weighted_sum += $final_weighted;
                                                $total_score_sum += $total_score;
                                                $subjects_count++;
                                            }
                                            ?>
                                            <tr>
                                                <td class="exam-cell"><?php echo htmlspecialchars($subject); ?></td>
                                                <td class="midterm-cell">
                                                    <?php if ($mid_term_marks !== null): ?>
                                                        <?php echo $mid_term_marks; ?> / <?php echo $mid_term_total; ?>
                                                        <div style="font-size: 0.85rem; color: var(--dark-gray); margin-top: 5px;">
                                                            = <?php echo number_format($mid_term_weighted, 1); ?> pts
                                                        </div>
                                                    <?php else: ?>
                                                        <span style="color: #999;">N/A</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="final-cell">
                                                    <?php if ($final_marks !== null): ?>
                                                        <?php echo $final_marks; ?> / <?php echo $final_total; ?>
                                                        <div style="font-size: 0.85rem; color: var(--dark-gray); margin-top: 5px;">
                                                            = <?php echo number_format($final_weighted, 1); ?> pts
                                                        </div>
                                                    <?php else: ?>
                                                        <span style="color: #999;">N/A</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="total-cell">
                                                    <strong><?php echo number_format($total_score, 1); ?> / 100</strong>
                                                </td>
                                                <td>
                                                    <span class="grade-badge <?php echo $grade_class; ?>">
                                                        <?php echo $grade_letter; ?>
                                                    </span>
                                                </td>
                                                <td class="position-column">
                                                    <?php if ($subject_position !== 'N/A'): ?>
                                                        <span class="position-badge-small" style="
                                                            background: <?php echo $subject_position <= 3 ? 'rgba(255, 215, 0, 0.1)' : 'rgba(0, 204, 255, 0.1)'; ?>;
                                                            color: <?php echo $subject_position <= 3 ? '#ffd700' : 'var(--primary-blue)'; ?>;
                                                            border: 1px solid <?php echo $subject_position <= 3 ? 'rgba(255, 215, 0, 0.3)' : 'rgba(0, 204, 255, 0.3)'; ?>;
                                                        ">
                                                            <?php echo $subject_position . getPositionSuffix($subject_position); ?>
                                                        </span>
                                                    <?php else: ?>
                                                        <span style="color: var(--dark-gray);">N/A</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="pass-fail-column">
                                                    <span class="subject-pass-fail" style="
                                                        background: <?php echo $subject_pass_fail == 'PASS' ? 'rgba(16, 185, 129, 0.15)' : 'rgba(239, 68, 68, 0.15)'; ?>;
                                                        color: <?php echo $subject_pass_fail == 'PASS' ? 'var(--success)' : 'var(--danger)'; ?>;
                                                        border: 1px solid <?php echo $subject_pass_fail == 'PASS' ? 'var(--success)' : 'var(--danger)'; ?>;
                                                    ">
                                                        <?php echo $subject_pass_fail; ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td><strong>Overall</strong></td>
                                            <td>
                                                <strong class="midterm-cell">
                                                    <?php if ($subjects_count > 0): ?>
                                                        <?php echo number_format($mid_term_weighted_sum / $subjects_count, 1); ?> pts avg
                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?>
                                                </strong>
                                            </td>
                                            <td>
                                                <strong class="final-cell">
                                                    <?php if ($subjects_count > 0): ?>
                                                        <?php echo number_format($final_weighted_sum / $subjects_count, 1); ?> pts avg
                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?>
                                                </strong>
                                            </td>
                                            <td class="total-cell">
                                                <strong><?php echo number_format($overall_average, 1); ?>%</strong>
                                            </td>
                                            <td>
                                                <?php 
                                                $overall_grade = getWeightedGrade($overall_average);
                                                $overall_grade_class = strtolower('grade-' . $overall_grade[0]);
                                                ?>
                                                <span class="grade-badge <?php echo $overall_grade_class; ?>">
                                                    <?php echo $overall_grade[0]; ?>
                                                </span>
                                            </td>
                                            <td class="position-column">
                                                <?php if (isset($student_position) && $student_position !== 'N/A'): ?>
                                                    <span class="position-badge-small" style="
                                                        background: <?php echo $student_position <= 3 ? 'rgba(255, 215, 0, 0.1)' : 'rgba(0, 204, 255, 0.1)'; ?>;
                                                        color: <?php echo $student_position <= 3 ? '#ffd700' : 'var(--primary-blue)'; ?>;
                                                        border: 1px solid <?php echo $student_position <= 3 ? 'rgba(255, 215, 0, 0.3)' : 'rgba(0, 204, 255, 0.3)'; ?>;
                                                    ">
                                                        <?php echo $student_position . getPositionSuffix($student_position); ?>
                                                    </span>
                                                <?php else: ?>
                                                    <span style="color: var(--dark-gray);">N/A</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="pass-fail-column">
                                                <span class="pass-fail-status <?php echo $pass_fail_status == 'PASS' ? 'pass-status' : 'fail-status'; ?>">
                                                    <?php echo $pass_fail_status; ?>
                                                    <small style="margin-left: 5px; font-size: 0.8rem;">
                                                        (<?php echo $pass_subjects; ?>P/<?php echo $fail_subjects; ?>F)
                                                    </small>
                                                </span>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            
                            <div class="calculation-note">
                                <p><i class="fas fa-info-circle"></i> 
                                    <strong>Calculation Method:</strong> 
                                    Mid-term score = (Marks ÷ Total) × 40
                                    Final score = (Marks ÷ Total) × 60
                                    Total Score = Mid-term + Final (out of 100)
                                    <br><strong>Passing Criteria:</strong> Overall average score ≥ 60% = PASS, < 60% = FAIL
                                </p>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-file-alt"></i>
                                <h3>No Exam Results Found</h3>
                                <p>This student has not taken any exams yet or no results have been entered.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if (!empty($rankings) && count($rankings) > 1): ?>
                    <div class="results-section" style="margin-top: 30px;">
                        <div class="section-header">
                            <h2><i class="fas fa-trophy"></i> Class Ranking (Simple Logic)</h2>
                            <small style="color: var(--dark-gray); font-size: 0.9rem;">
                                Ranking based on AVERAGE SCORE (Highest to Lowest)
                            </small>
                        </div>
                        <div class="table-container">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Position</th>
                                        <th>Student Name</th>
                                        <th>Average Score</th>
                                        <th>Total Score</th>
                                        <th>Subjects</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $stu_ids_map = [];
                                    $stu_id_query = $pdo->query("
                                        SELECT s.id, u.username as stu_id 
                                        FROM students s 
                                        JOIN users u ON s.user_id = u.id
                                    ");
                                    foreach ($stu_id_query->fetchAll() as $row) {
                                        $stu_ids_map[$row['id']] = $row['stu_id'];
                                    }
                                    ?>
                                    
                                    <?php foreach ($rankings as $ranking): ?>
                                        <?php 
                                        $position = $ranking['position'];
                                        $position_class = '';
                                        if ($position == 1) $position_class = 'position-1';
                                        elseif ($position == 2) $position_class = 'position-2';
                                        elseif ($position == 3) $position_class = 'position-3';
                                        
                                        $is_current = $ranking['student_id'] == $student_id;
                                        $stu_id = $stu_ids_map[$ranking['student_id']] ?? 'N/A';
                                        $student_average = $ranking['average_score'];
                                        $student_total = $ranking['total_score'];
                                        $student_subjects = $ranking['subjects_count'];
                                        $student_pass_fail = $ranking['pass_fail'];
                                        ?>
                                        <tr style="<?php echo $is_current ? 'background: rgba(0, 204, 255, 0.1);' : ''; ?>">
                                            <td>
                                                <span style="font-weight: 700; <?php echo $position_class ? "color: $position_class" : ''; ?>">
                                                    <?php echo $position . getPositionSuffix($position); ?>
                                                </span>
                                                <?php if ($is_current): ?>
                                                    <span style="margin-left: 10px; color: var(--primary-blue);">
                                                        <i class="fas fa-user"></i> Current
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo htmlspecialchars($ranking['first_name'] . ' ' . $ranking['last_name']); ?>
                                                <div style="font-size: 0.85rem; color: var(--primary-blue); margin-top: 3px;">
                                                    <i class="fas fa-id-card"></i> <?php echo htmlspecialchars($stu_id); ?>
                                                </div>
                                            </td>
                                            <td>
                                                <strong><?php echo number_format($student_average, 1); ?>%</strong>
                                            </td>
                                            <td>
                                                <?php echo number_format($student_total, 1); ?>
                                            </td>
                                            <td>
                                                <?php echo $student_subjects; ?>
                                            </td>
                                            <td>
                                                <span class="subject-pass-fail" style="
                                                    background: <?php echo $student_pass_fail == 'PASS' ? 'rgba(16, 185, 129, 0.15)' : 'rgba(239, 68, 68, 0.15)'; ?>;
                                                    color: <?php echo $student_pass_fail == 'PASS' ? 'var(--success)' : 'var(--danger)'; ?>;
                                                    border: 1px solid <?php echo $student_pass_fail == 'PASS' ? 'var(--success)' : 'var(--danger)'; ?>;
                                                ">
                                                    <?php echo $student_pass_fail; ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="calculation-note">
                            <p><i class="fas fa-calculator"></i> 
                                <strong>Simple Ranking Logic:</strong> 
                                1. Calculate average score for each student who has exam results
                                2. Sort students by average score (highest to lowest)
                                3. Assign positions: 1st, 2nd, 3rd, etc.
                                4. Handle ties: Students with same average score get same position
                                5. Next position skips tied students (e.g., if 2 students tie for 1st, next is 3rd)
                            </p>
                            <p><strong>Formula:</strong> Average Score = (Sum of all subject weighted scores) ÷ (Number of subjects)</p>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-search"></i>
                        <h3>Search for a Student</h3>
                        <p>Use the search bar above to find a student by STU-ID or name.</p>
                        <p style="margin-top: 15px; color: var(--primary-blue); font-weight: 600;">
                            <i class="fas fa-lightbulb"></i> Tip: Enter numbers (1, 2, 3) for STU-IDs or names for quick results!
                        </p>
                        
                        <?php if (!empty($all_students_dropdown)): ?>
                        <div style="margin-top: 30px; text-align: left; max-width: 600px; margin-left: auto; margin-right: auto;">
                            <h4 style="margin-bottom: 15px; color: var(--primary-dark);">Quick Access Students:</h4>
                            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px;">
                                <?php foreach (array_slice($all_students_dropdown, 0, 8) as $student): ?>
                                    <div class="result-item" onclick="quickSearchStudent('<?php echo urlencode($student['stu_id']); ?>')">
                                        <div style="font-weight: 600; margin-bottom: 8px; color: var(--primary-dark);">
                                            <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                                        </div>
                                        <div style="color: var(--dark-gray); font-size: 0.9rem;">
                                            <div>Grade <?php echo htmlspecialchars($student['grade_level']); ?></div>
                                            <div style="color: var(--primary-blue); margin-top: 5px; font-weight: 600;">
                                                <i class="fas fa-id-card"></i> <?php echo htmlspecialchars($student['stu_id']); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const menuToggle = document.getElementById('menuToggle');
            const sidebar = document.getElementById('sidebar');
            
            if (window.innerWidth <= 768) {
                menuToggle.style.display = 'block';
                
                menuToggle.addEventListener('click', () => {
                    sidebar.classList.toggle('active');
                });
                
                document.addEventListener('click', (e) => {
                    if (!sidebar.contains(e.target) && !menuToggle.contains(e.target) && window.innerWidth <= 768) {
                        sidebar.classList.remove('active');
                    }
                });
            }
            
            window.addEventListener('resize', function() {
                if (window.innerWidth > 768) {
                    menuToggle.style.display = 'none';
                    sidebar.classList.remove('active');
                } else {
                    menuToggle.style.display = 'block';
                }
            });
            
            const tableRows = document.querySelectorAll('tbody tr');
            tableRows.forEach(row => {
                row.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateX(5px)';
                });
                row.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateX(0)';
                });
            });
            
            // Focus on search input when page loads
            const searchInput = document.getElementById('searchInput');
            if (searchInput) {
                searchInput.focus();
                
                // Highlight STU-ID input
                searchInput.addEventListener('input', function() {
                    const value = this.value.toUpperCase();
                    if (value.startsWith('STU') || /^\d+$/.test(value)) {
                        this.style.borderColor = 'var(--success)';
                        this.style.boxShadow = '0 0 0 3px rgba(16, 185, 129, 0.1)';
                    } else {
                        this.style.borderColor = '';
                        this.style.boxShadow = '';
                    }
                });
            }
            
            // Initialize autocomplete
            initAutocomplete();
            
            // Keyboard shortcuts
            initKeyboardShortcuts();
        });

        function copySTUId(stuId) {
            navigator.clipboard.writeText(stuId).then(() => {
                const copyBtn = event.target.closest('.copy-btn');
                if (copyBtn) {
                    const originalHTML = copyBtn.innerHTML;
                    copyBtn.innerHTML = '<i class="fas fa-check"></i>';
                    copyBtn.style.color = 'var(--success)';
                    copyBtn.title = 'Copied!';
                    
                    setTimeout(() => {
                        copyBtn.innerHTML = originalHTML;
                        copyBtn.style.color = '';
                        copyBtn.title = 'Copy STU-ID';
                    }, 2000);
                }
            });
        }

        function copyStudentLink() {
            const currentUrl = window.location.href;
            navigator.clipboard.writeText(currentUrl).then(() => {
                alert('Student link copied to clipboard!');
            });
        }

        function searchAgain() {
            document.getElementById('searchInput').value = '';
            document.getElementById('searchInput').focus();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        function quickSearchStudent(stuId) {
            showLoading();
            window.location.href = `?stu_id=${stuId}`;
        }

        function quickSearch(studentNumber) {
            showLoading();
            const paddedId = studentNumber.toString().padStart(3, '0');
            window.location.href = `?stu_id=${paddedId}`;
        }

        function printResults() {
            const printContent = `
                <html>
                <head>
                    <title>Exam Results - <?php echo $student_data ? $student_data['first_name'] . ' ' . $student_data['last_name'] : 'Student'; ?></title>
                    <style>
                        body { font-family: Arial, sans-serif; padding: 20px; }
                        .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px; }
                        .student-info { margin-bottom: 30px; padding: 20px; background: #f5f5f5; border-radius: 10px; }
                        .info-row { display: flex; margin-bottom: 10px; }
                        .info-label { font-weight: bold; width: 150px; }
                        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
                        th { background-color: #f2f2f2; font-weight: bold; }
                        .summary { display: flex; justify-content: space-between; margin-bottom: 30px; }
                        .summary-box { text-align: center; padding: 20px; border: 1px solid #ddd; border-radius: 10px; width: 23%; }
                        .summary-number { font-size: 24px; font-weight: bold; margin: 10px 0; }
                        .footer { text-align: center; margin-top: 50px; color: #666; font-size: 12px; }
                        .midterm { color: #00ccff; font-weight: bold; }
                        .final { color: #9d4edd; font-weight: bold; }
                        .position-1 { color: #FFD700; font-weight: bold; }
                        .position-2 { color: #C0C0C0; font-weight: bold; }
                        .position-3 { color: #CD7F32; font-weight: bold; }
                        .pass { color: #10b981; font-weight: bold; background: rgba(16, 185, 129, 0.1); padding: 3px 8px; border-radius: 10px; }
                        .fail { color: #ef4444; font-weight: bold; background: rgba(239, 68, 68, 0.1); padding: 3px 8px; border-radius: 10px; }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>Exam Results Report</h1>
                        <p>Generated on: ${new Date().toLocaleDateString()}</p>
                    </div>
                    
                    <?php if ($student_data): ?>
                        <div class="student-info">
                            <div class="info-row">
                                <div class="info-label">Student Name:</div>
                                <div><?php echo htmlspecialchars($student_data['first_name'] . ' ' . $student_data['last_name']); ?></div>
                            </div>
                            <div class="info-row">
                                <div class="info-label">Student ID:</div>
                                <div><?php echo htmlspecialchars($student_data['stu_id']); ?></div>
                            </div>
                            <div class="info-row">
                                <div class="info-label">Grade Level:</div>
                                <div>Grade <?php echo htmlspecialchars($student_data['grade_level']); ?></div>
                            </div>
                            <div class="info-row">
                                <div class="info-label">Class Position:</div>
                                <div>
                                    <?php if (isset($student_position) && $student_position !== 'N/A'): ?>
                                        <?php echo $student_position . getPositionSuffix($student_position); ?> out of <?php echo $class_total_students; ?>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="info-row">
                                <div class="info-label">Average Score:</div>
                                <div><?php echo number_format($overall_average, 1); ?>%</div>
                            </div>
                            <div class="info-row">
                                <div class="info-label">Overall Status:</div>
                                <div>
                                    <span class="<?php echo $pass_fail_status == 'PASS' ? 'pass' : 'fail'; ?>">
                                        <?php echo $pass_fail_status; ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        
                        <h2>Subject-wise Results (Weighted)</h2>
                        <table>
                            <thead>
                                <tr>
                                    <th>Subject</th>
                                    <th>Mid-term (40%)</th>
                                    <th>Final (60%)</th>
                                    <th>Total Score</th>
                                    <th>Grade</th>
                                    <th>Position</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($subject_results as $subject => $data): ?>
                                    <?php 
                                    $mid_term_marks = $data['mid_term_marks'];
                                    $mid_term_total = $data['mid_term_total'];
                                    $final_marks = $data['final_marks'];
                                    $final_total = $data['final_total'];
                                    $mid_term_weighted = $data['mid_term_weighted'];
                                    $final_weighted = $data['final_weighted'];
                                    $total_score = $data['total_score'];
                                    $grade = getWeightedGrade($total_score);
                                    $subject_position = $subject_positions[$subject] ?? 'N/A';
                                    $subject_pass_fail = $total_score >= 60 ? 'PASS' : 'FAIL';
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($subject); ?></td>
                                        <td class="midterm">
                                            <?php if ($mid_term_marks !== null): ?>
                                                <?php echo $mid_term_marks; ?>/<?php echo $mid_term_total; ?>
                                                (<?php echo number_format($mid_term_weighted, 1); ?>pts)
                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>
                                        <td class="final">
                                            <?php if ($final_marks !== null): ?>
                                                <?php echo $final_marks; ?>/<?php echo $final_total; ?>
                                                (<?php echo number_format($final_weighted, 1); ?>pts)
                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo number_format($total_score, 1); ?>/100</td>
                                        <td><?php echo $grade[0]; ?></td>
                                        <td>
                                            <?php if ($subject_position !== 'N/A'): ?>
                                                <?php echo $subject_position . getPositionSuffix($subject_position); ?>
                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="<?php echo $subject_pass_fail == 'PASS' ? 'pass' : 'fail'; ?>">
                                                <?php echo $subject_pass_fail; ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr style="font-weight: bold; background: #f8f9fa;">
                                    <td>Overall</td>
                                    <td>
                                        <?php if ($subjects_count > 0): ?>
                                            <?php echo number_format($mid_term_weighted_sum / $subjects_count, 1); ?> pts
                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($subjects_count > 0): ?>
                                            <?php echo number_format($final_weighted_sum / $subjects_count, 1); ?> pts
                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo number_format($overall_average, 1); ?>%</td>
                                    <td><?php echo getWeightedGrade($overall_average)[0]; ?></td>
                                    <td>
                                        <?php if (isset($student_position) && $student_position !== 'N/A'): ?>
                                            <?php echo $student_position . getPositionSuffix($student_position); ?>
                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="<?php echo $pass_fail_status == 'PASS' ? 'pass' : 'fail'; ?>">
                                            <?php echo $pass_fail_status; ?> (<?php echo $pass_subjects; ?>P/<?php echo $fail_subjects; ?>F)
                                        </span>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                        
                        <div style="margin-top: 30px; padding: 15px; background: #f0f8ff; border-radius: 5px; font-size: 14px;">
                            <p><strong>Note:</strong> Mid-term scores are weighted 40%, Final scores are weighted 60%. 
                            Passing criteria: Overall average score ≥ 60% = PASS, < 60% = FAIL.</p>
                            <p><strong>Ranking Logic:</strong> Students are ranked by average score (highest to lowest). 
                            Ties are handled by giving same position to students with same score.</p>
                        </div>
                    <?php endif; ?>
                    
                    <div class="footer">
                        <p>School Management System - Group-H</p>
                        <p>This is an official exam results report</p>
                    </div>
                </body>
                </html>
            `;
            
            const printWindow = window.open('', '_blank');
            printWindow.document.write(printContent);
            printWindow.document.close();
            printWindow.focus();
            setTimeout(() => {
                printWindow.print();
                printWindow.close();
            }, 500);
        }

        // Autocomplete functionality
        function initAutocomplete() {
            const searchInput = document.getElementById('searchInput');
            const autocompleteDropdown = document.getElementById('autocompleteDropdown');
            let autocompleteTimeout;
            let selectedIndex = -1;

            searchInput.addEventListener('input', function() {
                const query = this.value.trim();
                
                // Clear previous timeout
                clearTimeout(autocompleteTimeout);
                
                // Hide dropdown if query is too short
                if (query.length < 1) {
                    autocompleteDropdown.style.display = 'none';
                    return;
                }
                
                // Set timeout to avoid too many requests
                autocompleteTimeout = setTimeout(() => {
                    fetchAutocompleteResults(query);
                }, 300);
            });

            // Handle arrow key navigation
            searchInput.addEventListener('keydown', function(e) {
                const items = autocompleteDropdown.querySelectorAll('.autocomplete-item');
                
                if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    selectedIndex = Math.min(selectedIndex + 1, items.length - 1);
                    updateSelection(items);
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    selectedIndex = Math.max(selectedIndex - 1, -1);
                    updateSelection(items);
                } else if (e.key === 'Enter' && selectedIndex >= 0) {
                    e.preventDefault();
                    const stuId = items[selectedIndex].getAttribute('data-stu-id');
                    if (stuId) {
                        quickSearchStudent(stuId);
                    }
                } else if (e.key === 'Enter' && this.value.trim().length > 0) {
                    // Submit form
                    document.getElementById('searchForm').submit();
                    showLoading();
                } else if (e.key === 'Tab' && items.length > 0) {
                    // Auto-select first result on Tab
                    e.preventDefault();
                    const stuId = items[0].getAttribute('data-stu-id');
                    if (stuId) {
                        quickSearchStudent(stuId);
                    }
                }
            });

            function updateSelection(items) {
                items.forEach((item, index) => {
                    if (index === selectedIndex) {
                        item.classList.add('selected');
                        item.scrollIntoView({ block: 'nearest' });
                    } else {
                        item.classList.remove('selected');
                    }
                });
            }

            function fetchAutocompleteResults(query) {
                // Show loading indicator in dropdown
                autocompleteDropdown.innerHTML = '<div class="autocomplete-item" style="text-align: center; color: #666;"><i class="fas fa-spinner fa-spin"></i> Loading...</div>';
                autocompleteDropdown.style.display = 'block';
                
                // Simple autocomplete with local data
                const allStudents = <?php echo json_encode($all_students_dropdown); ?>;
                
                if (!allStudents || allStudents.length === 0) {
                    autocompleteDropdown.innerHTML = '<div class="autocomplete-item" style="text-align: center; color: #666;">No students found</div>';
                    return;
                }
                
                const queryLower = query.toLowerCase();
                const results = allStudents.filter(student => {
                    const fullName = (student.first_name + ' ' + student.last_name).toLowerCase();
                    const stuId = student.stu_id.toLowerCase();
                    
                    return fullName.includes(queryLower) || 
                           stuId.includes(queryLower) ||
                           student.first_name.toLowerCase().includes(queryLower) ||
                           student.last_name.toLowerCase().includes(queryLower);
                });
                
                displayAutocompleteResults(results.slice(0, 10));
            }

            function displayAutocompleteResults(results) {
                if (results.length === 0) {
                    autocompleteDropdown.innerHTML = '<div class="autocomplete-item" style="text-align: center; color: #666;">No results found</div>';
                    return;
                }
                
                autocompleteDropdown.innerHTML = '';
                
                // Sort: STU-ID matches first, then name matches
                const stuIdMatches = results.filter(r => 
                    r.stu_id.toLowerCase().includes(searchInput.value.toLowerCase())
                );
                const nameMatches = results.filter(r => 
                    !stuIdMatches.some(s => s.id === r.id)
                );
                
                const allResults = [...stuIdMatches, ...nameMatches];
                
                allResults.forEach((result, index) => {
                    const item = document.createElement('div');
                    item.className = 'autocomplete-item';
                    item.setAttribute('data-stu-id', result.stu_id);
                    item.innerHTML = `
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div style="flex: 1;">
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div style="width: 40px; height: 40px; background: #00ccff; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold;">
                                        ${result.first_name.charAt(0)}${result.last_name.charAt(0)}
                                    </div>
                                    <div>
                                        <strong>${result.first_name} ${result.last_name}</strong>
                                        <div style="font-size: 0.9rem; color: #666;">
                                            <span style="color: #00ccff; font-weight: 600;">${result.stu_id}</span> | Grade ${result.grade_level}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div style="color: #00ccff; font-size: 0.9rem;">
                                <i class="fas fa-arrow-right"></i>
                            </div>
                        </div>
                    `;
                    
                    item.addEventListener('click', () => {
                        quickSearchStudent(result.stu_id);
                    });
                    
                    autocompleteDropdown.appendChild(item);
                });
                
                autocompleteDropdown.style.display = 'block';
                selectedIndex = -1;
            }

            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!searchInput.contains(e.target) && !autocompleteDropdown.contains(e.target)) {
                    autocompleteDropdown.style.display = 'none';
                }
            });

            // Focus search input on page load
            searchInput.focus();
            
            // Auto-open dropdown if there's text
            if (searchInput.value.length > 0) {
                searchInput.dispatchEvent(new Event('input'));
            }
        }

        // Keyboard shortcuts
        function initKeyboardShortcuts() {
            document.addEventListener('keydown', function(e) {
                // Alt + Number for quick student access (Alt+1, Alt+2, etc.)
                if (e.altKey && e.key >= '1' && e.key <= '5') {
                    e.preventDefault();
                    const studentNumber = parseInt(e.key);
                    quickSearch(studentNumber);
                }
                
                // Ctrl/Cmd + F to focus search
                if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                    e.preventDefault();
                    const searchInput = document.getElementById('searchInput');
                    searchInput.focus();
                    searchInput.select();
                }
                
                // Escape to clear search
                if (e.key === 'Escape') {
                    const searchInput = document.getElementById('searchInput');
                    if (document.activeElement === searchInput) {
                        searchInput.value = '';
                        document.getElementById('autocompleteDropdown').style.display = 'none';
                    }
                }
                
                // F5 to refresh with current student
                if (e.key === 'F5' && <?php echo $student_data ? 'true' : 'false'; ?>) {
                    e.preventDefault();
                    window.location.href = window.location.href;
                }
                
                // Ctrl/Cmd + P to print
                if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
                    e.preventDefault();
                    printResults();
                }
            });
        }

        // Loading functions
        function showLoading() {
            document.getElementById('loadingOverlay').style.display = 'flex';
        }

        function hideLoading() {
            document.getElementById('loadingOverlay').style.display = 'none';
        }

        // Show loading when submitting form
        document.getElementById('searchForm').addEventListener('submit', function() {
            showLoading();
        });

        // Show loading when clicking autocomplete or result items
        document.querySelectorAll('.autocomplete-item, .result-item').forEach(item => {
            item.addEventListener('click', function() {
                showLoading();
            });
        });

        // Hide loading when page is fully loaded
        window.addEventListener('load', function() {
            setTimeout(hideLoading, 500);
        });
    </script>
</body>
</html>