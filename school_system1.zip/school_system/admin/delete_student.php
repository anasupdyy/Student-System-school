<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../index.php');
    exit();
}

if (isset($_GET['id'])) {
    $student_id = $_GET['id'];
    
    try {
        $pdo->beginTransaction();
        
        // Get user_id first
        $stmt = $pdo->prepare("SELECT user_id FROM students WHERE id = ?");
        $stmt->execute([$student_id]);
        $student = $stmt->fetch();
        
        if ($student) {
            // Delete from students table
            $stmt = $pdo->prepare("DELETE FROM students WHERE id = ?");
            $stmt->execute([$student_id]);
            
            // Delete from users table
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$student['user_id']]);
            
            $pdo->commit();
            $_SESSION['success'] = "Student deleted successfully!";
        } else {
            $_SESSION['error'] = "Student not found!";
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Error deleting student: " . $e->getMessage();
    }
    
    header('Location: manage_students.php');
    exit();
}
?>