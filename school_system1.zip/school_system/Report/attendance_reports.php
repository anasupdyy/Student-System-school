<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../index.php');
    exit();
}

// الحصول على المعلمات من URL
$grade = isset($_GET['grade']) ? $_GET['grade'] : 'all';
$status = isset($_GET['status']) ? $_GET['status'] : 'all';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-d', strtotime('-7 days'));
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : date('Y-m-d');
$export = isset($_GET['export']) ? true : false;

// بناء استعلام SQL ديناميكي
$where_conditions = ["DATE(a.date) BETWEEN :date_from AND :date_to"];
$params = [
    ':date_from' => $date_from,
    ':date_to' => $date_to
];

if ($grade != 'all') {
    $where_conditions[] = "s.grade_level = :grade";
    $params[':grade'] = $grade;
}

if ($status != 'all') {
    $where_conditions[] = "a.status = :status";
    $params[':status'] = $status;
}

$where_clause = implode(' AND ', $where_conditions);

// إحصائيات عامة
$total_students = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();

// الحصول على أحدث سجل حضور لكل طالب في كل يوم (المنطق الصحيح)
$attendance_stats_query = "
    SELECT 
        DATE(a.date) as attendance_date,
        COUNT(DISTINCT a.student_id) as total_students,
        SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_count,
        SUM(CASE WHEN a.status = 'absent' THEN 1 ELSE 0 END) as absent_count,
        SUM(CASE WHEN a.status = 'late' THEN 1 ELSE 0 END) as late_count
    FROM (
        SELECT student_id, status, DATE(date) as date,
               ROW_NUMBER() OVER (PARTITION BY student_id, DATE(date) ORDER BY date DESC) as rn
        FROM attendance
        WHERE DATE(date) BETWEEN :date_from AND :date_to
    ) a
    JOIN students s ON a.student_id = s.id
    WHERE a.rn = 1
    " . ($grade != 'all' ? " AND s.grade_level = :grade" : "") . "
    " . ($status != 'all' ? " AND a.status = :status" : "") . "
    GROUP BY DATE(a.date)
    ORDER BY attendance_date DESC
";

$stmt = $pdo->prepare($attendance_stats_query);
$stmt->execute($params);
$attendance_stats = $stmt->fetchAll();

// بيانات التفاصيل مع أحدث سجل لكل طالب
$details_query = "
    SELECT 
        a.*,
        s.first_name,
        s.last_name,
        s.grade_level,
        s.roll_number,
        DATE(a.date) as attendance_date,
        TIME(a.date) as attendance_time
    FROM (
        SELECT *,
               ROW_NUMBER() OVER (PARTITION BY student_id, DATE(date) ORDER BY date DESC) as rn
        FROM attendance
        WHERE DATE(date) BETWEEN :date_from AND :date_to
    ) a
    JOIN students s ON a.student_id = s.id
    WHERE a.rn = 1
    " . ($grade != 'all' ? " AND s.grade_level = :grade" : "") . "
    " . ($status != 'all' ? " AND a.status = :status" : "") . "
    ORDER BY a.date DESC, s.grade_level, s.roll_number
";

$stmt = $pdo->prepare($details_query);
$stmt->execute($params);
$attendance_details = $stmt->fetchAll();

// الحصول على قائمة الصفوف
$grades = $pdo->query("SELECT DISTINCT grade_level FROM students ORDER BY grade_level")->fetchAll();

// إحصائيات حسب الصفوف (مع المنطق الصحيح)
$grade_stats_query = "
    SELECT 
        s.grade_level,
        COUNT(DISTINCT s.id) as total_students,
        COUNT(DISTINCT CASE WHEN latest_status.status = 'present' THEN s.id END) as present_count,
        COUNT(DISTINCT CASE WHEN latest_status.status = 'absent' THEN s.id END) as absent_count,
        COUNT(DISTINCT CASE WHEN latest_status.status = 'late' THEN s.id END) as late_count
    FROM students s
    LEFT JOIN (
        SELECT a.student_id, a.status,
               ROW_NUMBER() OVER (PARTITION BY a.student_id, DATE(a.date) ORDER BY a.date DESC) as rn
        FROM attendance a
        WHERE DATE(a.date) = CURDATE()
    ) latest_status ON s.id = latest_status.student_id AND latest_status.rn = 1
    GROUP BY s.grade_level
    ORDER BY s.grade_level
";

$stmt = $pdo->prepare($grade_stats_query);
$stmt->execute();
$grade_stats = $stmt->fetchAll();

// إحصائيات إضافية
$daily_stats_query = "
    SELECT 
        DATE(date) as day,
        COUNT(DISTINCT student_id) as total_students,
        SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present,
        SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent,
        SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late
    FROM (
        SELECT *,
               ROW_NUMBER() OVER (PARTITION BY student_id, DATE(date) ORDER BY date DESC) as rn
        FROM attendance
        WHERE DATE(date) BETWEEN :date_from AND :date_to
    ) a
    WHERE rn = 1
    GROUP BY DATE(date)
    ORDER BY day DESC
    LIMIT 7
";

$stmt = $pdo->prepare($daily_stats_query);
$stmt->execute([':date_from' => $date_from, ':date_to' => $date_to]);
$daily_stats = $stmt->fetchAll();

// تصدير البيانات إلى Excel إذا طلب
if ($export) {
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="attendance_report_' . date('Y-m-d') . '.xls"');
    
    echo "<table border='1'>";
    echo "<tr><th colspan='6'>Attendance Report - " . date('Y-m-d') . "</th></tr>";
    echo "<tr><th>Date</th><th>Student Name</th><th>Grade</th><th>Roll No</th><th>Status</th><th>Time</th></tr>";
    
    foreach ($attendance_details as $record) {
        echo "<tr>";
        echo "<td>" . $record['attendance_date'] . "</td>";
        echo "<td>" . $record['first_name'] . " " . $record['last_name'] . "</td>";
        echo "<td>Grade " . $record['grade_level'] . "</td>";
        echo "<td>" . $record['roll_number'] . "</td>";
        echo "<td>" . ucfirst($record['status']) . "</td>";
        echo "<td>" . $record['attendance_time'] . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Group-H - Attendance Analytics Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.css">
    <style>
        :root {
            --primary-dark: #0a192f;
            --primary-blue: #00ccff;
            --primary-purple: #8a2be2;
            --white: #ffffff;
            --light-gray: #f8fafc;
            --text-dark: #1e293b;
            --text-light: #64748b;
            --success: #00cc7a;
            --warning: #ff9d00;
            --danger: #ff4757;
            --gradient: linear-gradient(135deg, #00ccff 0%, #8a2be2 100%);
            --gradient-success: linear-gradient(135deg, #00cc7a 0%, #00b368 100%);
            --gradient-danger: linear-gradient(135deg, #ff4757 0%, #ff2e43 100%);
            --gradient-warning: linear-gradient(135deg, #ff9d00 0%, #ff7e00 100%);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            color: var(--text-dark);
            min-height: 100vh;
        }

        /* Layout Container */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--primary-dark);
            color: var(--white);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            transition: all 0.3s ease;
            z-index: 100;
            box-shadow: 2px 0 20px rgba(0, 0, 0, 0.2);
            background: linear-gradient(180deg, var(--primary-dark) 0%, #1a365d 100%);
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(10px);
        }

        .logo {
            width: 70px;
            height: 70px;
            background: var(--gradient);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 2rem;
            animation: pulse 2s infinite;
            box-shadow: 0 5px 20px rgba(0, 204, 255, 0.3);
        }

        .logo-text {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--white);
            letter-spacing: 1px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }

        .sidebar-menu {
            padding: 25px 0;
        }

        .menu-item {
            display: flex;
            align-items: center;
            padding: 18px 25px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            border-left: 4px solid transparent;
            transition: all 0.3s ease;
            margin: 8px 15px;
            border-radius: 12px;
            position: relative;
            backdrop-filter: blur(5px);
            background: rgba(255, 255, 255, 0.05);
        }

        .menu-item:hover {
            background: rgba(0, 204, 255, 0.2);
            color: var(--white);
            transform: translateX(10px);
            border-left: 4px solid var(--primary-blue);
            box-shadow: 0 5px 15px rgba(0, 204, 255, 0.2);
        }

        .menu-item.active {
            background: linear-gradient(90deg, rgba(0, 204, 255, 0.3), rgba(138, 43, 226, 0.2));
            color: var(--white);
            border-left: 4px solid var(--primary-blue);
            box-shadow: 0 5px 15px rgba(0, 204, 255, 0.2);
        }

        .menu-item i {
            margin-right: 15px;
            font-size: 1.3rem;
            width: 25px;
            text-align: center;
        }

        .menu-text {
            flex: 1;
            font-weight: 500;
            font-size: 1.05rem;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Top Bar */
        .top-bar {
            background: var(--white);
            padding: 20px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95);
        }

        .page-title h1 {
            font-size: 2rem;
            color: var(--primary-dark);
            margin-bottom: 5px;
            font-weight: 700;
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .page-title p {
            color: var(--text-light);
            font-size: 1.05rem;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            padding: 10px 20px;
            border-radius: 30px;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            transition: all 0.3s ease;
            cursor: pointer;
            border: 1px solid rgba(0, 0, 0, 0.05);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }

        .user-profile:hover {
            background: var(--gradient);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 204, 255, 0.3);
        }

        .avatar {
            width: 50px;
            height: 50px;
            background: var(--gradient);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            font-weight: 600;
            margin-right: 15px;
            box-shadow: 0 4px 12px rgba(0, 204, 255, 0.3);
        }

        .user-info {
            display: flex;
            flex-direction: column;
        }

        .user-name {
            font-weight: 600;
            color: var(--primary-dark);
            font-size: 1.1rem;
        }

        .user-role {
            font-size: 0.9rem;
            color: var(--text-light);
            text-transform: capitalize;
        }

        /* Filter Section */
        .filter-section {
            background: var(--white);
            margin: 25px 30px;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(0, 0, 0, 0.05);
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95);
            animation: slideDown 0.5s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .filter-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 25px;
            align-items: end;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .form-group label {
            font-weight: 600;
            color: var(--text-dark);
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-group label i {
            color: var(--primary-blue);
        }

        .form-control {
            padding: 14px 18px;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            font-size: 1.05rem;
            transition: all 0.3s ease;
            background: var(--white);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.03);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 4px rgba(0, 204, 255, 0.15);
        }

        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 15px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 14px 28px;
            border: none;
            border-radius: 12px;
            font-size: 1.05rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.5s;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary {
            background: var(--gradient);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 204, 255, 0.4);
        }

        .btn-secondary {
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            color: var(--text-dark);
            border: 1px solid rgba(0, 0, 0, 0.1);
        }

        .btn-secondary:hover {
            background: #e2e8f0;
            transform: translateY(-2px);
        }

        .btn-success {
            background: var(--gradient-success);
            color: white;
        }

        .btn-success:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 204, 122, 0.4);
        }

        .btn-danger {
            background: var(--gradient-danger);
            color: white;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin: 0 30px 30px;
        }

        .stat-card {
            background: var(--white);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
            display: flex;
            flex-direction: column;
            transition: all 0.4s ease;
            border: 1px solid rgba(0, 0, 0, 0.05);
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.9);
            animation: fadeInUp 0.6s ease-out;
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: var(--gradient);
            z-index: 1;
        }

        .stat-card:hover {
            transform: translateY(-8px) scale(1.02);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }

        .stat-present::before {
            background: var(--gradient-success);
        }

        .stat-absent::before {
            background: var(--gradient-danger);
        }

        .stat-late::before {
            background: var(--gradient-warning);
        }

        .stat-total::before {
            background: var(--gradient);
        }

        .stat-icon {
            width: 70px;
            height: 70px;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            margin-bottom: 25px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        .stat-total .stat-icon {
            background: linear-gradient(135deg, rgba(0, 204, 255, 0.1), rgba(138, 43, 226, 0.1));
            color: var(--primary-blue);
        }

        .stat-present .stat-icon {
            background: linear-gradient(135deg, rgba(0, 204, 122, 0.1), rgba(0, 179, 104, 0.1));
            color: var(--success);
        }

        .stat-absent .stat-icon {
            background: linear-gradient(135deg, rgba(255, 71, 87, 0.1), rgba(255, 46, 67, 0.1));
            color: var(--danger);
        }

        .stat-late .stat-icon {
            background: linear-gradient(135deg, rgba(255, 157, 0, 0.1), rgba(255, 126, 0, 0.1));
            color: var(--warning);
        }

        .stat-number {
            font-size: 3rem;
            font-weight: 800;
            color: var(--primary-dark);
            margin-bottom: 8px;
            font-family: 'Poppins', sans-serif;
        }

        .stat-label {
            color: var(--text-light);
            font-size: 1.1rem;
            margin-bottom: 15px;
            font-weight: 500;
        }

        .stat-trend {
            font-size: 1rem;
            color: var(--success);
            display: flex;
            align-items: center;
            gap: 8px;
            padding-top: 15px;
            border-top: 2px solid rgba(0, 0, 0, 0.05);
            font-weight: 600;
        }

        .stat-trend i {
            font-size: 1.2rem;
        }

        /* Charts Section */
        .charts-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin: 0 30px 30px;
        }

        @media (max-width: 1200px) {
            .charts-section {
                grid-template-columns: 1fr;
            }
        }

        .chart-card {
            background: var(--white);
            border-radius: 20px;
            padding: 35px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(0, 0, 0, 0.05);
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.9);
            animation: fadeIn 0.8s ease-out;
        }

        .chart-card h2 {
            color: var(--primary-dark);
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 15px;
            font-size: 1.5rem;
            font-weight: 700;
            padding-bottom: 20px;
            border-bottom: 2px solid rgba(0, 0, 0, 0.05);
        }

        .chart-container {
            position: relative;
            height: 350px;
        }

        /* Report Table */
        .report-section {
            background: var(--white);
            margin: 0 30px 30px;
            padding: 35px;
            border-radius: 20px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(0, 0, 0, 0.05);
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.9);
            animation: fadeIn 1s ease-out;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid rgba(0, 0, 0, 0.05);
        }

        .section-header h2 {
            color: var(--primary-dark);
            display: flex;
            align-items: center;
            gap: 15px;
            font-size: 1.5rem;
            font-weight: 700;
        }

        .table-responsive {
            overflow-x: auto;
            border-radius: 15px;
            border: 1px solid rgba(0, 0, 0, 0.05);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        }

        .data-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            min-width: 1000px;
        }

        .data-table th {
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            padding: 20px 15px;
            text-align: left;
            font-weight: 700;
            color: var(--primary-dark);
            border-bottom: 2px solid rgba(0, 0, 0, 0.05);
            font-size: 1.05rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .data-table th:first-child {
            border-top-left-radius: 15px;
        }

        .data-table th:last-child {
            border-top-right-radius: 15px;
        }

        .data-table td {
            padding: 18px 15px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            vertical-align: middle;
            font-size: 1.05rem;
        }

        .data-table tbody tr {
            transition: all 0.3s ease;
            background: var(--white);
        }

        .data-table tbody tr:hover {
            background: linear-gradient(90deg, rgba(0, 204, 255, 0.05), rgba(138, 43, 226, 0.03));
            transform: translateX(5px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        }

        .status-badge {
            padding: 10px 20px;
            border-radius: 20px;
            font-size: 0.95rem;
            font-weight: 700;
            display: inline-block;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .badge-present {
            background: var(--gradient-success);
            color: white;
        }

        .badge-absent {
            background: var(--gradient-danger);
            color: white;
        }

        .badge-late {
            background: var(--gradient-warning);
            color: white;
        }

        .no-data {
            text-align: center;
            padding: 60px;
            color: var(--text-light);
        }

        .no-data i {
            font-size: 4rem;
            margin-bottom: 20px;
            display: block;
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            opacity: 0.5;
        }

        .no-data h3 {
            font-size: 1.8rem;
            margin-bottom: 15px;
            color: var(--text-dark);
        }

        /* Footer */
        footer {
            background: linear-gradient(180deg, var(--primary-dark) 0%, #1a365d 100%);
            color: rgba(255, 255, 255, 0.8);
            padding: 30px;
            margin-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .footer-text p {
            font-size: 1.1rem;
        }

        .live-time {
            display: flex;
            align-items: center;
            gap: 15px;
            font-size: 1.2rem;
            background: rgba(255, 255, 255, 0.1);
            padding: 12px 25px;
            border-radius: 30px;
            backdrop-filter: blur(10px);
        }

        .time-icon {
            color: var(--primary-blue);
            font-size: 1.3rem;
        }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 30px;
            padding-top: 25px;
            border-top: 2px solid rgba(0, 0, 0, 0.05);
        }

        .page-link {
            padding: 12px 18px;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            color: var(--text-dark);
            text-decoration: none;
            border-radius: 10px;
            font-weight: 700;
            transition: all 0.3s ease;
            border: 1px solid rgba(0, 0, 0, 0.1);
            min-width: 45px;
            text-align: center;
        }

        .page-link:hover {
            background: var(--gradient);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 204, 255, 0.3);
        }

        .page-link.active {
            background: var(--gradient);
            color: white;
            box-shadow: 0 5px 15px rgba(0, 204, 255, 0.3);
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes pulse {
            0%, 100% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
            }
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
            }
            
            .sidebar-header {
                padding: 20px 15px;
            }
            
            .logo-text,
            .menu-text {
                display: none;
            }
            
            .menu-item {
                justify-content: center;
                padding: 15px;
            }
            
            .menu-item i {
                margin-right: 0;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 0;
                overflow: hidden;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .menu-toggle {
                display: block;
                position: fixed;
                top: 20px;
                left: 20px;
                z-index: 1000;
                background: var(--gradient);
                color: white;
                border: none;
                padding: 12px;
                border-radius: 12px;
                cursor: pointer;
                font-size: 1.2rem;
                box-shadow: 0 4px 15px rgba(0, 204, 255, 0.3);
            }
            
            .sidebar.active {
                width: 280px;
                z-index: 999;
            }
            
            .top-bar {
                flex-direction: column;
                gap: 20px;
                padding: 20px;
            }
            
            .filter-form {
                grid-template-columns: 1fr;
            }
            
            .charts-section,
            .stats-grid {
                margin: 0 20px 20px;
            }
            
            .report-section,
            .filter-section {
                margin: 20px;
                padding: 20px;
            }
            
            .stat-number {
                font-size: 2.5rem;
            }
        }

        @media (max-width: 480px) {
            .page-title h1 {
                font-size: 1.5rem;
            }
            
            .section-header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
            
            .form-actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
            
            .footer-content {
                flex-direction: column;
                gap: 20px;
                text-align: center;
            }
        }

        /* Glowing Effects */
        .glow {
            animation: glow 2s ease-in-out infinite alternate;
        }

        @keyframes glow {
            from {
                box-shadow: 0 0 10px rgba(0, 204, 255, 0.5);
            }
            to {
                box-shadow: 0 0 20px rgba(0, 204, 255, 0.8), 0 0 30px rgba(138, 43, 226, 0.6);
            }
        }

        /* Tooltips */
        .tooltip {
            position: relative;
            display: inline-block;
        }

        .tooltip .tooltip-text {
            visibility: hidden;
            width: 200px;
            background-color: var(--primary-dark);
            color: white;
            text-align: center;
            border-radius: 10px;
            padding: 10px;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            left: 50%;
            transform: translateX(-50%);
            opacity: 0;
            transition: opacity 0.3s;
            font-size: 0.9rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .tooltip:hover .tooltip-text {
            visibility: visible;
            opacity: 1;
        }
    </style>
</head>
<body>
    <!-- Mobile Menu Toggle -->
    <button class="menu-toggle" id="menuToggle" style="display: none;">
        <i class="fas fa-bars"></i>
    </button>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo glow">
                    <i class="fas fa-chart-bar"></i>
                </div>
                <div class="logo-text">Analytics Hub</div>
            </div>
            
            <div class="sidebar-menu">
                <a href="admin_dashboard.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="menu-text">Dashboard</span>
                </a>
                
                <a href="../student/manage_students.php" class="menu-item">
                    <i class="fas fa-user-graduate"></i>
                    <span class="menu-text">Students</span>
                </a>
                
                <a href="../teacher/manage_teachers.php" class="menu-item">
                    <i class="fas fa-chalkboard-teacher"></i>
                    <span class="menu-text">Teachers</span>
                </a>
                
                <a href="admin_view_exams.php" class="menu-item">
                    <i class="fas fa-file-alt"></i>
                    <span class="menu-text">Exams</span>
                </a>
                
                <a href="attendance_reports.php" class="menu-item active">
                    <i class="fas fa-chart-line"></i>
                    <span class="menu-text">Analytics</span>
                </a>
                
                <a href="../teacher/take_attendance.php" class="menu-item">
                    <i class="fas fa-clipboard-check"></i>
                    <span class="menu-text">Take Attendance</span>
                </a>
                
                <a href="../index.php" class="menu-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span class="menu-text">Logout</span>
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Bar -->
            <div class="top-bar">
                <div class="page-title">
                    <h1>Attendance Analytics Dashboard</h1>
                    <p>Advanced insights and comprehensive attendance analysis</p>
                </div>
                
                <div class="user-menu">
                    <div class="user-profile">
                        <div class="avatar">
                            <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
                        </div>
                        <div class="user-info">
                            <div class="user-name"><?php echo $_SESSION['username']; ?></div>
                            <div class="user-role"><?php echo $_SESSION['role']; ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filter Section -->
            <div class="filter-section">
                <form method="GET" class="filter-form">
                    <div class="form-group">
                        <label for="grade"><i class="fas fa-layer-group"></i> Grade Level</label>
                        <select name="grade" id="grade" class="form-control">
                            <option value="all" <?php echo $grade == 'all' ? 'selected' : ''; ?>>All Grades</option>
                            <?php foreach($grades as $g): ?>
                                <option value="<?php echo $g['grade_level']; ?>" <?php echo $grade == $g['grade_level'] ? 'selected' : ''; ?>>
                                    Grade <?php echo $g['grade_level']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="status"><i class="fas fa-clipboard-check"></i> Attendance Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="all" <?php echo $status == 'all' ? 'selected' : ''; ?>>All Statuses</option>
                            <option value="present" <?php echo $status == 'present' ? 'selected' : ''; ?><i class="fas fa-check-circle"></i> Present</option>
                            <option value="absent" <?php echo $status == 'absent' ? 'selected' : ''; ?><i class="fas fa-times-circle"></i> Absent</option>
                            <option value="late" <?php echo $status == 'late' ? 'selected' : ''; ?><i class="fas fa-clock"></i> Late</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="date_from"><i class="fas fa-calendar-alt"></i> From Date</label>
                        <input type="date" name="date_from" id="date_from" class="form-control" value="<?php echo $date_from; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="date_to"><i class="fas fa-calendar-check"></i> To Date</label>
                        <input type="date" name="date_to" id="date_to" class="form-control" value="<?php echo $date_to; ?>">
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-filter"></i> Filter Analytics
                        </button>
                        <a href="?export=true&grade=<?php echo $grade; ?>&status=<?php echo $status; ?>&date_from=<?php echo $date_from; ?>&date_to=<?php echo $date_to; ?>" class="btn btn-success">
                            <i class="fas fa-file-excel"></i> Export Report
                        </a>
                        <button type="reset" onclick="window.location.href='attendance_reports.php'" class="btn btn-secondary">
                            <i class="fas fa-redo"></i> Reset Filters
                        </button>
                    </div>
                </form>
            </div>

            <!-- Statistics Cards -->
            <div class="stats-grid">
                <?php
                // حساب الإحصائيات الإجمالية
                $total_records = 0;
                $total_present = 0;
                $total_absent = 0;
                $total_late = 0;
                
                foreach($attendance_stats as $stat) {
                    $total_records += $stat['total_students'];
                    $total_present += $stat['present_count'];
                    $total_absent += $stat['absent_count'];
                    $total_late += $stat['late_count'];
                }
                
                $attendance_rate = $total_records > 0 ? round(($total_present / $total_records) * 100, 1) : 0;
                $average_daily = count($attendance_stats) > 0 ? round($total_records / count($attendance_stats)) : 0;
                ?>
                
                <div class="stat-card stat-total animate__animated animate__fadeInUp">
                    <div class="stat-icon"><i class="fas fa-clipboard-list"></i></div>
                    <div class="stat-number"><?php echo number_format($total_records); ?></div>
                    <div class="stat-label">Total Attendance Records</div>
                    <div class="stat-trend">
                        <i class="fas fa-calendar-alt"></i> 
                        <?php echo date('M d, Y', strtotime($date_from)); ?> - <?php echo date('M d, Y', strtotime($date_to)); ?>
                    </div>
                </div>
                
                <div class="stat-card stat-present animate__animated animate__fadeInUp animate__delay-1s">
                    <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                    <div class="stat-number"><?php echo number_format($total_present); ?></div>
                    <div class="stat-label">Present Students</div>
                    <div class="stat-trend">
                        <i class="fas fa-chart-line"></i> 
                        <?php echo $attendance_rate; ?>% Attendance Rate
                    </div>
                </div>
                
                <div class="stat-card stat-absent animate__animated animate__fadeInUp animate__delay-2s">
                    <div class="stat-icon"><i class="fas fa-times-circle"></i></div>
                    <div class="stat-number"><?php echo number_format($total_absent); ?></div>
                    <div class="stat-label">Absent Students</div>
                    <div class="stat-trend">
                        <i class="fas fa-exclamation-triangle"></i> 
                        <?php echo $total_records > 0 ? round(($total_absent / $total_records) * 100, 1) : 0; ?>% Absence Rate
                    </div>
                </div>
                
                <div class="stat-card stat-late animate__animated animate__fadeInUp animate__delay-3s">
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                    <div class="stat-number"><?php echo number_format($total_late); ?></div>
                    <div class="stat-label">Late Arrivals</div>
                    <div class="stat-trend">
                        <i class="fas fa-running"></i> 
                        <?php echo $total_records > 0 ? round(($total_late / $total_records) * 100, 1) : 0; ?>% Late Rate
                    </div>
                </div>
            </div>

            <!-- Charts Section -->
            <div class="charts-section">
                <div class="chart-card">
                    <h2><i class="fas fa-chart-pie"></i> Attendance Distribution</h2>
                    <div class="chart-container">
                        <canvas id="attendanceChart"></canvas>
                    </div>
                </div>
                
                <div class="chart-card">
                    <h2><i class="fas fa-chart-bar"></i> Attendance by Grade Level</h2>
                    <div class="chart-container">
                        <canvas id="gradeChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Weekly Stats -->
            <div class="report-section">
                <div class="section-header">
                    <h2><i class="fas fa-calendar-week"></i> Weekly Attendance Trend</h2>
                </div>
                
                <?php if(!empty($daily_stats)): ?>
                    <div style="overflow-x: auto; margin-top: 20px;">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Total Students</th>
                                    <th>Present</th>
                                    <th>Absent</th>
                                    <th>Late</th>
                                    <th>Attendance Rate</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($daily_stats as $daily): 
                                    $daily_rate = $daily['total_students'] > 0 ? round(($daily['present'] / $daily['total_students']) * 100, 1) : 0;
                                ?>
                                    <tr>
                                        <td><strong><?php echo date('D, M d', strtotime($daily['day'])); ?></strong></td>
                                        <td><?php echo $daily['total_students']; ?></td>
                                        <td>
                                            <span class="status-badge badge-present"><?php echo $daily['present']; ?></span>
                                        </td>
                                        <td>
                                            <span class="status-badge badge-absent"><?php echo $daily['absent']; ?></span>
                                        </td>
                                        <td>
                                            <span class="status-badge badge-late"><?php echo $daily['late']; ?></span>
                                        </td>
                                        <td>
                                            <div style="display: flex; align-items: center; gap: 10px;">
                                                <div style="flex: 1; height: 8px; background: #e2e8f0; border-radius: 4px; overflow: hidden;">
                                                    <div style="width: <?php echo $daily_rate; ?>%; height: 100%; background: var(--gradient-success); border-radius: 4px;"></div>
                                                </div>
                                                <span style="font-weight: 700; color: <?php echo $daily_rate >= 90 ? 'var(--success)' : ($daily_rate >= 70 ? 'var(--warning)' : 'var(--danger)'); ?>">
                                                    <?php echo $daily_rate; ?>%
                                                </span>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="no-data">
                        <i class="fas fa-chart-line"></i>
                        <h3>No weekly data available</h3>
                        <p>Select a date range to view attendance trends</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Detailed Report -->
            <div class="report-section">
                <div class="section-header">
                    <h2><i class="fas fa-list-alt"></i> Detailed Attendance Analytics</h2>
                    <div>
                        <button onclick="window.print()" class="btn btn-secondary">
                            <i class="fas fa-print"></i> Print Report
                        </button>
                    </div>
                </div>
                
                <?php if(!empty($attendance_details)): ?>
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Student Name</th>
                                    <th>Grade</th>
                                    <th>Roll No</th>
                                    <th>Status</th>
                                    <th>Time</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($attendance_details as $record): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo date('M d, Y', strtotime($record['attendance_date'])); ?></strong>
                                            <br>
                                            <small style="color: var(--text-light);"><?php echo date('D', strtotime($record['attendance_date'])); ?></small>
                                        </td>
                                        <td>
                                            <strong><?php echo $record['first_name'] . ' ' . $record['last_name']; ?></strong>
                                        </td>
                                        <td>
                                            <span style="display: inline-block; padding: 8px 15px; background: rgba(0, 204, 255, 0.1); border-radius: 20px; font-weight: 700; color: var(--primary-blue);">
                                                Grade <?php echo $record['grade_level']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span style="font-weight: 700; color: var(--primary-dark);"><?php echo $record['roll_number']; ?></span>
                                        </td>
                                        <td>
                                            <?php if($record['status'] == 'present'): ?>
                                                <span class="status-badge badge-present">
                                                    <i class="fas fa-check-circle"></i> Present
                                                </span>
                                            <?php elseif($record['status'] == 'absent'): ?>
                                                <span class="status-badge badge-absent">
                                                    <i class="fas fa-times-circle"></i> Absent
                                                </span>
                                            <?php elseif($record['status'] == 'late'): ?>
                                                <span class="status-badge badge-late">
                                                    <i class="fas fa-clock"></i> Late
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span style="font-weight: 700; color: var(--primary-dark);">
                                                <?php echo date('h:i A', strtotime($record['attendance_time'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button class="btn btn-secondary" style="padding: 8px 15px; font-size: 0.9rem;" onclick="viewDetails(<?php echo $record['id']; ?>)">
                                                <i class="fas fa-eye"></i> Details
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="pagination">
                        <a href="#" class="page-link"><i class="fas fa-chevron-left"></i></a>
                        <a href="#" class="page-link active">1</a>
                        <a href="#" class="page-link">2</a>
                        <a href="#" class="page-link">3</a>
                        <span style="color: var(--text-light); padding: 0 10px;">...</span>
                        <a href="#" class="page-link">10</a>
                        <a href="#" class="page-link"><i class="fas fa-chevron-right"></i></a>
                    </div>
                <?php else: ?>
                    <div class="no-data">
                        <i class="fas fa-clipboard-list"></i>
                        <h3>No attendance records found</h3>
                        <p>Try adjusting your filters or check back later for new records.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <footer>
        <div class="footer-content">
            <div class="footer-text">
                <p style="margin: 0; font-size: 1.1rem; font-weight: 500;">
                    <i class="fas fa-graduation-cap" style="color: var(--primary-blue); margin-right: 10px;"></i>
                    School Analytics System &copy; 2025 - Powered by Group-H
                </p>
            </div>
            <div class="live-time">
                <i class="fas fa-clock time-icon"></i>
                <span id="live-time">Loading...</span>
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <script>
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const menuToggle = document.getElementById('menuToggle');
            const sidebar = document.getElementById('sidebar');
            
            if (window.innerWidth <= 768) {
                menuToggle.style.display = 'block';
                
                menuToggle.addEventListener('click', () => {
                    sidebar.classList.toggle('active');
                });
                
                document.addEventListener('click', (e) => {
                    if (!sidebar.contains(e.target) && !menuToggle.contains(e.target) && window.innerWidth <= 768) {
                        sidebar.classList.remove('active');
                    }
                });
            }
            
            window.addEventListener('resize', function() {
                if (window.innerWidth > 768) {
                    menuToggle.style.display = 'none';
                    sidebar.classList.remove('active');
                } else {
                    menuToggle.style.display = 'block';
                }
            });
            
            // Update live time
            function updateTime() {
                const now = new Date();
                const timeString = now.toLocaleTimeString('en-US', {
                    hour12: true,
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit'
                });
                document.getElementById('live-time').textContent = timeString;
            }
            
            updateTime();
            setInterval(updateTime, 1000);
            
            // Initialize charts
            initializeCharts();
            
            // Add hover effects
            const cards = document.querySelectorAll('.stat-card');
            cards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-8px) scale(1.02)';
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0) scale(1)';
                });
            });
        });
        
        function initializeCharts() {
            // Attendance Distribution Chart
            const attendanceCtx = document.getElementById('attendanceChart').getContext('2d');
            const attendanceChart = new Chart(attendanceCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Present', 'Absent', 'Late'],
                    datasets: [{
                        data: [<?php echo $total_present; ?>, <?php echo $total_absent; ?>, <?php echo $total_late; ?>],
                        backgroundColor: [
                            'rgba(0, 204, 122, 0.9)',
                            'rgba(255, 71, 87, 0.9)',
                            'rgba(255, 157, 0, 0.9)'
                        ],
                        borderColor: [
                            'rgba(0, 204, 122, 1)',
                            'rgba(255, 71, 87, 1)',
                            'rgba(255, 157, 0, 1)'
                        ],
                        borderWidth: 3,
                        hoverOffset: 20
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '70%',
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 25,
                                font: {
                                    size: 14,
                                    weight: '600'
                                },
                                usePointStyle: true,
                                pointStyle: 'circle'
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(10, 25, 47, 0.9)',
                            titleFont: {
                                size: 14
                            },
                            bodyFont: {
                                size: 14
                            },
                            padding: 15,
                            callbacks: {
                                label: function(context) {
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const value = context.raw;
                                    const percentage = Math.round((value / total) * 100);
                                    return `${context.label}: ${value} (${percentage}%)`;
                                }
                            }
                        }
                    }
                }
            });
            
            // Attendance by Grade Chart
            const gradeLabels = [];
            const presentData = [];
            const absentData = [];
            const lateData = [];
            
            <?php foreach($grade_stats as $stat): ?>
                gradeLabels.push('Grade <?php echo $stat['grade_level']; ?>');
                presentData.push(<?php echo $stat['present_count']; ?>);
                absentData.push(<?php echo $stat['absent_count']; ?>);
                lateData.push(<?php echo $stat['late_count']; ?>);
            <?php endforeach; ?>
            
            const gradeCtx = document.getElementById('gradeChart').getContext('2d');
            const gradeChart = new Chart(gradeCtx, {
                type: 'bar',
                data: {
                    labels: gradeLabels,
                    datasets: [
                        {
                            label: 'Present',
                            data: presentData,
                            backgroundColor: 'rgba(0, 204, 122, 0.9)',
                            borderColor: 'rgba(0, 204, 122, 1)',
                            borderWidth: 2,
                            borderRadius: 8,
                            borderSkipped: false,
                        },
                        {
                            label: 'Absent',
                            data: absentData,
                            backgroundColor: 'rgba(255, 71, 87, 0.9)',
                            borderColor: 'rgba(255, 71, 87, 1)',
                            borderWidth: 2,
                            borderRadius: 8,
                            borderSkipped: false,
                        },
                        {
                            label: 'Late',
                            data: lateData,
                            backgroundColor: 'rgba(255, 157, 0, 0.9)',
                            borderColor: 'rgba(255, 157, 0, 1)',
                            borderWidth: 2,
                            borderRadius: 8,
                            borderSkipped: false,
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: {
                                padding: 20,
                                font: {
                                    size: 14,
                                    weight: '600'
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Number of Students',
                                font: {
                                    size: 14,
                                    weight: '600'
                                }
                            },
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)'
                            },
                            ticks: {
                                font: {
                                    size: 12
                                }
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Grade Level',
                                font: {
                                    size: 14,
                                    weight: '600'
                                }
                            },
                            grid: {
                                display: false
                            },
                            ticks: {
                                font: {
                                    size: 12
                                }
                            }
                        }
                    }
                }
            });
            
            // Auto-refresh charts on window resize
            window.addEventListener('resize', function() {
                attendanceChart.resize();
                gradeChart.resize();
            });
        }
        
        function viewDetails(recordId) {
            alert('Viewing details for record ID: ' + recordId + '\n\nThis feature will show detailed attendance information.');
            // يمكنك استبدال هذا بتنفيذ AJAX لجلب التفاصيل
        }
        
        // إضافة تأثيرات تفاعلية للعناصر
        document.querySelectorAll('.btn').forEach(button => {
            button.addEventListener('click', function(e) {
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.cssText = `
                    position: absolute;
                    border-radius: 50%;
                    background: rgba(255, 255, 255, 0.7);
                    transform: scale(0);
                    animation: ripple-animation 0.6s linear;
                    width: ${size}px;
                    height: ${size}px;
                    top: ${y}px;
                    left: ${x}px;
                    pointer-events: none;
                `;
                
                this.appendChild(ripple);
                
                setTimeout(() => {
                    ripple.remove();
                }, 600);
            });
        });
        
        const style = document.createElement('style');
        style.textContent = `
            @keyframes ripple-animation {
                to {
                    transform: scale(4);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>