-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 28, 2025 at 02:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `system_studenty_school`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `EnrollNewStudent` (IN `p_username` VARCHAR(50), IN `p_password` VARCHAR(255), IN `p_email` VARCHAR(100), IN `p_first_name` VARCHAR(50), IN `p_last_name` VARCHAR(50), IN `p_dob` DATE, IN `p_gender` ENUM('male','female'), IN `p_grade_level` VARCHAR(20), IN `p_school_level` ENUM('Dugsi Hoose','Dugsi Dhexe','Dugsi Sare'), IN `p_father_name` VARCHAR(100), IN `p_mother_name` VARCHAR(100), IN `p_parent_phone` VARCHAR(20))   BEGIN
    DECLARE v_user_id INT;
    DECLARE v_student_code VARCHAR(20);
    
    START TRANSACTION;
    
    -- Generate student code
    SET v_student_code = CONCAT('STU', LPAD((SELECT COUNT(*) + 1 FROM students), 3, '0'));
    
    -- Insert into users table
    INSERT INTO users (username, password, email, role, status)
    VALUES (p_username, p_password, p_email, 'student', 'active');
    
    SET v_user_id = LAST_INSERT_ID();
    
    -- Insert into students table
    INSERT INTO students (
        user_id, student_code, first_name, last_name, date_of_birth, gender,
        grade_level, school_level, father_name, mother_name, parent_phone, enrollment_date
    ) VALUES (
        v_user_id, v_student_code, p_first_name, p_last_name, p_dob, p_gender,
        p_grade_level, p_school_level, p_father_name, p_mother_name, p_parent_phone, CURDATE()
    );
    
    COMMIT;
    
    SELECT v_student_code AS new_student_code, 'Student enrolled successfully' AS message;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `RecordAttendance` (IN `p_student_id` INT, IN `p_class_id` INT, IN `p_date` DATE, IN `p_status` ENUM('present','absent','late','excused'), IN `p_recorded_by` INT)   BEGIN
    INSERT INTO attendance (student_id, class_id, date, status, recorded_by)
    VALUES (p_student_id, p_class_id, p_date, p_status, p_recorded_by)
    ON DUPLICATE KEY UPDATE
        status = VALUES(status),
        recorded_by = VALUES(recorded_by),
        recorded_at = CURRENT_TIMESTAMP;
    
    SELECT 'Attendance recorded successfully' AS message;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `status` enum('present','absent','late') NOT NULL,
  `recorded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `student_id`, `date`, `status`, `recorded_by`, `created_at`) VALUES
(3, 2, '2025-12-06', 'present', 6, '2025-12-06 11:13:24'),
(4, 8, '2025-12-06', 'absent', 6, '2025-12-06 11:13:24'),
(11, 10, '2025-12-06', 'absent', 6, '2025-12-06 12:10:13'),
(12, 9, '2025-12-06', 'absent', 6, '2025-12-06 12:10:53'),
(14, 13, '2025-12-07', 'absent', 6, '2025-12-07 05:34:39'),
(15, 14, '2025-12-07', 'absent', 6, '2025-12-07 06:18:48'),
(16, 10, '2025-12-07', 'present', 6, '2025-12-07 06:18:48'),
(17, 13, '2025-12-10', 'absent', 6, '2025-12-10 06:45:22'),
(18, 15, '2025-12-18', 'absent', 10, '2025-12-18 19:45:45'),
(19, 15, '2025-12-16', 'present', 10, '2025-12-18 19:46:44'),
(20, 15, '2025-12-10', 'present', 10, '2025-12-18 19:47:26'),
(21, 15, '2025-12-08', 'absent', 10, '2025-12-18 19:48:22'),
(22, 2, '2025-12-19', 'absent', 10, '2025-12-19 22:20:08'),
(23, 8, '2025-12-19', 'present', 10, '2025-12-19 22:20:08'),
(24, 14, '2025-12-21', 'absent', 10, '2025-12-21 12:22:54'),
(25, 10, '2025-12-21', 'present', 10, '2025-12-21 12:22:54'),
(26, 14, '2025-12-27', 'absent', 10, '2025-12-27 08:54:46'),
(27, 10, '2025-12-27', 'present', 10, '2025-12-27 08:54:47'),
(28, 2, '2025-12-27', 'absent', 10, '2025-12-27 08:55:37'),
(29, 8, '2025-12-27', 'absent', 10, '2025-12-27 08:55:37');

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE `audit_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `table_name` varchar(50) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `book_borrowings`
--

CREATE TABLE `book_borrowings` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `borrower_id` int(11) NOT NULL,
  `borrower_type` enum('student','teacher') NOT NULL,
  `borrowed_date` date NOT NULL,
  `due_date` date NOT NULL,
  `returned_date` date DEFAULT NULL,
  `fine_amount` decimal(10,2) DEFAULT 0.00,
  `status` enum('borrowed','returned','overdue') DEFAULT 'borrowed',
  `issued_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `book_borrowings`
--
DELIMITER $$
CREATE TRIGGER `update_book_availability` AFTER INSERT ON `book_borrowings` FOR EACH ROW BEGIN
    IF NEW.status = 'borrowed' THEN
        UPDATE library_books 
        SET available_copies = available_copies - 1 
        WHERE id = NEW.book_id;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` int(11) NOT NULL,
  `class_code` varchar(20) NOT NULL,
  `grade_level` varchar(20) NOT NULL,
  `section` varchar(10) NOT NULL,
  `school_level` enum('Dugsi Hoose','Dugsi Dhexe','Dugsi Sare') NOT NULL,
  `academic_year` varchar(10) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `max_students` int(11) DEFAULT 35,
  `current_students` int(11) DEFAULT 0,
  `room_number` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `class_code`, `grade_level`, `section`, `school_level`, `academic_year`, `teacher_id`, `max_students`, `current_students`, `room_number`, `created_at`, `updated_at`) VALUES
(1, 'G5-A', 'Grade 5', 'A', 'Dugsi Dhexe', '2024-2025', 1, 35, 0, 'Room 101', '2025-12-01 13:53:18', '2025-12-01 13:53:18'),
(2, 'G4-A', 'Grade 4', 'A', 'Dugsi Hoose', '2024-2025', NULL, 30, 0, 'Room 102', '2025-12-01 13:53:18', '2025-12-01 13:53:18'),
(3, 'G9-A', 'Grade 9', 'A', 'Dugsi Sare', '2024-2025', 1, 40, 0, 'Room 201', '2025-12-01 13:53:18', '2025-12-01 13:53:18');

-- --------------------------------------------------------

--
-- Table structure for table `class_subjects`
--

CREATE TABLE `class_subjects` (
  `id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `schedule_day` enum('Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday') NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class_subjects`
--

INSERT INTO `class_subjects` (`id`, `class_id`, `subject_id`, `teacher_id`, `schedule_day`, `start_time`, `end_time`) VALUES
(1, 1, 6, 1, 'Saturday', '08:00:00', '09:30:00'),
(2, 1, 7, NULL, 'Saturday', '09:45:00', '11:15:00'),
(3, 1, 8, 1, 'Sunday', '08:00:00', '09:30:00'),
(4, 1, 9, 1, 'Sunday', '09:45:00', '11:15:00'),
(5, 1, 10, 1, 'Monday', '08:00:00', '09:30:00'),
(6, 2, 1, NULL, 'Saturday', '08:00:00', '09:30:00'),
(7, 2, 2, NULL, 'Saturday', '09:45:00', '11:15:00'),
(8, 2, 3, 1, 'Sunday', '08:00:00', '09:30:00'),
(9, 3, 12, 1, 'Saturday', '08:00:00', '09:30:00'),
(10, 3, 13, NULL, 'Saturday', '09:45:00', '11:15:00'),
(11, 3, 14, 1, 'Sunday', '08:00:00', '09:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `event_type` enum('academic','religious','cultural','sports','holiday') NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `location` varchar(200) DEFAULT NULL,
  `organizer` varchar(100) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `description`, `event_type`, `start_date`, `end_date`, `start_time`, `end_time`, `location`, `organizer`, `created_by`, `created_at`) VALUES
(1, 'Maalin Quran', 'Quran memorization competition', 'religious', '2024-02-15', '2024-02-15', NULL, NULL, 'School Mosque', 'Islamic Department', 1, '2025-12-01 13:53:19'),
(2, 'Science Fair', 'Annual science exhibition', 'academic', '2024-03-10', '2024-03-12', NULL, NULL, 'School Hall', 'Science Department', 1, '2025-12-01 13:53:19'),
(3, 'Independence Day', 'Somali Independence Day celebration', 'cultural', '2024-07-01', '2024-07-01', NULL, NULL, 'School Ground', 'Administration', 1, '2025-12-01 13:53:19');

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `id` int(11) NOT NULL,
  `exam_name` varchar(100) NOT NULL,
  `exam_type` enum('Mid-Term','Final','Quiz','Assignment') DEFAULT 'Mid-Term',
  `subject` varchar(50) NOT NULL,
  `exam_date` date NOT NULL,
  `total_marks` decimal(6,2) DEFAULT NULL,
  `duration` int(11) DEFAULT 60,
  `description` text DEFAULT NULL,
  `target_class` varchar(50) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`id`, `exam_name`, `exam_type`, `subject`, `exam_date`, `total_marks`, `duration`, `description`, `target_class`, `student_id`, `created_by`, `created_at`) VALUES
(1, 'Mid Term Exam', 'Mid-Term', 'Mathematics', '2025-01-20', 100.00, 60, NULL, 'Grade 8', NULL, 1, '2025-11-27 13:00:51'),
(2, 'Final', 'Mid-Term', 'Physics', '2025-12-08', 100.00, 60, NULL, 'Grade 9', NULL, NULL, '2025-12-01 16:38:43'),
(3, 'Mid-Term Exam', 'Mid-Term', 'Physics', '2025-09-08', 90.00, 60, NULL, 'Grade 9', NULL, 6, '2025-12-06 13:24:42'),
(4, 'Mid-Term Exam', 'Mid-Term', 'Physics', '2025-12-06', 100.00, 60, NULL, 'Grade 10', 10, 6, '2025-12-06 13:38:06'),
(5, 'Mid-Term Exam', 'Mid-Term', 'English', '2025-12-06', 70.00, 60, NULL, 'Grade 10', 10, 8, '2025-12-06 13:48:11'),
(6, 'Mid-Term Exam', 'Mid-Term', 'Business', '2025-01-01', 100.00, 60, NULL, 'Grade 9', 15, NULL, '2025-12-13 08:47:44'),
(7, 'Mid-Term Exam', 'Mid-Term', 'Physics', '2025-09-11', 30.00, 60, NULL, 'Grade 9', 15, 6, '2025-12-13 09:12:14'),
(8, 'Final Exam', 'Mid-Term', 'Physics', '2025-09-11', 30.00, 60, NULL, 'Grade 9', 15, 6, '2025-12-13 09:22:06'),
(9, 'Final Exam', 'Mid-Term', 'Tariikh', '2025-12-18', 60.00, 60, NULL, 'Grade 9', NULL, 10, '2025-12-18 21:11:34'),
(10, 'Mid-Term Exam', 'Mid-Term', 'Tariikh', '2025-12-18', 40.00, 60, NULL, 'Grade 9', NULL, 10, '2025-12-18 21:36:44'),
(11, 'Mid-Term Exam', 'Mid-Term', 'Physics', '2025-12-18', 40.00, 60, NULL, 'Grade 9', NULL, 6, '2025-12-18 21:41:41'),
(12, 'Final Exam', 'Mid-Term', 'Physics', '2025-12-18', 60.00, 60, NULL, 'Grade 9', NULL, 6, '2025-12-18 21:42:13'),
(13, 'Mid-Term Exam', 'Mid-Term', 'English', '2025-12-18', 40.00, 60, NULL, 'Grade 9', NULL, 8, '2025-12-18 21:45:28'),
(14, 'Mid-Term Exam', 'Mid-Term', 'Biology', '2025-12-18', 40.00, 60, NULL, 'Grade 9', NULL, 11, '2025-12-18 21:47:26'),
(15, 'Mid-Term Exam', 'Mid-Term', 'Business', '2025-12-18', 40.00, 60, NULL, 'Grade 9', NULL, 12, '2025-12-18 21:50:16'),
(16, 'Final Exam', 'Mid-Term', 'Business', '2025-12-18', 60.00, 60, NULL, 'Grade 9', NULL, 12, '2025-12-18 21:51:23'),
(17, 'Mid-Term Exam', 'Mid-Term', 'Business', '2025-12-18', 40.00, 60, NULL, 'Grade 11', NULL, 12, '2025-12-18 21:53:19'),
(18, 'Mid-Term Exam', 'Mid-Term', 'Tariikh', '2025-12-18', 40.00, 60, NULL, 'Grade 11', NULL, 10, '2025-12-18 21:55:08'),
(19, 'Mid-Term Exam', 'Mid-Term', 'Jugrafi', '2025-12-18', 40.00, 60, NULL, 'Grade 9', NULL, 14, '2025-12-18 22:32:15'),
(20, 'Mid-Term Exam', 'Mid-Term', 'Technology', '2025-12-18', 40.00, 60, NULL, 'Grade 9', NULL, 14, '2025-12-18 22:33:23'),
(21, 'Mid-Term Exam', 'Mid-Term', 'Physics', '2025-12-21', 40.00, 60, NULL, 'Grade 9', NULL, 6, '2025-12-21 12:24:51'),
(22, 'Final Exam', 'Mid-Term', 'Physics', '2025-12-21', 60.00, 60, NULL, 'Grade 9', NULL, 6, '2025-12-21 12:25:05'),
(23, 'Final Exam', 'Mid-Term', 'Tariikh', '2025-12-22', 60.00, 60, NULL, 'Grade 11', NULL, 10, '2025-12-22 11:46:00'),
(24, 'Mid-Term Exam', 'Mid-Term', 'Tariikh', '2025-12-22', 40.00, 60, NULL, 'Grade 11', NULL, 10, '2025-12-22 11:47:56'),
(25, 'Final Exam', 'Mid-Term', 'Tariikh', '2025-12-22', 60.00, 60, NULL, 'Grade 9', NULL, 10, '2025-12-22 11:48:53'),
(26, 'Mid-Term Exam', 'Mid-Term', 'Tariikh', '2025-12-22', 40.00, 60, NULL, 'Grade 10', NULL, 10, '2025-12-22 11:51:11'),
(27, 'Mid-Term Exam', 'Mid-Term', 'Soshiyal', '2025-12-23', 40.00, 60, NULL, 'Grade 8', NULL, 18, '2025-12-23 11:11:28'),
(28, 'Final Exam', 'Final', 'Tariikh', '2025-12-23', 60.00, 60, NULL, 'Grade 9', NULL, 10, '2025-12-23 22:33:19'),
(29, 'Mid-Term Exam', 'Mid-Term', 'Tariikh', '2025-12-23', 40.00, 60, NULL, 'Grade 9', NULL, 10, '2025-12-23 22:34:20'),
(30, 'Mid-Term Exam', 'Mid-Term', 'Physics', '2025-12-23', 40.00, 60, NULL, 'Grade 9', NULL, 6, '2025-12-23 22:35:19'),
(31, 'Final Exam', 'Final', 'Physics', '2025-12-23', 60.00, 60, NULL, 'Grade 9', NULL, 6, '2025-12-23 22:36:43'),
(32, 'Mid-Term Exam', 'Mid-Term', 'Physics', '2025-11-21', 40.00, 60, NULL, 'Grade 9', NULL, 6, '2025-12-23 23:12:56'),
(33, 'Final Exam', 'Final', 'Physics', '2025-11-21', 60.00, 60, NULL, 'Grade 9', NULL, 6, '2025-12-23 23:14:24'),
(34, 'Mid-Term Exam', 'Mid-Term', 'English', '2025-08-22', 40.00, 60, NULL, 'Grade 9', NULL, 8, '2025-12-23 23:17:02'),
(35, 'Final Exam', 'Final', 'English', '2025-09-22', 60.00, 60, NULL, 'Grade 9', NULL, 8, '2025-12-23 23:18:05'),
(36, 'Mid-Term Exam', 'Mid-Term', 'Biology', '2025-09-21', 40.00, 60, NULL, 'Grade 9', NULL, 11, '2025-12-23 23:21:44'),
(37, 'Mid-Term Exam', 'Mid-Term', 'Chemistry', '2025-08-22', 40.00, 60, NULL, 'Grade 9', NULL, 11, '2025-12-23 23:22:28'),
(38, 'Final Exam', 'Final', 'Biology', '2025-09-12', 60.00, 60, NULL, 'Grade 9', NULL, 11, '2025-12-23 23:24:07'),
(39, 'Final Exam', 'Final', 'Chemistry', '2025-01-21', 60.00, 60, NULL, 'Grade 9', NULL, 11, '2025-12-23 23:24:40'),
(40, 'Mid-Term Exam', 'Mid-Term', 'Carabi', '2025-12-23', 40.00, 60, NULL, 'Grade 9', NULL, 16, '2025-12-23 23:27:46'),
(41, 'Final Exam', 'Final', 'Carabi', '2025-12-23', 60.00, 60, NULL, 'Grade 9', NULL, 16, '2025-12-23 23:28:24'),
(42, 'Mid-Term Exam', 'Mid-Term', 'Tarbiyo', '2025-12-23', 40.00, 60, NULL, 'Grade 9', NULL, 16, '2025-12-23 23:33:50'),
(43, 'Final Exam', 'Final', 'Tarbiyo', '2025-12-23', 60.00, 60, NULL, 'Grade 9', NULL, 16, '2025-12-23 23:34:31'),
(44, 'Mid-Term Exam', 'Mid-Term', 'Tariikh', '2025-12-23', 40.00, 60, NULL, 'Grade 9', NULL, 14, '2025-12-23 23:36:35'),
(45, 'Final Exam', 'Final', 'Tariikh', '2025-12-23', 60.00, 60, NULL, 'Grade 9', NULL, 14, '2025-12-23 23:37:09');

-- --------------------------------------------------------

--
-- Table structure for table `exam_results`
--

CREATE TABLE `exam_results` (
  `id` int(11) NOT NULL,
  `exam_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `marks_obtained` decimal(6,2) DEFAULT NULL,
  `grade` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam_results`
--

INSERT INTO `exam_results` (`id`, `exam_id`, `student_id`, `marks_obtained`, `grade`) VALUES
(2, 9, 16, 55.00, NULL),
(3, 9, 15, 55.00, NULL),
(4, 10, 15, 31.00, NULL),
(5, 11, 15, 20.00, NULL),
(6, 12, 15, 60.00, NULL),
(7, 13, 15, 35.00, NULL),
(8, 14, 15, 33.00, NULL),
(9, 15, 15, 39.00, NULL),
(10, 16, 15, 55.00, NULL),
(11, 17, 2, 20.00, NULL),
(12, 18, 2, 33.00, NULL),
(13, 19, 15, 32.00, NULL),
(14, 20, 15, 40.00, NULL),
(15, 21, 15, 40.00, NULL),
(16, 22, 15, 60.00, NULL),
(17, 23, 2, 50.00, NULL),
(18, 24, 2, 33.00, NULL),
(19, 25, 15, 60.00, NULL),
(20, 26, 14, 39.00, NULL),
(21, 27, 17, 38.00, NULL),
(22, 28, 15, 55.00, NULL),
(23, 29, 15, 30.00, NULL),
(24, 30, 15, 35.00, NULL),
(25, 31, 15, 60.00, NULL),
(26, 32, 18, 40.00, NULL),
(27, 33, 18, 55.00, NULL),
(28, 34, 18, 39.00, NULL),
(29, 35, 18, 58.00, NULL),
(30, 36, 18, 40.00, NULL),
(31, 37, 18, 37.00, NULL),
(32, 38, 18, 60.00, NULL),
(33, 39, 18, 60.00, NULL),
(34, 40, 18, 40.00, NULL),
(35, 41, 18, 59.00, NULL),
(36, 42, 18, 34.00, NULL),
(37, 43, 18, 60.00, NULL),
(38, 44, 18, 40.00, NULL),
(39, 45, 18, 60.00, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `homework`
--

CREATE TABLE `homework` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `subject_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `assigned_by` int(11) NOT NULL,
  `assigned_date` date NOT NULL,
  `due_date` date NOT NULL,
  `max_marks` decimal(5,2) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `homework`
--

INSERT INTO `homework` (`id`, `title`, `description`, `subject_id`, `class_id`, `assigned_by`, `assigned_date`, `due_date`, `max_marks`, `attachment`, `created_at`) VALUES
(1, 'Math Chapter 3 Exercises', 'Complete all exercises from chapter 3', 9, 1, 1, '2024-01-15', '2024-01-22', 20.00, NULL, '2025-12-01 13:53:18');

-- --------------------------------------------------------

--
-- Table structure for table `library_books`
--

CREATE TABLE `library_books` (
  `id` int(11) NOT NULL,
  `book_code` varchar(50) NOT NULL,
  `title` varchar(200) NOT NULL,
  `author` varchar(100) NOT NULL,
  `isbn` varchar(20) DEFAULT NULL,
  `publisher` varchar(100) DEFAULT NULL,
  `publication_year` year(4) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `language` varchar(30) DEFAULT 'Somali',
  `total_copies` int(11) DEFAULT 1,
  `available_copies` int(11) DEFAULT 1,
  `shelf_location` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `library_books`
--

INSERT INTO `library_books` (`id`, `book_code`, `title`, `author`, `isbn`, `publisher`, `publication_year`, `category`, `language`, `total_copies`, `available_copies`, `shelf_location`, `created_at`) VALUES
(1, 'LIB001', 'Quraanka Kariimka', 'Various', NULL, NULL, NULL, 'Religious', 'Somali', 10, 10, NULL, '2025-12-01 13:53:19'),
(2, 'LIB002', 'Halgankii Soomaalida', 'Ahmed Artan', NULL, NULL, NULL, 'History', 'Somali', 5, 5, NULL, '2025-12-01 13:53:19'),
(3, 'LIB003', 'English Grammar Guide', 'John Smith', NULL, NULL, NULL, 'Education', 'Somali', 8, 8, NULL, '2025-12-01 13:53:19'),
(4, 'LIB004', 'Xisaabta Dugsiga Sare', 'Omar Ali', NULL, NULL, NULL, 'Mathematics', 'Somali', 6, 6, NULL, '2025-12-01 13:53:19');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `obtained_marks` decimal(5,2) NOT NULL,
  `percentage` decimal(5,2) NOT NULL,
  `grade` varchar(5) NOT NULL,
  `remarks` text DEFAULT NULL,
  `entered_by` int(11) DEFAULT NULL,
  `entered_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `parent_message_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `category` enum('general','exam','holiday','event','urgent') DEFAULT 'general',
  `target_audience` enum('all','students','teachers','parents') DEFAULT 'all',
  `published_by` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `is_published` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`id`, `title`, `content`, `category`, `target_audience`, `published_by`, `start_date`, `end_date`, `is_published`, `created_at`, `updated_at`) VALUES
(1, 'Parent-Teacher Meeting', 'Annual parent-teacher meeting will be held on Saturday. All parents are requested to attend.', 'event', 'parents', 1, '2024-01-20', '2024-01-21', 1, '2025-12-01 13:53:18', '2025-12-01 13:53:18'),
(2, 'Ramadan Schedule', 'School timings during Ramadan will be from 8:00 AM to 12:00 PM.', 'general', 'all', 1, '2024-03-01', '2024-04-30', 1, '2025-12-01 13:53:18', '2025-12-01 13:53:18');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `payment_type` enum('tuition','exam','transport','library','other') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `payment_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `payment_method` enum('cash','bank_transfer','mobile_money') DEFAULT 'cash',
  `transaction_id` varchar(100) DEFAULT NULL,
  `status` enum('pending','paid','overdue','cancelled') DEFAULT 'pending',
  `received_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `student_code` varchar(20) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `grade_level` varchar(20) DEFAULT NULL,
  `parent_contact` varchar(100) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `parent_name` varchar(100) DEFAULT NULL,
  `parent_phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `section` varchar(10) DEFAULT NULL,
  `roll_number` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `user_id`, `student_code`, `first_name`, `last_name`, `date_of_birth`, `grade_level`, `parent_contact`, `updated_at`, `parent_name`, `parent_phone`, `address`, `section`, `roll_number`) VALUES
(2, 4, 'STU002', 'Anas Abdiwahid', 'Hussein', '2004-01-01', 'Grade 11', '0613496943', '2025-12-21 18:01:36', NULL, NULL, NULL, NULL, NULL),
(8, 22, 'STU008', 'Ayman Abdiwahid', 'Hussein', '2008-07-03', 'Grade 11', '0618290200', '2025-12-21 18:01:36', NULL, NULL, NULL, NULL, NULL),
(9, 24, 'STU009', 'Maxamed', 'Amiin', '2009-08-31', 'Grade 3', '0770728812', '2025-12-21 18:01:36', NULL, NULL, NULL, NULL, NULL),
(10, 25, 'STU010', 'yoonis', 'hussein', '2009-02-07', 'Grade 10', '0618992922', '2025-12-21 18:01:36', NULL, NULL, NULL, NULL, NULL),
(12, 28, 'STU012', 'Jaamac', 'raage', '2010-08-29', 'Grade 7', '0618118822', '2025-12-21 18:01:36', NULL, NULL, NULL, NULL, NULL),
(13, 29, 'STU013', 'dhanged', 'ugaaz', '1960-07-01', 'Grade 12', '6131118888', '2025-12-21 18:01:36', NULL, NULL, NULL, NULL, NULL),
(14, 30, 'STU014', 'Abdikadir mohamed', 'ibrahim', '2005-03-29', 'Grade 10', '61111111', '2025-12-21 18:01:36', NULL, NULL, NULL, NULL, NULL),
(15, 31, 'STU015', 'Anas Abdiwahid', 'Hussein', '2010-09-21', 'Grade 9', '0617881181', '2025-12-21 18:01:36', NULL, NULL, NULL, NULL, NULL),
(16, 35, 'STU016', 'Maxamed', 'Amiin', '2016-04-21', 'Grade 6', '0616665558', '2025-12-21 18:01:36', NULL, NULL, NULL, NULL, NULL),
(17, 43, NULL, 'Omar', 'Abukar', '2009-02-09', 'Grade 8', '0612008977', '2025-12-23 11:04:59', NULL, NULL, NULL, NULL, NULL),
(18, 45, NULL, 'Sakariye Maxamed', 'Ahmed', '2006-11-30', 'Grade 9', '0618929910', '2025-12-23 23:03:18', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `subject_code` varchar(20) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `subject_name_somali` varchar(100) NOT NULL,
  `school_level` enum('Dugsi Hoose','Dugsi Dhexe','Dugsi Sare') NOT NULL,
  `description` text DEFAULT NULL,
  `credit_hours` int(11) DEFAULT 1,
  `is_core` enum('yes','no') DEFAULT 'yes',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `subject_code`, `subject_name`, `subject_name_somali`, `school_level`, `description`, `credit_hours`, `is_core`, `created_at`) VALUES
(1, 'DH-SOM', 'Somali Language', 'Af-Soomaali', 'Dugsi Hoose', 'Somali language and grammar', 1, 'yes', '2025-12-01 13:53:18'),
(2, 'DH-ENG', 'English Language', 'Af-Ingiriisi', 'Dugsi Hoose', 'English language basics', 1, 'yes', '2025-12-01 13:53:18'),
(3, 'DH-ARB', 'Arabic Language', 'Af-Carabi', 'Dugsi Hoose', 'Arabic language and Quran reading', 1, 'yes', '2025-12-01 13:53:18'),
(4, 'DH-MATH', 'Mathematics', 'Xisaab', 'Dugsi Hoose', 'Basic mathematics', 1, 'yes', '2025-12-01 13:53:18'),
(5, 'DH-ISL', 'Islamic Studies', 'Cilmiga Diinta', 'Dugsi Hoose', 'Islamic education and morals', 1, 'yes', '2025-12-01 13:53:18'),
(6, 'DD-SOM', 'Somali Literature', 'Suugaanta Soomaalida', 'Dugsi Dhexe', 'Somali literature and poetry', 1, 'yes', '2025-12-01 13:53:18'),
(7, 'DD-ENG', 'English Grammar', 'Qawaaniinta Af-Ingiriisiga', 'Dugsi Dhexe', 'English grammar and composition', 1, 'yes', '2025-12-01 13:53:18'),
(8, 'DD-ARB', 'Arabic Grammar', 'Naxwaha Carabiga', 'Dugsi Dhexe', 'Arabic grammar and Quranic studies', 1, 'yes', '2025-12-01 13:53:18'),
(9, 'DD-MATH', 'Mathematics', 'Xisaab', 'Dugsi Dhexe', 'Intermediate mathematics', 1, 'yes', '2025-12-01 13:53:18'),
(10, 'DD-SCI', 'Science', 'Saynis', 'Dugsi Dhexe', 'General science', 1, 'yes', '2025-12-01 13:53:18'),
(11, 'DD-HIS', 'History', 'Taariikh', 'Dugsi Dhexe', 'Somali and world history', 1, 'yes', '2025-12-01 13:53:18'),
(12, 'DS-SOM', 'Advanced Somali', 'Af-Soomaali Sare', 'Dugsi Sare', 'Advanced Somali language and literature', 1, 'yes', '2025-12-01 13:53:18'),
(13, 'DS-ENG', 'Advanced English', 'Af-Ingiriisi Sare', 'Dugsi Sare', 'Advanced English and composition', 1, 'yes', '2025-12-01 13:53:18'),
(14, 'DS-ARB', 'Quranic Studies', 'Cilmiga Quraanka', 'Dugsi Sare', 'Quran memorization and interpretation', 1, 'yes', '2025-12-01 13:53:18'),
(15, 'DS-MATH', 'Advanced Math', 'Xisaab Sare', 'Dugsi Sare', 'Advanced mathematics and algebra', 1, 'yes', '2025-12-01 13:53:18'),
(16, 'DS-PHY', 'Physics', 'Fiisigis', 'Dugsi Sare', 'Physics for high school', 1, 'yes', '2025-12-01 13:53:18'),
(17, 'DS-BIO', 'Biology', 'Bayoloji', 'Dugsi Sare', 'Biology for high school', 1, 'yes', '2025-12-01 13:53:18'),
(18, 'DS-CHEM', 'Chemistry', 'Kimistar', 'Dugsi Sare', 'Chemistry for high school', 1, 'yes', '2025-12-01 13:53:18'),
(19, 'DS-ICT', 'Computer Studies', 'Kumbuyuutar', 'Dugsi Sare', 'Computer and technology', 1, 'yes', '2025-12-01 13:53:18');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `subject_specialization` varchar(100) DEFAULT NULL,
  `assigned_classes` text DEFAULT NULL,
  `hire_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `user_id`, `first_name`, `last_name`, `subject_specialization`, `assigned_classes`, `hire_date`) VALUES
(1, 2, 'Mohamed', 'Hassan', 'Mathematics', 'Grade 8, Grade 9', '2021-02-12'),
(5, 19, 'Hussein Mohamed', 'Hussein', 'English', 'Grade 1,Grade 2,Grade 3,Grade 4', '2025-12-03'),
(6, 21, 'Maryan', 'Hussein', 'Physics', 'Grade 9,Grade 10', '2025-12-03'),
(7, 23, 'fadumo', 'dahir', 'Tarbiyo', 'Grade 1,Grade 2,Grade 3,Grade 4', '2025-12-06'),
(8, 27, 'Sheikh', 'Ahmed', 'English', 'Grade 9,Grade 10,Grade 11,Grade 12', '2025-12-06'),
(10, 34, 'anas', 'updyyy', 'Xisaab', 'Grade 9,Grade 10,Grade 11,Grade 12', '2025-12-14'),
(11, 36, 'Ustaad', 'Ali', 'Biology,Chemistry', 'Grade 9,Grade 10,Grade 11,Grade 12', '2025-12-19'),
(12, 37, 'hussein', 'hassan', 'Business', 'Grade 9,Grade 10,Grade 11,Grade 12', '2025-12-19'),
(13, 38, 'ayman', 'maxamed', 'Business', 'Grade 7,Grade 9,Grade 10,Grade 11,Grade 12', '2025-12-19'),
(14, 39, 'ahmed', 'abdi', 'Tariikh', 'Grade 9,Grade 10,Grade 11,Grade 12', '2025-12-19'),
(15, 40, 'Khalid', 'Maxamed', 'Carabi,Tarbiyo', 'Grade 5,Grade 6,Grade 7,Grade 8', '2025-12-21'),
(16, 41, 'Mustafa', 'Ragge', 'Carabi,Tarbiyo', 'Grade 9,Grade 10,Grade 11,Grade 12', '2025-12-21'),
(17, 42, 'Muuse', 'Maxamed', 'Jugrafi', 'Grade 9,Grade 10,Grade 11,Grade 12', '2025-12-21'),
(18, 44, 'Yusuf', 'Ali', 'Soshiyal', 'Grade 5,Grade 6,Grade 7,Grade 8', '2025-12-23');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_classes`
--

CREATE TABLE `teacher_classes` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `class_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `day_of_week` enum('Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday') NOT NULL,
  `period_number` int(11) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `room` varchar(20) DEFAULT NULL,
  `academic_year` varchar(10) NOT NULL,
  `term` enum('Term 1','Term 2','Term 3') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`id`, `class_id`, `subject_id`, `teacher_id`, `day_of_week`, `period_number`, `start_time`, `end_time`, `room`, `academic_year`, `term`, `created_at`, `updated_at`) VALUES
(1, 1, 6, 1, 'Saturday', 1, '08:00:00', '08:45:00', NULL, '2024-2025', 'Term 1', '2025-12-01 13:53:18', '2025-12-01 13:53:18'),
(2, 1, 6, 1, 'Saturday', 2, '08:45:00', '09:30:00', NULL, '2024-2025', 'Term 1', '2025-12-01 13:53:18', '2025-12-01 13:53:18'),
(5, 1, 8, 1, 'Sunday', 1, '08:00:00', '08:45:00', NULL, '2024-2025', 'Term 1', '2025-12-01 13:53:18', '2025-12-01 13:53:18'),
(6, 1, 8, 1, 'Sunday', 2, '08:45:00', '09:30:00', NULL, '2024-2025', 'Term 1', '2025-12-01 13:53:18', '2025-12-01 13:53:18'),
(7, 1, 9, 1, 'Sunday', 3, '09:45:00', '10:30:00', NULL, '2024-2025', 'Term 1', '2025-12-01 13:53:18', '2025-12-01 13:53:18'),
(8, 1, 9, 1, 'Sunday', 4, '10:30:00', '11:15:00', NULL, '2024-2025', 'Term 1', '2025-12-01 13:53:18', '2025-12-01 13:53:18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `role` enum('admin','teacher','student') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `phone_number`, `profile_image`, `role`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'password', 'admin1@example.com', NULL, NULL, 'admin', '2025-11-27 13:00:50', '2025-12-21 17:49:51'),
(2, 'teacher1', 'teacher123', 'teacher1@example.com', NULL, NULL, 'teacher', '2025-11-27 13:00:50', '2025-12-21 17:49:51'),
(4, 'STU004', '$2y$10$i4J8Celd93T34X5dLoXRleKKJ9flQlwZU4QUd/kaqm0aOAP.XaW.C', 'STU004@school.com', NULL, NULL, 'student', '2025-11-27 13:05:33', '2025-12-21 17:49:51'),
(6, 'anas', '$2y$10$45gHyerbwEvJ3SphWRveq.Gkuymsx3GmzZk.dapClq.Ub9zgKJ09G', 'anas2627@gmail.com', NULL, NULL, 'admin', '2025-12-01 15:39:05', '2025-12-21 17:49:51'),
(18, 'admin2', '$2y$10$jTmC/UhATI10F0KxlYlRaOxPp/j/CnMVZoFqOjcOEBKRMhjSVoiMK', 'abdinasir@gmail.com', NULL, NULL, 'admin', '2025-12-03 15:12:32', '2025-12-21 17:49:51'),
(19, 'hussein', '$2y$10$hGJOE9rk6jWlj5aMZVLhmeW6pQpgbRzBzCjlyLZimpr9NnOqjKTY6', 'hussein@gmail.com', NULL, NULL, 'teacher', '2025-12-03 15:21:15', '2025-12-21 17:49:51'),
(20, 'Najmo', '$2y$10$BnUp5cLeMFTmEyBG.a07R.vYQqEseMGV5cQicaOf1VN4.cmVDEVD6', 'najmo@gmail.om', NULL, NULL, 'admin', '2025-12-03 18:50:05', '2025-12-21 17:49:51'),
(21, 'maryan', '$2y$10$9CCOZUhqTGleTf29e2RVYO5IK2z.qNp/3CVrJpaTsDeZeNuJBe8Qm', 'maryan@gmail.com', NULL, NULL, 'teacher', '2025-12-03 18:51:09', '2025-12-21 17:49:51'),
(22, 'STU022', '$2y$10$8rJrd0dxy9g.sDyu1hVqOufj7ZP6t9n1q.lqR92HeDncsZAc0nZV.', 'STU022@school.com', NULL, NULL, 'student', '2025-12-06 11:12:37', '2025-12-21 17:49:51'),
(23, 'fadumo', '$2y$10$IGMU7Znhx5Xo3ppXD4exjeI3q7N8SW2mSl2vBLQ9CKj/ZTAS.d2Ba', 'fadumo@gmail.com', NULL, NULL, 'teacher', '2025-12-06 11:33:39', '2025-12-21 17:49:51'),
(24, 'STU024', '$2y$10$DD1dVpVIBeBkP8fqewPTdOtvQubiI2X/kyJNvZgPhMSgbfZ8i3lni', 'STU024@school.com', NULL, NULL, 'student', '2025-12-06 11:36:16', '2025-12-21 17:49:51'),
(25, 'STU025', '$2y$10$7PaRf3cEfQo0tSB8oydJ5esyCOC7Ym60sXThfHRfwpVK1CirB/PZu', 'STU025@school.com', NULL, NULL, 'student', '2025-12-06 11:55:07', '2025-12-21 17:49:51'),
(27, 'sheikh', '$2y$10$POIvVDbIeuLZL4aFXFY7uusFEA/UqMnP8tw6t.K5j5C4LrnYebfpq', 'sheikh@gmail.com', NULL, NULL, 'teacher', '2025-12-06 13:47:26', '2025-12-21 17:49:51'),
(28, 'STU028', '$2y$10$CMBNo8Unxgfp6IPxCr8wSeYOBPxn3UIugozd.zowln2ZWeWuX.VN.', 'STU028@school.com', NULL, NULL, 'student', '2025-12-06 18:41:26', '2025-12-21 17:49:51'),
(29, 'STU029', '$2y$10$.vUlttTPBqcI7Qptpl/89e8kFInfo0zhQDyiLNCICIYVyaM.LWHBG', 'STU029@school.com', NULL, NULL, 'student', '2025-12-07 05:31:57', '2025-12-21 17:49:51'),
(30, 'STU030', '$2y$10$ugaDhZ6N86cPLnlX/3F/Pe40X11lpkmP3R7n3AJ9XcAjvovpKNyO6', 'STU030@school.com', NULL, NULL, 'student', '2025-12-07 06:17:35', '2025-12-21 17:49:51'),
(31, 'STU031', '$2y$10$911DErerIj1MFANhHTC/pe2maW703JP50OSicyl9EgEMz60E49/k2', 'STU031@school.com', NULL, NULL, 'student', '2025-12-07 06:27:21', '2025-12-21 17:50:50'),
(34, 'anaz', '$2y$10$C26Xb/SElvmaFo3dWmMhoO3Rqfw73/oTQnRBDsu8ym.ZCBvEd03pG', 'anazzz@gmail.com', NULL, NULL, 'teacher', '2025-12-14 06:21:35', '2025-12-21 17:49:51'),
(35, 'STU035', '$2y$10$LI.aoT30bQO6pGomM7NFvuwqB597zwUIKy7pa2.8Da.RcEIgVi.NG', 'STU035@school.com', NULL, NULL, 'student', '2025-12-18 16:41:41', '2025-12-21 17:49:51'),
(36, 'ali', '$2y$10$44cWBK5Q435v6MUZiRAAcenDV098piUAsNV1YUEz3CRmvsh.C.1Z2', 'ustaad@gmail.com', NULL, NULL, 'teacher', '2025-12-18 21:46:50', '2025-12-21 17:49:51'),
(37, 'hassan', '$2y$10$fhBVg5e5dX4PZyVjYa/.1Ozz0rs9NcyDR0vTSN/GyjWqbi3O5eHvy', 'husseinhassan@gmail.com', NULL, NULL, 'teacher', '2025-12-18 21:49:39', '2025-12-21 17:49:51'),
(38, 'ayman', '$2y$10$AtsIv5lLOXI/aVrpRIR2Bew/HgRLKLvQL3H7dO3rn3aFQH5QMfPPG', 'ayman@gmail.com', NULL, NULL, 'teacher', '2025-12-18 22:06:39', '2025-12-21 17:49:51'),
(39, 'ahmed', '$2y$10$OEvCn/0XTB1sf4MLgyfwGO4DP9A9CjLPLbjxslcboxd/aW78lbMo.', 'ahmedabdi@gmail.com', NULL, NULL, 'teacher', '2025-12-18 22:25:09', '2025-12-21 17:49:51'),
(40, 'khalid', '$2y$10$ZRLjOwIxcheKj14YLX9Uf.UhjodsWVt4hY24macA3zWCQ6W9JiVqO', 'khalid@gmail.com', NULL, NULL, 'teacher', '2025-12-21 15:08:43', '2025-12-21 17:49:51'),
(41, 'mustafa', '$2y$10$45M7hshS6SPLZ3xu/s3JyOhGr7FVqTTp7aMWjq8.Fe3c7LZywraz.', 'mustafa@gmail.com', NULL, NULL, 'teacher', '2025-12-21 15:22:42', '2025-12-21 17:49:51'),
(42, 'muuse', '$2y$10$ctyfiasYVEJj3djwKeEYO.ZsfK.QXsekLpUrW0QO./e181huVzG52', 'muuse@gmail.com', NULL, NULL, 'teacher', '2025-12-21 16:22:01', '2025-12-21 17:49:51'),
(43, 'STU043', '$2y$10$ricm4Mcx4Sc5mCSQcS0YEewbfymWOE67WcrI9Uxy6lo01XwxBqACO', 'STU043@school.com', NULL, NULL, 'student', '2025-12-23 11:04:59', '2025-12-23 11:04:59'),
(44, 'yusuf', '$2y$10$gi5fxJpr1gSXvJEMIc/dlOWC6D0aDiRaVo.Z.2jSMPKe9qj8cc.tK', 'yusuf@gmail.comm', NULL, NULL, 'teacher', '2025-12-23 11:08:58', '2025-12-23 11:08:58'),
(45, 'STU045', '$2y$10$LP9i9tmwv5XiKxBXTfWnqeH.0TNG9sHFshhn8JOOMhYl/wJxBvwZu', 'STU045@school.com', NULL, NULL, 'student', '2025-12-23 23:03:17', '2025-12-23 23:03:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_attendance_student` (`student_id`),
  ADD KEY `idx_attendance_recorded_by` (`recorded_by`),
  ADD KEY `idx_attendance_student_date` (`student_id`,`date`);

--
-- Indexes for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_action` (`action`,`created_at`),
  ADD KEY `idx_user_action` (`user_id`,`created_at`);

--
-- Indexes for table `book_borrowings`
--
ALTER TABLE `book_borrowings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`),
  ADD KEY `idx_borrower` (`borrower_id`,`borrower_type`),
  ADD KEY `idx_status` (`status`,`due_date`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `class_code` (`class_code`),
  ADD UNIQUE KEY `unique_class` (`grade_level`,`section`,`academic_year`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `idx_class_code` (`class_code`),
  ADD KEY `idx_academic_year` (`academic_year`);

--
-- Indexes for table `class_subjects`
--
ALTER TABLE `class_subjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_schedule` (`class_id`,`schedule_day`,`start_time`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `idx_class_id` (`class_id`),
  ADD KEY `idx_teacher_id` (`teacher_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_event_date` (`start_date`,`end_date`),
  ADD KEY `idx_event_type` (`event_type`),
  ADD KEY `idx_events_dates` (`start_date`,`end_date`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_exams_created_by` (`created_by`),
  ADD KEY `fk_exam_student` (`student_id`);

--
-- Indexes for table `exam_results`
--
ALTER TABLE `exam_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_results_exam_id` (`exam_id`),
  ADD KEY `idx_results_student_id` (`student_id`);

--
-- Indexes for table `homework`
--
ALTER TABLE `homework`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `assigned_by` (`assigned_by`),
  ADD KEY `idx_due_date` (`due_date`),
  ADD KEY `idx_class_subject` (`class_id`,`subject_id`),
  ADD KEY `idx_homework_due` (`due_date`);

--
-- Indexes for table `library_books`
--
ALTER TABLE `library_books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `book_code` (`book_code`),
  ADD KEY `idx_book_code` (`book_code`),
  ADD KEY `idx_category` (`category`),
  ADD KEY `idx_available` (`available_copies`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_marks` (`student_id`,`exam_id`,`subject_id`),
  ADD KEY `exam_id` (`exam_id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `entered_by` (`entered_by`),
  ADD KEY `idx_student_exam` (`student_id`,`exam_id`),
  ADD KEY `idx_marks_student_subject` (`student_id`,`subject_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_message_id` (`parent_message_id`),
  ADD KEY `idx_sender` (`sender_id`,`created_at`),
  ADD KEY `idx_receiver` (`receiver_id`,`is_read`,`created_at`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `published_by` (`published_by`),
  ADD KEY `idx_category` (`category`),
  ADD KEY `idx_published` (`is_published`,`start_date`),
  ADD KEY `idx_notices_dates` (`start_date`,`end_date`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `received_by` (`received_by`),
  ADD KEY `idx_student_status` (`student_id`,`status`),
  ADD KEY `idx_payment_date` (`payment_date`),
  ADD KEY `idx_payments_student` (`student_id`,`status`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_code` (`student_code`),
  ADD KEY `idx_students_user_id` (`user_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subject_code` (`subject_code`),
  ADD KEY `idx_subject_code` (`subject_code`),
  ADD KEY `idx_school_level` (`school_level`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_teachers_user_id` (`user_id`);

--
-- Indexes for table `teacher_classes`
--
ALTER TABLE `teacher_classes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_timetable` (`class_id`,`day_of_week`,`period_number`,`academic_year`,`term`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `idx_class_day` (`class_id`,`day_of_week`),
  ADD KEY `idx_timetable_class_day` (`class_id`,`day_of_week`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_users_username` (`username`),
  ADD UNIQUE KEY `uq_users_email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `audit_log`
--
ALTER TABLE `audit_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `book_borrowings`
--
ALTER TABLE `book_borrowings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `class_subjects`
--
ALTER TABLE `class_subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `exam_results`
--
ALTER TABLE `exam_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `homework`
--
ALTER TABLE `homework`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `library_books`
--
ALTER TABLE `library_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `teacher_classes`
--
ALTER TABLE `teacher_classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `timetable`
--
ALTER TABLE `timetable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `fk_attendance_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_attendance_teacher` FOREIGN KEY (`recorded_by`) REFERENCES `teachers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD CONSTRAINT `audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `book_borrowings`
--
ALTER TABLE `book_borrowings`
  ADD CONSTRAINT `book_borrowings_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `library_books` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `classes`
--
ALTER TABLE `classes`
  ADD CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `class_subjects`
--
ALTER TABLE `class_subjects`
  ADD CONSTRAINT `class_subjects_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `class_subjects_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `class_subjects_ibfk_3` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `exams`
--
ALTER TABLE `exams`
  ADD CONSTRAINT `fk_exam_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_exams_teacher` FOREIGN KEY (`created_by`) REFERENCES `teachers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `exam_results`
--
ALTER TABLE `exam_results`
  ADD CONSTRAINT `fk_results_exam` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_results_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `homework`
--
ALTER TABLE `homework`
  ADD CONSTRAINT `homework_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `homework_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `homework_ibfk_3` FOREIGN KEY (`assigned_by`) REFERENCES `teachers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `marks`
--
ALTER TABLE `marks`
  ADD CONSTRAINT `marks_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `marks_ibfk_2` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `marks_ibfk_3` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `marks_ibfk_4` FOREIGN KEY (`entered_by`) REFERENCES `teachers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `messages_ibfk_3` FOREIGN KEY (`parent_message_id`) REFERENCES `messages` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `notices`
--
ALTER TABLE `notices`
  ADD CONSTRAINT `notices_ibfk_1` FOREIGN KEY (`published_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `fk_students_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teachers`
--
ALTER TABLE `teachers`
  ADD CONSTRAINT `fk_teachers_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teacher_classes`
--
ALTER TABLE `teacher_classes`
  ADD CONSTRAINT `teacher_classes_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `timetable`
--
ALTER TABLE `timetable`
  ADD CONSTRAINT `timetable_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `timetable_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `timetable_ibfk_3` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
