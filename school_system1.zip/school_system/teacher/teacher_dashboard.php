<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'teacher') {
    header('Location: ../index.php');
    exit();
}

$teacher_username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Teacher';
if (empty($teacher_username)) {
    $teacher_username = 'Teacher';
}

$teacher_id = $_SESSION['user_id'];

// Get teacher info
$teacher_stmt = $pdo->prepare("SELECT * FROM teachers WHERE user_id = ?");
$teacher_stmt->execute([$teacher_id]);
$teacher = $teacher_stmt->fetch();

// Default values if teacher not found
if (!$teacher) {
    $teacher = [
        'id' => $teacher_id,
        'first_name' => 'John',
        'last_name' => 'Doe',
        'subject' => 'Mathematics'
    ];
}

$teacher_name = $teacher['first_name'] . ' ' . $teacher['last_name'];
$teacher_subject = $teacher['subject'] ?? 'General';

// Get assigned classes
$classes_stmt = $pdo->prepare("SELECT DISTINCT class_name FROM teacher_classes WHERE teacher_id = ?");
$classes_stmt->execute([$teacher['id']]);
$assigned_classes = $classes_stmt->fetchAll(PDO::FETCH_COLUMN);

if (empty($assigned_classes)) {
    $assigned_classes = ['Grade 10A', 'Grade 10B', 'Grade 11A']; // Default
}

// Stats
$stmt = $pdo->prepare("SELECT COUNT(*) FROM exams WHERE created_by = ?");
$stmt->execute([$teacher['id']]);
$my_exams_count = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE recorded_by = ? AND DATE(date) = CURDATE()");
$stmt->execute([$teacher['id']]);
$today_attendance = $stmt->fetchColumn();

if (!empty($assigned_classes)) {
    $placeholders = str_repeat('?,', count($assigned_classes) - 1) . '?';
    $assigned_students_stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE grade_level IN ($placeholders)");
    $assigned_students_stmt->execute($assigned_classes);
    $assigned_students_count = $assigned_students_stmt->fetchColumn();
} else {
    $assigned_students_count = 0;
}

// Recent exams
$recent_exams_stmt = $pdo->prepare("SELECT * FROM exams WHERE created_by = ? ORDER BY created_at DESC LIMIT 5");
$recent_exams_stmt->execute([$teacher['id']]);
$recent_exams = $recent_exams_stmt->fetchAll();

// Today's schedule
$today = date('l');
$schedule = [
    'Monday' => '8:00 AM - 3:00 PM - Regular Classes',
    'Tuesday' => '8:00 AM - 3:00 PM - Regular Classes',
    'Wednesday' => '8:00 AM - 3:00 PM - Regular Classes',
    'Thursday' => '8:00 AM - 3:00 PM - Regular Classes',
    'Friday' => '8:00 AM - 12:00 PM - Half Day',
    'Saturday' => 'No Classes - Weekend',
    'Sunday' => 'No Classes - Weekend'
];
$today_schedule = $schedule[$today] ?? 'No schedule available';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #0a192f;
            --accent: #00ccff;
            --white: #ffffff;
            --light-bg: #f8fafc;
            --gray: #64748b;
            --light-gray: #e2e8f0;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--white);
            color: #1e293b;
            min-height: 100vh;
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary) 0%, #0c2040 100%);
            color: var(--white);
            display: flex;
            flex-direction: column;
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
            z-index: 100;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            text-align: center;
            padding: 0 25px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 30px;
        }

        .sidebar-avatar {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--accent), #0099cc);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            font-weight: 600;
            margin: 0 auto 15px;
            color: var(--white);
            border: 3px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar-header h2 {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.8);
            background: rgba(0, 204, 255, 0.2);
            padding: 4px 12px;
            border-radius: 20px;
            display: inline-block;
        }

        .nav-links {
            list-style: none;
            flex-grow: 1;
            padding: 0 20px;
        }

        .nav-links li {
            margin-bottom: 8px;
        }

        .nav-links a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            padding: 14px 18px;
            border-radius: 10px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-links a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            transform: translateX(5px);
        }

        .nav-links a.active {
            background: var(--accent);
            color: var(--white);
            box-shadow: 0 4px 12px rgba(0, 204, 255, 0.3);
        }

        .nav-links i {
            width: 24px;
            margin-right: 12px;
            font-size: 18px;
        }

        .logout-btn {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            border: none;
            padding: 15px;
            margin: 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateY(-2px);
            border-color: rgba(255, 255, 255, 0.2);
        }

        .logout-btn i {
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
            background-color: #f8fafc;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--light-gray);
        }

        .page-header h1 {
            color: var(--primary);
            font-size: 28px;
            font-weight: 700;
            display: flex;
            align-items: center;
        }

        .page-header h1 i {
            color: var(--accent);
            margin-right: 12px;
            font-size: 26px;
        }

        .date-display {
            background: var(--white);
            padding: 10px 20px;
            border-radius: 10px;
            color: var(--gray);
            font-weight: 500;
            border: 1px solid var(--light-gray);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        /* Welcome Banner */
        .welcome-banner {
            background: linear-gradient(135deg, var(--primary), #1a365d);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            color: var(--white);
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 25px rgba(10, 25, 47, 0.2);
        }

        .welcome-banner::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 200px;
            height: 200px;
            background: radial-gradient(circle, rgba(0, 204, 255, 0.2) 0%, transparent 70%);
        }

        .welcome-banner h2 {
            font-size: 28px;
            margin-bottom: 10px;
            position: relative;
            z-index: 1;
        }

        .welcome-banner p {
            color: rgba(255, 255, 255, 0.9);
            font-size: 16px;
            position: relative;
            z-index: 1;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--white);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--light-gray);
            text-align: center;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            border-color: var(--accent);
            box-shadow: 0 10px 25px rgba(0, 204, 255, 0.1);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
            background: var(--accent);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, rgba(0, 204, 255, 0.1), rgba(0, 204, 255, 0.2));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            color: var(--accent);
            font-size: 24px;
        }

        .stat-value {
            font-size: 36px;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 5px;
        }

        .stat-label {
            color: var(--gray);
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Quick Actions */
        .quick-actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .action-card {
            background: var(--white);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--light-gray);
            transition: all 0.3s ease;
            text-align: center;
            text-decoration: none;
            color: var(--primary);
        }

        .action-card:hover {
            transform: translateY(-5px);
            border-color: var(--accent);
            box-shadow: 0 10px 25px rgba(0, 204, 255, 0.1);
            background: linear-gradient(135deg, var(--white), #f0f9ff);
        }

        .action-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, rgba(0, 204, 255, 0.1), rgba(0, 204, 255, 0.2));
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            color: var(--accent);
            font-size: 32px;
            transition: all 0.3s ease;
        }

        .action-card:hover .action-icon {
            background: linear-gradient(135deg, var(--accent), #0099cc);
            color: var(--white);
            transform: scale(1.1);
        }

        .action-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .action-desc {
            color: var(--gray);
            font-size: 14px;
        }

        /* Today's Schedule */
        .schedule-card {
            background: var(--white);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--light-gray);
            margin-bottom: 30px;
        }

        .schedule-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .schedule-header i {
            color: var(--accent);
            font-size: 24px;
            margin-right: 12px;
        }

        .schedule-header h3 {
            color: var(--primary);
            font-size: 20px;
            font-weight: 600;
        }

        .schedule-content {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .day-highlight {
            background: linear-gradient(135deg, var(--accent), #0099cc);
            color: var(--white);
            padding: 15px 25px;
            border-radius: 10px;
            font-weight: 700;
            font-size: 18px;
            text-align: center;
            min-width: 120px;
        }

        .schedule-details {
            flex: 1;
        }

        .schedule-details p {
            color: var(--gray);
            font-size: 16px;
            margin-bottom: 5px;
        }

        /* Recent Exams */
        .exams-card {
            background: var(--white);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--light-gray);
            margin-bottom: 30px;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .card-title {
            color: var(--primary);
            font-size: 20px;
            font-weight: 600;
            display: flex;
            align-items: center;
        }

        .card-title i {
            color: var(--accent);
            margin-right: 10px;
            font-size: 20px;
        }

        .view-all-btn {
            background: var(--light-bg);
            color: var(--accent);
            border: 1px solid var(--accent);
            padding: 8px 16px;
            border-radius: 20px;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .view-all-btn:hover {
            background: var(--accent);
            color: var(--white);
        }

        .exams-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .exam-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            border-radius: 10px;
            background: var(--light-bg);
            border: 1px solid var(--light-gray);
            transition: all 0.3s ease;
        }

        .exam-item:hover {
            background: var(--white);
            border-color: var(--accent);
            transform: translateX(5px);
        }

        .exam-info h4 {
            color: var(--primary);
            margin-bottom: 5px;
        }

        .exam-meta {
            display: flex;
            gap: 15px;
            font-size: 14px;
            color: var(--gray);
        }

        .exam-date {
            background: rgba(0, 204, 255, 0.1);
            color: var(--accent);
            padding: 4px 10px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 14px;
        }

        /* Assigned Classes */
        .classes-card {
            background: var(--white);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--light-gray);
        }

        .classes-list {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
        }

        .class-badge {
            background: linear-gradient(135deg, rgba(0, 204, 255, 0.1), rgba(0, 204, 255, 0.2));
            color: var(--accent);
            padding: 10px 20px;
            border-radius: 20px;
            font-weight: 600;
            border: 1px solid rgba(0, 204, 255, 0.3);
            transition: all 0.3s ease;
        }

        .class-badge:hover {
            background: linear-gradient(135deg, var(--accent), #0099cc);
            color: var(--white);
            transform: translateY(-2px);
        }

        /* No Data Message */
        .no-data {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray);
        }

        .no-data i {
            font-size: 48px;
            color: var(--accent);
            margin-bottom: 15px;
            opacity: 0.5;
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 20px;
            color: var(--gray);
            font-size: 14px;
            border-top: 1px solid var(--light-gray);
            margin-top: 30px;
            background: var(--white);
            border-radius: 10px;
        }

        .footer i {
            color: var(--accent);
            margin-right: 8px;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 80px;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .sidebar-header h2,
            .sidebar-header p,
            .nav-links span,
            .logout-btn span {
                display: none;
            }
            
            .nav-links a {
                justify-content: center;
                padding: 16px;
            }
            
            .nav-links i {
                margin-right: 0;
                font-size: 20px;
            }
            
            .sidebar-avatar {
                width: 50px;
                height: 50px;
                font-size: 22px;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                flex-direction: row;
                padding: 15px;
            }
            
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
            
            .sidebar-header {
                display: flex;
                align-items: center;
                padding: 0;
                border-bottom: none;
                margin-bottom: 0;
                margin-right: 15px;
            }
            
            .sidebar-avatar {
                width: 40px;
                height: 40px;
                margin: 0 10px 0 0;
            }
            
            .nav-links {
                display: flex;
                padding: 0;
                flex-grow: 0;
            }
            
            .nav-links li {
                margin-bottom: 0;
                margin-right: 5px;
            }
            
            .logout-btn {
                margin: 0 0 0 auto;
                padding: 10px;
            }
            
            .stats-grid,
            .quick-actions-grid {
                grid-template-columns: 1fr;
            }
            
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .schedule-content {
                flex-direction: column;
                text-align: center;
            }
        }

        @media (max-width: 480px) {
            .main-content {
                padding: 15px;
            }
            
            .welcome-banner h2 {
                font-size: 24px;
            }
            
            .stat-card,
            .action-card,
            .schedule-card,
            .exams-card,
            .classes-card {
                padding: 20px;
            }
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            animation: fadeIn 0.6s ease forwards;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-avatar"><?= strtoupper(substr($teacher_name[0] ?? 'T', 0, 1)) ?></div>
            <h2><?= htmlspecialchars($teacher_name) ?></h2>
            <p><?= htmlspecialchars($teacher_subject) ?> Teacher</p>
        </div>
        <ul class="nav-links">
            <li><a href="teacher_dashboard.php" class="active"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
            <li><a href="add_attendance.php"><i class="fas fa-calendar-check"></i> <span>Attendance</span></a></li>
            <li><a href="add_exam.php"><i class="fas fa-file-alt"></i> <span>Exams</span></a></li>
           
        </ul>
        <button class="logout-btn" onclick="window.location='../index.php'">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </button>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="page-header">
            <h1><i class="fas fa-chalkboard-teacher"></i> Teacher Dashboard</h1>
            <div class="date-display">
                <i class="fas fa-calendar"></i> <?= date('l, F j, Y') ?>
            </div>
        </div>

        <!-- Welcome Banner -->
        <div class="welcome-banner fade-in">
            <h2>Welcome back, <?= htmlspecialchars($teacher_name) ?>! 👋</h2>
            <p>Manage your classes, track attendance, and create exams efficiently.</p>
        </div>

        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card fade-in">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-value"><?= $assigned_students_count ?></div>
                <div class="stat-label">Assigned Students</div>
            </div>
            
            <div class="stat-card fade-in" style="animation-delay: 0.1s">
                <div class="stat-icon">
                    <i class="fas fa-file-alt"></i>
                </div>
                <div class="stat-value"><?= $my_exams_count ?></div>
                <div class="stat-label">My Exams</div>
            </div>
            
            <div class="stat-card fade-in" style="animation-delay: 0.2s">
                <div class="stat-icon">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <div class="stat-value"><?= $today_attendance ?></div>
                <div class="stat-label">Today's Attendance</div>
            </div>
            
            <div class="stat-card fade-in" style="animation-delay: 0.3s">
                <div class="stat-icon">
                    <i class="fas fa-chalkboard"></i>
                </div>
                <div class="stat-value"><?= count($assigned_classes) ?></div>
                <div class="stat-label">Classes</div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions-grid">
            <a href="add_attendance.php" class="action-card fade-in" style="animation-delay: 0.2s">
                <div class="action-icon">
                    <i class="fas fa-user-check"></i>
                </div>
                <h3 class="action-title">Take Attendance</h3>
                <p class="action-desc">Record attendance for your classes</p>
            </a>
            
            <a href="add_exam.php" class="action-card fade-in" style="animation-delay: 0.3s">
                <div class="action-icon">
                    <i class="fas fa-file-circle-plus"></i>
                </div>
                <h3 class="action-title">Create Exam</h3>
                <p class="action-desc">Add new exams and assignments</p>
            </a>
            
           
        </div>

      

        <!-- Footer -->
        <div class="footer">
            <p><i class="fas fa-school"></i> School Management System • Teacher Portal • <?= date('Y') ?></p>
        </div>
    </div>

    <script>
        // Simple animations
        document.addEventListener('DOMContentLoaded', () => {
            // Add fade-in animations with delay
            const elements = document.querySelectorAll('.fade-in');
            elements.forEach((el, index) => {
                el.style.opacity = '0';
                setTimeout(() => {
                    el.style.animation = `fadeIn 0.6s ease ${index * 0.1}s forwards`;
                }, 100);
            });
            
            // Add hover effects to interactive elements
            const interactiveEls = document.querySelectorAll('.stat-card, .action-card, .exam-item, .class-badge');
            interactiveEls.forEach(el => {
                el.addEventListener('mouseenter', () => {
                    el.style.transform = 'translateY(-5px)';
                });
                el.addEventListener('mouseleave', () => {
                    el.style.transform = 'translateY(0)';
                });
            });
        });
    </script>
</body>
</html>