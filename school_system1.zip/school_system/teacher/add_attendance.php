<?php
session_start();
require_once '../db.php';

// 1. Auth check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'teacher') {
    header('Location: ../index.php');
    exit();
}

// 2. Get teacher info with assigned classes
$teacher_stmt = $pdo->prepare("
    SELECT t.*, u.username 
    FROM teachers t 
    JOIN users u ON t.user_id = u.id 
    WHERE u.id = ?
");
$teacher_stmt->execute([$_SESSION['user_id']]);
$teacher = $teacher_stmt->fetch();

$message = '';
$message_type = '';

// Parse teacher's assigned classes
$teacher_classes = [];
if ($teacher && !empty($teacher['assigned_classes'])) {
    $teacher_classes = explode(',', $teacher['assigned_classes']);
}

// 3. Handle saving attendance
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_attendance'])) {
    $grade_level = $_POST['grade_level'] ?? '';
    $attendance_date = $_POST['attendance_date'] ?? date('Y-m-d');

    if (!$teacher || empty($grade_level)) {
        $message = "Teacher or grade level not found.";
        $message_type = 'error';
    } else {
        // Check if teacher is allowed to teach this grade
        if (!in_array($grade_level, $teacher_classes)) {
            $message = "❌ You are not assigned to teach $grade_level. You can only take attendance for your assigned classes.";
            $message_type = 'error';
        } else {
            $success_count = 0;
            $error_count = 0;

            if (isset($_POST['attendance']) && is_array($_POST['attendance'])) {
                foreach ($_POST['attendance'] as $student_id => $status) {
                    if (!is_numeric($student_id) || !in_array($status, ['present', 'absent', 'late', 'excused'])) continue;

                    try {
                        $check = $pdo->prepare("SELECT id FROM attendance WHERE student_id = ? AND date = ?");
                        $check->execute([$student_id, $attendance_date]);
                        $exists = $check->fetch();

                        if ($exists) {
                            $stmt = $pdo->prepare("UPDATE attendance SET status = ?, recorded_by = ? WHERE student_id = ? AND date = ?");
                            $res = $stmt->execute([$status, $teacher['id'], $student_id, $attendance_date]);
                        } else {
                            $stmt = $pdo->prepare("INSERT INTO attendance (student_id, date, status, recorded_by) VALUES (?, ?, ?, ?)");
                            $res = $stmt->execute([$student_id, $attendance_date, $status, $teacher['id']]);
                        }

                        if ($res) {
                            $success_count++;
                        } else {
                            $error_count++;
                        }
                    } catch (Exception $e) {
                        $error_count++;
                    }
                }

                if ($success_count > 0) {
                    $message = "✅ Attendance saved successfully for $success_count student(s) in $grade_level!";
                    $message_type = 'success';
                } else {
                    $message = "❌ Failed to save attendance.";
                    $message_type = 'error';
                }
            } else {
                $message = "❌ No attendance data received.";
                $message_type = 'error';
            }
        }
    }
}

// 4. Get teacher's assigned grade levels (ONLY the grades they teach)
$teacher_grade_levels = [];
if (!empty($teacher_classes)) {
    // Create placeholders for the IN clause
    $placeholders = str_repeat('?,', count($teacher_classes) - 1) . '?';
    $grade_stmt = $pdo->prepare("
        SELECT DISTINCT grade_level 
        FROM students 
        WHERE grade_level IN ($placeholders) 
        AND grade_level IS NOT NULL 
        AND grade_level != '' 
        ORDER BY grade_level
    ");
    $grade_stmt->execute($teacher_classes);
    $teacher_grade_levels = $grade_stmt->fetchAll();
}

// 5. Handle date & grade selection (from GET or POST)
$selected_date = $_GET['date'] ?? ($_POST['attendance_date'] ?? date('Y-m-d'));
$selected_grade = $_GET['grade'] ?? ($_POST['grade_level'] ?? '');

// Check if selected grade is allowed for this teacher
$is_allowed_grade = true;
if ($selected_grade && !empty($teacher_classes)) {
    $is_allowed_grade = in_array($selected_grade, $teacher_classes);
}

$students = [];
$attendance_records = [];

if ($selected_grade && $is_allowed_grade) {
    $students_stmt = $pdo->prepare("SELECT id, first_name, last_name, grade_level FROM students WHERE grade_level = ? ORDER BY first_name, last_name");
    $students_stmt->execute([$selected_grade]);
    $students = $students_stmt->fetchAll();

    if (!empty($students)) {
        $student_ids = array_column($students, 'id');
        $placeholders = str_repeat('?,', count($student_ids) - 1) . '?';
        $att_stmt = $pdo->prepare("SELECT student_id, status FROM attendance WHERE student_id IN ($placeholders) AND date = ?");
        $att_params = array_merge($student_ids, [$selected_date]);
        $att_stmt->execute($att_params);
        $att_data = $att_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

        foreach ($students as $s) {
            $sid = $s['id'];
            $attendance_records[$sid] = $att_data[$sid] ?? 'present';
        }
    }
}

// 6. Get teacher username for sidebar
$teacher_username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Teacher';
if (empty($teacher_username)) {
    $teacher_username = 'Teacher';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Take Attendance - Teacher Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #0a192f;
            --accent: #00ccff;
            --white: #ffffff;
            --light-bg: #f8fafc;
            --gray: #64748b;
            --light-gray: #e2e8f0;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #3b82f6;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--white);
            color: #1e293b;
            min-height: 100vh;
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary) 0%, #0c2040 100%);
            color: var(--white);
            display: flex;
            flex-direction: column;
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
            z-index: 100;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            text-align: center;
            padding: 0 25px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 30px;
        }

        .sidebar-avatar {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--accent), #0099cc);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            font-weight: 600;
            margin: 0 auto 15px;
            color: var(--white);
            border: 3px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar-header h2 {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.8);
            background: rgba(0, 204, 255, 0.2);
            padding: 4px 12px;
            border-radius: 20px;
            display: inline-block;
        }

        .nav-links {
            list-style: none;
            flex-grow: 1;
            padding: 0 20px;
        }

        .nav-links li {
            margin-bottom: 8px;
        }

        .nav-links a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            padding: 14px 18px;
            border-radius: 10px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-links a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            transform: translateX(5px);
        }

        .nav-links a.active {
            background: var(--accent);
            color: var(--white);
            box-shadow: 0 4px 12px rgba(0, 204, 255, 0.3);
        }

        .nav-links i {
            width: 24px;
            margin-right: 12px;
            font-size: 18px;
        }

        .logout-btn {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            border: none;
            padding: 15px;
            margin: 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateY(-2px);
            border-color: rgba(255, 255, 255, 0.2);
        }

        .logout-btn i {
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
            background-color: #f8fafc;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--light-gray);
        }

        .page-header h1 {
            color: var(--primary);
            font-size: 28px;
            font-weight: 700;
            display: flex;
            align-items: center;
        }

        .page-header h1 i {
            color: var(--accent);
            margin-right: 12px;
            font-size: 26px;
        }

        .date-display {
            background: var(--white);
            padding: 10px 20px;
            border-radius: 10px;
            color: var(--gray);
            font-weight: 500;
            border: 1px solid var(--light-gray);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        /* Card */
        .card {
            background: var(--white);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--light-gray);
            transition: all 0.3s ease;
            margin-bottom: 30px;
        }

        .card:hover {
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            border-color: var(--accent);
        }

        /* Teacher Info */
        .teacher-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
            padding: 20px;
            background: linear-gradient(135deg, #f0f9ff, #e0f2fe);
            border-radius: 12px;
            border-left: 4px solid var(--accent);
        }

        .info-item {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .info-item i {
            color: var(--accent);
            font-size: 20px;
        }

        .info-content h3 {
            color: var(--primary);
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 4px;
        }

        .info-content p {
            color: var(--gray);
            font-size: 14px;
        }

        /* Assigned Classes Display */
        .assigned-classes {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(59, 130, 246, 0.1));
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
            border-left: 4px solid var(--success);
        }

        .assigned-classes h4 {
            color: var(--primary);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.1rem;
            font-weight: 600;
        }

        .classes-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .class-badge {
            background: var(--success);
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 3px 10px rgba(16, 185, 129, 0.3);
        }

        .class-badge.selected {
            background: var(--accent);
            transform: scale(1.05);
        }

        /* Message */
        .message {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            border-left: 4px solid transparent;
        }

        .message.success {
            background: rgba(16, 185, 129, 0.1);
            border-left-color: var(--success);
            color: var(--success);
        }

        .message.error {
            background: rgba(239, 68, 68, 0.1);
            border-left-color: var(--danger);
            color: var(--danger);
        }

        .message.info {
            background: rgba(0, 204, 255, 0.1);
            border-left-color: var(--accent);
            color: var(--accent);
        }

        .message.warning {
            background: rgba(245, 158, 11, 0.1);
            border-left-color: var(--warning);
            color: #b45309;
        }

        .message i {
            font-size: 20px;
        }

        /* Form */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-label {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--primary);
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .form-label i {
            color: var(--accent);
        }

        .form-control {
            padding: 12px 16px;
            border: 2px solid var(--light-gray);
            border-radius: 8px;
            font-size: 15px;
            color: var(--primary);
            background: var(--white);
            transition: all 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(0, 204, 255, 0.1);
        }

        /* Buttons */
        .btn-group {
            display: flex;
            gap: 15px;
            margin: 25px 0;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border: 2px solid transparent;
            text-decoration: none;
        }

        .btn-primary {
            background: var(--accent);
            color: var(--white);
        }

        .btn-primary:hover {
            background: #0099cc;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 204, 255, 0.2);
        }

        .btn-secondary {
            background: var(--white);
            color: var(--gray);
            border-color: var(--light-gray);
        }

        .btn-secondary:hover {
            background: var(--light-bg);
            color: var(--primary);
            border-color: var(--accent);
        }

        .btn-success {
            background: var(--success);
            color: var(--white);
        }

        .btn-success:hover {
            background: #0da271;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(16, 185, 129, 0.2);
        }

        .btn i {
            font-size: 16px;
        }

        /* Statistics */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }

        .stat-card {
            background: var(--white);
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            border: 1px solid var(--light-gray);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            border-color: var(--accent);
            box-shadow: 0 8px 20px rgba(0, 204, 255, 0.1);
        }

        .stat-value {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-label {
            color: var(--gray);
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Attendance Table */
        .attendance-table-container {
            overflow-x: auto;
            margin: 25px 0;
        }

        .attendance-table {
            width: 100%;
            border-collapse: collapse;
            background: var(--white);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .attendance-table thead {
            background: linear-gradient(90deg, var(--primary), #1a365d);
            color: var(--white);
        }

        .attendance-table th {
            padding: 16px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .attendance-table tbody tr {
            border-bottom: 1px solid var(--light-gray);
            transition: all 0.3s ease;
        }

        .attendance-table tbody tr:hover {
            background-color: var(--light-bg);
        }

        .attendance-table td {
            padding: 16px;
        }

        .student-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .student-avatar {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--accent), #0099cc);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: var(--white);
            font-size: 16px;
        }

        .student-details h4 {
            color: var(--primary);
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 4px;
        }

        .student-details p {
            color: var(--gray);
            font-size: 14px;
        }

        /* Attendance Options */
        .attendance-options {
            display: flex;
            gap: 10px;
        }

        .attendance-btn {
            width: 50px;
            height: 50px;
            border: 2px solid transparent;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            background: var(--light-bg);
            color: var(--gray);
        }

        .attendance-btn:hover {
            transform: translateY(-2px) scale(1.1);
        }

        .attendance-btn.present {
            border-color: var(--success);
            color: var(--success);
        }

        .attendance-btn.present:hover {
            background: rgba(16, 185, 129, 0.1);
        }

        .attendance-btn.present.active {
            background: var(--success);
            color: var(--white);
        }

        .attendance-btn.absent {
            border-color: var(--danger);
            color: var(--danger);
        }

        .attendance-btn.absent:hover {
            background: rgba(239, 68, 68, 0.1);
        }

        .attendance-btn.absent.active {
            background: var(--danger);
            color: var(--white);
        }

        /* No Data Message */
        .no-data {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray);
        }

        .no-data i {
            font-size: 64px;
            color: var(--accent);
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .no-data h3 {
            color: var(--primary);
            margin-bottom: 10px;
            font-size: 20px;
        }

        .no-data p {
            font-size: 16px;
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 20px;
            color: var(--gray);
            font-size: 14px;
            border-top: 1px solid var(--light-gray);
            margin-top: 30px;
            background: var(--white);
            border-radius: 10px;
        }

        .footer i {
            color: var(--accent);
            margin-right: 8px;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 80px;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .sidebar-header h2,
            .sidebar-header p,
            .nav-links span,
            .logout-btn span {
                display: none;
            }
            
            .nav-links a {
                justify-content: center;
                padding: 16px;
            }
            
            .nav-links i {
                margin-right: 0;
                font-size: 20px;
            }
            
            .sidebar-avatar {
                width: 50px;
                height: 50px;
                font-size: 22px;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                flex-direction: row;
                padding: 15px;
            }
            
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
            
            .sidebar-header {
                display: flex;
                align-items: center;
                padding: 0;
                border-bottom: none;
                margin-bottom: 0;
                margin-right: 15px;
            }
            
            .sidebar-avatar {
                width: 40px;
                height: 40px;
                margin: 0 10px 0 0;
            }
            
            .nav-links {
                display: flex;
                padding: 0;
                flex-grow: 0;
            }
            
            .nav-links li {
                margin-bottom: 0;
                margin-right: 5px;
            }
            
            .logout-btn {
                margin: 0 0 0 auto;
                padding: 10px;
            }
            
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .btn-group {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
            }
        }

        @media (max-width: 480px) {
            .main-content {
                padding: 15px;
            }
            
            .card {
                padding: 20px;
            }
            
            .attendance-options {
                flex-direction: column;
                align-items: center;
            }
            
            .attendance-btn {
                width: 40px;
                height: 40px;
            }
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            animation: fadeIn 0.6s ease forwards;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-avatar">
                <?= $teacher ? strtoupper(substr($teacher['first_name'][0] ?? 'T', 0, 1)) : 'T' ?>
            </div>
            <h2><?= $teacher ? htmlspecialchars($teacher['first_name']) : 'Teacher' ?></h2>
            <p><?= $teacher ? htmlspecialchars($teacher['subject_specialization'] ?? 'Teacher') : 'Teacher' ?></p>
        </div>
        <ul class="nav-links">
            <li><a href="teacher_dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
            <li><a href="add_attendance.php" class="active"><i class="fas fa-calendar-check"></i> <span>Attendance</span></a></li>
            <li><a href="add_exam.php"><i class="fas fa-file-alt"></i> <span>Exams</span></a></li>
            
        </ul>
        <button class="logout-btn" onclick="window.location='../index.php'">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </button>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="page-header">
            <h1><i class="fas fa-user-check"></i> Take Attendance</h1>
            <div class="date-display">
                <i class="fas fa-calendar"></i> <?= date('l, F j, Y') ?>
            </div>
        </div>

        <!-- Main Card -->
        <div class="card fade-in">
            <?php if ($teacher): ?>
            <div class="teacher-info">
                <div class="info-item">
                    <i class="fas fa-user"></i>
                    <div class="info-content">
                        <h3>Teacher</h3>
                        <p><?= htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name']) ?></p>
                    </div>
                </div>
                <div class="info-item">
                    <i class="fas fa-book"></i>
                    <div class="info-content">
                        <h3>Subject</h3>
                        <p><?= htmlspecialchars($teacher['subject_specialization'] ?? 'Not specified') ?></p>
                    </div>
                </div>
                <div class="info-item">
                    <i class="fas fa-clock"></i>
                    <div class="info-content">
                        <h3>Current Time</h3>
                        <p><?= date('h:i A') ?></p>
                    </div>
                </div>
            </div>

            <!-- Show teacher's assigned classes -->
            <?php if (!empty($teacher_classes)): ?>
            <div class="assigned-classes fade-in">
                <h4><i class="fas fa-graduation-cap"></i> Your Assigned Classes</h4>
                <div class="classes-grid">
                    <?php foreach ($teacher_classes as $class): ?>
                        <div class="class-badge <?= ($selected_grade == $class) ? 'selected' : '' ?>" onclick="selectClass('<?= htmlspecialchars($class) ?>')">
                            <i class="fas fa-chalkboard-teacher"></i>
                            <?= htmlspecialchars($class) ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <p style="margin-top: 10px; color: var(--gray); font-size: 0.9rem;">
                    <i class="fas fa-info-circle"></i> You can only take attendance for these classes
                </p>
            </div>
            <?php else: ?>
            <div class="message warning fade-in">
                <i class="fas fa-exclamation-triangle"></i>
                You have not been assigned to any classes. Please contact admin.
            </div>
            <?php endif; ?>

            <?php endif; ?>

            <?php if ($message): ?>
                <div class="message <?= $message_type ?> fade-in">
                    <i class="fas fa-<?= $message_type === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <!-- Check if teacher is trying to access unauthorized grade -->
            <?php if ($selected_grade && !$is_allowed_grade): ?>
                <div class="message error fade-in">
                    <i class="fas fa-ban"></i>
                    <strong>Access Denied!</strong> You are not assigned to teach <?= htmlspecialchars($selected_grade) ?>.
                    You can only take attendance for: <?= !empty($teacher_classes) ? implode(', ', $teacher_classes) : 'No assigned classes' ?>
                </div>
            <?php endif; ?>

            <!-- Search Form -->
            <form method="GET" class="fade-in">
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label" for="grade">
                            <i class="fas fa-graduation-cap"></i>
                            <span>Grade Level</span>
                        </label>
                        <select class="form-control" name="grade" id="grade" required>
                            <option value="">-- Select Your Class --</option>
                            <?php if (!empty($teacher_grade_levels)): ?>
                                <?php foreach ($teacher_grade_levels as $grade): ?>
                                    <option value="<?= htmlspecialchars($grade['grade_level']) ?>" 
                                        <?= ($selected_grade == $grade['grade_level']) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($grade['grade_level']) ?>
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="date">
                            <i class="fas fa-calendar-alt"></i>
                            <span>Date</span>
                        </label>
                        <input type="date" class="form-control" name="date" value="<?= htmlspecialchars($selected_date) ?>" required>
                    </div>
                </div>
                <div class="btn-group">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i>
                        <span>View Attendance</span>
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="window.location='add_attendance.php'">
                        <i class="fas fa-times"></i>
                        <span>Clear</span>
                    </button>
                </div>
            </form>

            <?php if ($selected_date !== date('Y-m-d')): ?>
                <div class="message info fade-in">
                    <i class="fas fa-eye"></i>
                    Viewing attendance for <strong><?= date('l, F j, Y', strtotime($selected_date)) ?></strong>
                </div>
            <?php endif; ?>

            <?php if ($selected_grade && $is_allowed_grade && $students): ?>
                <?php
                $present_count = array_count_values($attendance_records)['present'] ?? 0;
                $absent_count = array_count_values($attendance_records)['absent'] ?? 0;
                ?>
                
                <div class="stats-grid fade-in">
                    <div class="stat-card">
                        <div class="stat-value" style="color: var(--primary);"><?= count($students) ?></div>
                        <div class="stat-label">Total Students</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value" style="color: var(--success);"><?= $present_count ?></div>
                        <div class="stat-label">Present</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value" style="color: var(--danger);"><?= $absent_count ?></div>
                        <div class="stat-label">Absent</div>
                    </div>
                </div>

                <form method="POST">
                    <input type="hidden" name="grade_level" value="<?= htmlspecialchars($selected_grade) ?>">
                    <input type="hidden" name="attendance_date" value="<?= htmlspecialchars($selected_date) ?>">
                    
                    <div class="attendance-table-container">
                        <table class="attendance-table">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>Attendance Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($students as $student): 
                                    $sid = $student['id'];
                                    $status = $attendance_records[$sid] ?? 'present';
                                    $initial = strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1));
                                ?>
                                <tr>
                                    <td>
                                        <div class="student-info">
                                            <div class="student-avatar"><?= $initial ?></div>
                                            <div class="student-details">
                                                <h4><?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></h4>
                                                <p>ID: <?= $sid ?> | <?= htmlspecialchars($student['grade_level']) ?></p>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="attendance-options">
                                            <button type="button" class="attendance-btn present <?= ($status === 'present') ? 'active' : '' ?>" 
                                                onclick="setAttendance(<?= $sid ?>, 'present')">
                                                <i class="fas fa-check"></i>
                                            </button>
                                            <button type="button" class="attendance-btn absent <?= ($status === 'absent') ? 'active' : '' ?>" 
                                                onclick="setAttendance(<?= $sid ?>, 'absent')">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </div>
                                        <input type="hidden" name="attendance[<?= $sid ?>]" id="attendance_<?= $sid ?>" value="<?= $status ?>">
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="btn-group" style="justify-content: center; margin-top: 25px;">
                        <button type="submit" class="btn btn-success" name="save_attendance">
                            <i class="fas fa-save"></i>
                            <span><?= !empty($attendance_records) ? 'Update' : 'Save' ?> Attendance</span>
                        </button>
                    </div>
                </form>

            <?php elseif ($selected_grade && $is_allowed_grade): ?>
                <div class="no-data fade-in">
                    <i class="fas fa-users-slash"></i>
                    <h3>No Students Found</h3>
                    <p>No students found in <strong><?= htmlspecialchars($selected_grade) ?></strong>.</p>
                </div>
            <?php elseif ($selected_grade && !$is_allowed_grade): ?>
                <!-- Already handled above -->
            <?php else: ?>
                <div class="no-data fade-in">
                    <i class="fas fa-graduation-cap"></i>
                    <h3>Select Your Class</h3>
                    <p>Please select one of your assigned classes to take attendance.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p><i class="fas fa-school"></i> School Management System • Teacher Portal • <?= date('Y') ?></p>
        </div>
    </div>

    <script>
        function setAttendance(studentId, status) {
            const input = document.getElementById(`attendance_${studentId}`);
            const row = input.closest('tr');
            
            // Remove active class from all buttons in this row
            row.querySelectorAll('.attendance-btn').forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            row.querySelector(`.attendance-btn.${status}`).classList.add('active');
            
            // Update hidden input value
            input.value = status;
            
            // Add visual feedback
            const btn = row.querySelector(`.attendance-btn.${status}`);
            btn.style.transform = 'scale(1.1)';
            setTimeout(() => {
                btn.style.transform = '';
            }, 200);
        }

        function selectClass(className) {
            const gradeSelect = document.getElementById('grade');
            gradeSelect.value = className;
            
            // Update visual selection
            document.querySelectorAll('.class-badge').forEach(badge => {
                if (badge.textContent.includes(className)) {
                    badge.classList.add('selected');
                } else {
                    badge.classList.remove('selected');
                }
            });
            
            // Auto-submit the form
            gradeSelect.closest('form').submit();
        }

        // Set today as default if empty
        document.addEventListener('DOMContentLoaded', () => {
            const dateInput = document.querySelector('input[name="date"]');
            if (!dateInput.value) {
                dateInput.value = new Date().toISOString().split('T')[0];
            }
            
            // Add fade-in animations
            const elements = document.querySelectorAll('.fade-in');
            elements.forEach((el, index) => {
                el.style.opacity = '0';
                setTimeout(() => {
                    el.style.animation = `fadeIn 0.6s ease ${index * 0.1}s forwards`;
                }, 100);
            });
        });
    </script>
</body>
</html>