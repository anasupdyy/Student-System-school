<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $email = trim($_POST['email']);
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    
    // Get selected subjects and classes
    $subject_specialization = isset($_POST['subject_specialization']) ? array_map('trim', $_POST['subject_specialization']) : [];
    $assigned_classes = isset($_POST['assigned_classes']) ? array_map('trim', $_POST['assigned_classes']) : [];
    
    // Validation
    if (empty($subject_specialization)) {
        $_SESSION['error'] = "Please select at least one subject for the teacher.";
    } elseif (empty($username) || empty($password) || empty($email) || empty($first_name) || empty($last_name)) {
        $_SESSION['error'] = "All fields are required.";
    } else {
        // ✅ Validate subject-class compatibility with FLEXIBLE rules
        $validation_errors = validateTeacherAssignment($subject_specialization, $assigned_classes);
        
        if (!empty($validation_errors)) {
            $_SESSION['error'] = implode("<br>", $validation_errors);
        } else {
            // ✅ Check for duplicate subject-class assignments
            $duplicate_errors = checkDuplicateAssignments($subject_specialization, $assigned_classes);
            
            if (!empty($duplicate_errors)) {
                $_SESSION['error'] = implode("<br>", $duplicate_errors);
            } else {
                $subject_specialization_str = implode(',', $subject_specialization);
                $assigned_classes_str = !empty($assigned_classes) ? implode(',', array_map('trim', $assigned_classes)) : '';

                try {
                    $pdo->beginTransaction();

                    $stmt = $pdo->prepare("INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, 'teacher')");
                    $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT), $email]);
                    $user_id = $pdo->lastInsertId();

                    $stmt = $pdo->prepare("INSERT INTO teachers (user_id, first_name, last_name, subject_specialization, assigned_classes, hire_date) VALUES (?, ?, ?, ?, ?, CURDATE())");
                    $stmt->execute([$user_id, $first_name, $last_name, $subject_specialization_str, $assigned_classes_str]);

                    $pdo->commit();
                    $_SESSION['success'] = "Teacher account created successfully with " . count($subject_specialization) . " subject(s)!";
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $_SESSION['error'] = "Error: " . $e->getMessage();
                }
            }
        }
    }

    header('Location: create_teacher.php');
    exit();
}

// Function to check for duplicate subject-class assignments
function checkDuplicateAssignments($subjects, $classes) {
    global $pdo;
    $errors = [];
    
    // If no classes assigned, no duplicate check needed
    if (empty($classes)) {
        return $errors;
    }
    
    // Get all existing teachers with their subjects and classes
    $stmt = $pdo->query("
        SELECT t.subject_specialization, t.assigned_classes, u.username 
        FROM teachers t 
        JOIN users u ON t.user_id = u.id 
        WHERE t.assigned_classes != '' AND t.assigned_classes IS NOT NULL
    ");
    $existing_teachers = $stmt->fetchAll();
    
    // Check each new assignment against existing ones
    foreach ($classes as $class) {
        foreach ($subjects as $subject) {
            // Check if this subject-class combination already exists
            foreach ($existing_teachers as $teacher) {
                $teacher_subjects = !empty($teacher['subject_specialization']) ? explode(',', $teacher['subject_specialization']) : [];
                $teacher_classes = !empty($teacher['assigned_classes']) ? explode(',', $teacher['assigned_classes']) : [];
                
                if (in_array($subject, $teacher_subjects) && in_array($class, $teacher_classes)) {
                    $errors[] = "❌ <strong>$subject</strong> in <strong>$class</strong> is already assigned to teacher <strong>{$teacher['username']}</strong>";
                }
            }
        }
    }
    
    return $errors;
}

// Function to validate subject-class compatibility with FLEXIBLE rules
function validateTeacherAssignment($subjects, $classes) {
    $errors = [];
    
    // If no classes assigned, it's okay (teacher can be without specific classes)
    if (empty($classes)) {
        return $errors;
    }
    
    // School levels with subjects
    $school_levels = [
        'dugsi_hoose' => [
            'name' => 'Dugsi Hoose (Grade 1-4)',
            'grades' => ['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4'],
            'subjects' => ['Somali', 'English', 'Carabi', 'Xisaab', 'Tarbiyo']
        ],
        'dugsi_dhexe' => [
            'name' => 'Dugsi Dhexe (Grade 5-8)',
            'grades' => ['Grade 5', 'Grade 6', 'Grade 7', 'Grade 8'],
            'subjects' => ['Somali', 'English', 'Carabi', 'Xisaab', 'Tarbiyo', 'Saynis', 'Soshiyal']
        ],
        'dugsi_sare' => [
            'name' => 'Dugsi Sare (Grade 9-12)',
            'grades' => ['Grade 9', 'Grade 10', 'Grade 11', 'Grade 12'],
            'subjects' => ['Somali', 'English', 'Carabi', 'Xisaab', 'Tarbiyo', 'Physics', 'Biology', 'Chemistry', 'Technology', 'Business', 'Tariikh', 'Jugrafi']
        ]
    ];
    
    // CORE SUBJECTS - Can be taught at ALL levels
    $core_subjects = ['Somali', 'English', 'Carabi', 'Xisaab', 'Tarbiyo'];
    
    // SUBJECT LEVEL RULES:
    // 1. Core subjects can be taught at ALL levels
    // 2. Middle School subjects can be taught in Middle AND High School
    // 3. High School subjects can ONLY be taught in High School
    // 4. Primary School teachers can ONLY teach core subjects
    
    $middle_school_subjects = ['Saynis', 'Soshiyal'];
    $high_school_subjects = ['Physics', 'Biology', 'Chemistry', 'Technology', 'Business', 'Tariikh', 'Jugrafi'];
    
    // Check each assigned class
    foreach ($classes as $class) {
        // Determine which level this class belongs to
        $level = '';
        foreach ($school_levels as $level_key => $level_info) {
            if (in_array($class, $level_info['grades'])) {
                $level = $level_key;
                break;
            }
        }
        
        if ($level) {
            // Check each selected subject against this class level
            foreach ($subjects as $subject) {
                $error_found = false;
                
                // RULE 1: If subject is core subject, it's ALWAYS allowed
                if (in_array($subject, $core_subjects)) {
                    continue; // Skip to next subject
                }
                
                // RULE 2: Primary School (Grade 1-4) - Only core subjects allowed
                if ($level === 'dugsi_hoose') {
                    if (!in_array($subject, $core_subjects)) {
                        $error_found = true;
                        $reason = "Primary School (Grade 1-4) can only teach core subjects (Somali, English, Carabi, Xisaab, Tarbiyo)";
                    }
                }
                
                // RULE 3: Middle School (Grade 5-8) - Core + Middle School subjects
                elseif ($level === 'dugsi_dhexe') {
                    if (in_array($subject, $high_school_subjects)) {
                        $error_found = true;
                        $reason = "Middle School (Grade 5-8) cannot teach High School specialized subjects";
                    }
                    // Middle school subjects and core subjects are allowed
                }
                
                // RULE 4: High School (Grade 9-12) - All subjects allowed
                // (Core, Middle School, and High School subjects)
                elseif ($level === 'dugsi_sare') {
                    // All subjects are allowed in High School
                    continue;
                }
                
                // Add error if found
                if ($error_found) {
                    $errors[] = "❌ <strong>$subject</strong> cannot be taught in <strong>$class</strong><br><small>$reason</small>";
                }
            }
        }
    }
    
    // SPECIAL CASE: If teacher has High School subjects, they CANNOT teach Primary School
    // But they CAN teach Middle School AND High School
    $has_high_school_subjects = !empty(array_intersect($subjects, $high_school_subjects));
    $has_primary_classes = false;
    $primary_classes = [];
    
    if ($has_high_school_subjects) {
        foreach ($classes as $class) {
            if (in_array($class, $school_levels['dugsi_hoose']['grades'])) {
                $has_primary_classes = true;
                $primary_classes[] = $class;
            }
        }
        
        if ($has_primary_classes) {
            $primary_class_list = implode(', ', $primary_classes);
            $errors[] = "❌ Teacher with High School specialized subjects (Physics, Biology, Chemistry, etc.) cannot teach Primary School classes ($primary_class_list)";
        }
    }
    
    return $errors;
}

// School levels for display
$school_levels = [
    'dugsi_hoose' => [
        'name' => 'Dugsi Hoose (Grade 1-4)',
        'grades' => ['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4'],
        'subjects' => ['Somali', 'English', 'Carabi', 'Xisaab', 'Tarbiyo']
    ],
    'dugsi_dhexe' => [
        'name' => 'Dugsi Dhexe (Grade 5-8)',
        'grades' => ['Grade 5', 'Grade 6', 'Grade 7', 'Grade 8'],
        'subjects' => ['Somali', 'English', 'Carabi', 'Xisaab', 'Tarbiyo', 'Saynis', 'Soshiyal']
    ],
    'dugsi_sare' => [
        'name' => 'Dugsi Sare (Grade 9-12)',
        'grades' => ['Grade 9', 'Grade 10', 'Grade 11', 'Grade 12'],
        'subjects' => ['Somali', 'English', 'Carabi', 'Xisaab', 'Tarbiyo', 'Physics', 'Biology', 'Chemistry', 'Technology', 'Business', 'Tariikh', 'Jugrafi']
    ]
];

// Get existing assignments for display warnings
$stmt = $pdo->query("
    SELECT t.subject_specialization, t.assigned_classes, u.username 
    FROM teachers t 
    JOIN users u ON t.user_id = u.id 
    WHERE t.assigned_classes != '' AND t.assigned_classes IS NOT NULL
");
$existing_assignments = $stmt->fetchAll();

// Prepare assignment map for JavaScript
$assignment_map = [];
foreach ($existing_assignments as $teacher) {
    $teacher_subjects = !empty($teacher['subject_specialization']) ? explode(',', $teacher['subject_specialization']) : [];
    $teacher_classes = !empty($teacher['assigned_classes']) ? explode(',', $teacher['assigned_classes']) : [];
    
    foreach ($teacher_classes as $class) {
        foreach ($teacher_subjects as $subject) {
            $assignment_map[] = [
                'class' => $class,
                'subject' => $subject,
                'teacher' => $teacher['username']
            ];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Teacher Account | EduFlow Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-dark: #0a192f;
            --primary-blue: #00ccff;
            --white: #ffffff;
            --light-gray: #f8fafc;
            --text-dark: #1e293b;
            --text-light: #64748b;
            --success: #00cc7a;
            --warning: #ff9d00;
            --danger: #ff4757;
            --gradient: linear-gradient(135deg, #00ccff 0%, #0099ff 100%);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--light-gray);
            color: var(--text-dark);
            min-height: 100vh;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 280px;
            background: var(--primary-dark);
            color: var(--white);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            transition: all 0.3s ease;
            z-index: 100;
            box-shadow: 2px 0 15px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(0, 0, 0, 0.2);
        }

        .sidebar-header h3 {
            font-size: 1.6rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            color: var(--white);
            font-weight: 700;
        }

        .sidebar-header h3 i {
            color: var(--primary-blue);
            font-size: 1.8rem;
        }

        .sidebar-header p {
            color: var(--primary-blue);
            font-size: 0.9rem;
            opacity: 0.8;
            margin-top: 8px;
        }

        .sidebar-menu {
            padding: 30px 0;
        }

        .sidebar-menu ul {
            list-style: none;
        }

        .sidebar-menu li {
            margin: 5px 20px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 18px 20px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            border-left: 4px solid transparent;
            transition: all 0.3s ease;
            border-radius: 10px;
            font-weight: 500;
        }

        .sidebar-menu a:hover {
            background: rgba(0, 204, 255, 0.15);
            color: var(--white);
            transform: translateX(5px);
        }

        .sidebar-menu a.active {
            background: rgba(0, 204, 255, 0.25);
            color: var(--white);
            border-left: 4px solid var(--primary-blue);
        }

        .sidebar-menu a i {
            margin-right: 15px;
            width: 25px;
            text-align: center;
            font-size: 1.3rem;
        }

        .sidebar-menu a.active i {
            color: var(--primary-blue);
        }

        .sidebar-footer {
            position: absolute;
            bottom: 0;
            width: 100%;
            padding: 20px;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            font-size: 0.9rem;
            color: rgba(255, 255, 255, 0.6);
            background: rgba(0, 0, 0, 0.2);
        }

        .sidebar-footer i {
            color: var(--primary-blue);
            margin-right: 8px;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            animation: fadeIn 0.8s ease-out;
        }

        .header {
            background: var(--white);
            padding: 25px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.05);
            border-bottom: 1px solid #eaeaea;
        }

        .header-title h1 {
            font-size: 1.8rem;
            color: var(--primary-dark);
            display: flex;
            align-items: center;
            gap: 15px;
            font-weight: 700;
        }

        .header-title h1 i {
            color: var(--primary-blue);
            font-size: 2rem;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            padding: 12px 22px;
            border-radius: 30px;
            background: var(--light-gray);
            transition: all 0.3s ease;
            cursor: pointer;
            border: 1px solid #eaeaea;
        }

        .user-profile:hover {
            background: #e6f7ff;
            border-color: var(--primary-blue);
            transform: translateY(-2px);
        }

        .user-profile img {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            margin-right: 15px;
            border: 2px solid var(--primary-blue);
        }

        .user-profile span {
            font-weight: 600;
            color: var(--primary-dark);
        }

        .content {
            flex: 1;
            padding: 30px;
            background: var(--light-gray);
        }

        .welcome-banner {
            background: linear-gradient(135deg, rgba(0, 204, 255, 0.1), rgba(10, 25, 47, 0.05));
            margin-bottom: 30px;
            padding: 25px 30px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            animation: fadeIn 0.8s ease-out;
            border: 1px solid rgba(0, 204, 255, 0.2);
        }

        .banner-content h2 {
            color: var(--primary-dark);
            font-size: 1.5rem;
            margin-bottom: 8px;
            font-weight: 600;
        }

        .banner-content p {
            color: var(--text-light);
            font-size: 1rem;
        }

        .banner-icon {
            font-size: 3.5rem;
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: float 3s ease-in-out infinite;
        }

        .main-card {
            background: var(--white);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.05);
            border: 1px solid #eaeaea;
            animation: fadeIn 0.8s ease-out;
        }

        .main-card h2 {
            color: var(--primary-dark);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 600;
        }

        .main-card p {
            color: var(--text-light);
            margin-bottom: 25px;
            font-size: 1rem;
        }

        .alert {
            padding: 20px 25px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 15px;
            animation: slideInRight 0.5s ease-out;
        }

        .alert-success {
            background: rgba(0, 204, 122, 0.1);
            border-left: 4px solid var(--success);
            color: #006644;
        }

        .alert-danger {
            background: rgba(255, 71, 87, 0.1);
            border-left: 4px solid var(--danger);
            color: #cc3342;
        }

        .alert-warning {
            background: rgba(255, 157, 0, 0.1);
            border-left: 4px solid var(--warning);
            color: #996100;
        }

        .alert-info {
            background: rgba(0, 204, 255, 0.1);
            border-left: 4px solid var(--primary-blue);
            color: #0066cc;
        }

        .alert i {
            font-size: 1.3rem;
        }

        .alert-success i {
            color: var(--success);
        }

        .alert-danger i {
            color: var(--danger);
        }

        .alert-warning i {
            color: var(--warning);
        }

        .alert-info i {
            color: var(--primary-blue);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            color: var(--primary-dark);
            font-weight: 600;
            font-size: 1rem;
        }

        .form-control {
            width: 100%;
            padding: 15px 20px;
            border-radius: 10px;
            border: 2px solid #eaeaea;
            font-size: 1rem;
            background: var(--white);
            transition: all 0.3s ease;
            color: var(--text-dark);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(0, 204, 255, 0.15);
        }

        /* Subject Selection Styling */
        .subject-selection-container {
            background: rgba(0, 204, 255, 0.05);
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 30px;
            border: 1px solid rgba(0, 204, 255, 0.1);
        }

        .subject-selection-container h3 {
            color: var(--primary-dark);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.3rem;
            font-weight: 600;
        }

        .subject-selection-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 12px;
            margin-bottom: 20px;
        }

        .subject-checkbox {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 15px;
            background: var(--white);
            border: 2px solid #eaeaea;
            border-radius: 8px;
            transition: all 0.3s ease;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }

        .subject-checkbox:hover {
            border-color: var(--primary-blue);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 204, 255, 0.1);
        }

        .subject-checkbox.selected {
            background: linear-gradient(135deg, rgba(0, 204, 255, 0.1), rgba(0, 153, 255, 0.05));
            border-color: var(--primary-blue);
            color: var(--primary-blue);
        }

        .subject-checkbox input[type="checkbox"] {
            position: absolute;
            opacity: 0;
            width: 0;
            height: 0;
        }

        .subject-checkbox .checkmark {
            width: 20px;
            height: 20px;
            border-radius: 4px;
            border: 2px solid #ddd;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            flex-shrink: 0;
        }

        .subject-checkbox.selected .checkmark {
            background: var(--primary-blue);
            border-color: var(--primary-blue);
        }

        .subject-checkbox .checkmark i {
            color: white;
            font-size: 0.8rem;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .subject-checkbox.selected .checkmark i {
            opacity: 1;
        }

        .subject-checkbox label {
            margin-bottom: 0;
            cursor: pointer;
            font-weight: 500;
            color: var(--text-dark);
            flex: 1;
        }

        .subject-checkbox.selected label {
            color: var(--primary-blue);
            font-weight: 600;
        }

        /* Subject level indicators */
        .subject-level {
            font-size: 0.7rem;
            padding: 2px 6px;
            border-radius: 10px;
            font-weight: 600;
            margin-left: auto;
            white-space: nowrap;
        }

        .level-core {
            background: rgba(0, 204, 122, 0.2);
            color: #006644;
        }

        .level-middle-high {
            background: rgba(0, 153, 255, 0.2);
            color: #0066cc;
        }

        .level-high {
            background: rgba(153, 0, 255, 0.2);
            color: #6600cc;
        }

        .subject-icon {
            width: 30px;
            height: 30px;
            border-radius: 6px;
            background: rgba(0, 204, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-blue);
            font-size: 1rem;
        }

        /* Class Assignment */
        .class-assignment {
            background: rgba(0, 204, 255, 0.05);
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 30px;
            border: 1px solid rgba(0, 204, 255, 0.1);
        }

        .class-assignment h3 {
            color: var(--primary-dark);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.3rem;
            font-weight: 600;
        }

        .school-level {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }

        .school-level:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }

        .school-level h4 {
            color: var(--primary-blue);
            margin-bottom: 15px;
            font-size: 1.1rem;
            font-weight: 600;
        }

        .grades-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
            gap: 12px;
        }

        .grade-checkbox {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 12px;
            background: var(--white);
            border: 2px solid #eaeaea;
            border-radius: 8px;
            transition: all 0.3s ease;
            cursor: pointer;
            position: relative;
        }

        .grade-checkbox:hover {
            border-color: var(--primary-blue);
            transform: translateY(-2px);
        }

        .grade-checkbox input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .grade-checkbox label {
            margin-bottom: 0;
            cursor: pointer;
            font-weight: 500;
            color: var(--text-dark);
            flex: 1;
        }

        .grade-checkbox.assigned::after {
            content: '✓ Assigned';
            position: absolute;
            top: -8px;
            right: -8px;
            background: var(--warning);
            color: white;
            font-size: 0.6rem;
            padding: 2px 6px;
            border-radius: 10px;
            font-weight: 600;
        }

        /* Counter Display */
        .counter-display {
            background: rgba(0, 204, 255, 0.1);
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border: 1px solid rgba(0, 204, 255, 0.2);
        }

        .counter-text {
            color: var(--text-dark);
            font-weight: 500;
        }

        .counter-number {
            background: var(--primary-blue);
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 1rem;
            box-shadow: 0 3px 10px rgba(0, 204, 255, 0.3);
        }

        /* Existing Assignments */
        .assignments-box {
            background: rgba(255, 157, 0, 0.05);
            border-radius: 12px;
            padding: 20px;
            margin: 20px 0;
            border: 1px solid rgba(255, 157, 0, 0.1);
        }

        .assignments-box h4 {
            color: var(--warning);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.1rem;
            font-weight: 600;
        }

        .assignments-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 10px;
            margin-bottom: 15px;
        }

        .assignment-item {
            background: var(--white);
            border: 1px solid rgba(255, 157, 0, 0.2);
            border-radius: 8px;
            padding: 10px 15px;
            font-size: 0.9rem;
        }

        .assignment-class {
            font-weight: 600;
            color: var(--warning);
        }

        .assignment-subject {
            color: var(--text-dark);
            margin: 5px 0;
        }

        .assignment-teacher {
            font-size: 0.8rem;
            color: var(--text-light);
            font-style: italic;
        }

        /* Compatibility Rules Box */
        .rules-box {
            background: rgba(0, 204, 255, 0.05);
            border-radius: 12px;
            padding: 20px;
            margin: 20px 0;
            border: 1px solid rgba(0, 204, 255, 0.1);
        }

        .rules-box h4 {
            color: var(--primary-blue);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.1rem;
            font-weight: 600;
        }

        .rule-list {
            list-style-type: none;
            padding-left: 0;
        }

        .rule-list li {
            margin-bottom: 10px;
            padding-left: 25px;
            position: relative;
            color: var(--text-dark);
            line-height: 1.5;
        }

        .rule-list li:before {
            content: '✓';
            position: absolute;
            left: 0;
            color: var(--success);
            font-weight: bold;
        }

        .rule-list li.warning:before {
            content: '⚠️';
            color: var(--warning);
        }

        .info-box {
            background: rgba(0, 204, 255, 0.05);
            border-radius: 12px;
            padding: 20px 25px;
            margin: 25px 0;
            border: 1px solid rgba(0, 204, 255, 0.1);
        }

        .info-box h4 {
            color: var(--primary-blue);
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.1rem;
            font-weight: 600;
        }

        .info-box p {
            color: var(--text-dark);
            margin-bottom: 0;
            line-height: 1.6;
        }

        .info-box strong {
            color: var(--primary-dark);
        }

        /* Duplicate Warning */
        .duplicate-warning {
            background: rgba(255, 157, 0, 0.1);
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
            border: 1px solid rgba(255, 157, 0, 0.3);
            display: none;
        }

        .duplicate-warning.show {
            display: block;
            animation: fadeIn 0.5s ease;
        }

        .warning-icon {
            color: var(--warning);
            font-size: 1.2rem;
            margin-right: 10px;
        }

        .warning-text {
            color: #996100;
            font-weight: 500;
        }

        .btn {
            padding: 14px 28px;
            border-radius: 10px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            text-decoration: none;
            font-size: 1rem;
            gap: 12px;
        }

        .btn-primary {
            background: var(--gradient);
            color: var(--white);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 204, 255, 0.3);
        }

        .btn-secondary {
            background: var(--light-gray);
            color: var(--text-dark);
            border: 1px solid #eaeaea;
        }

        .btn-secondary:hover {
            background: #e6f7ff;
            border-color: var(--primary-blue);
            transform: translateY(-3px);
        }

        .footer {
            background: var(--primary-dark);
            padding: 25px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.95rem;
        }

        .footer-links {
            display: flex;
            gap: 25px;
        }

        .footer-links a {
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            transition: color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
        }

        .footer-links a:hover {
            color: var(--primary-blue);
            transform: translateY(-2px);
        }

        .footer-links a i {
            font-size: 1.1rem;
        }

        .footer-copyright {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .footer-copyright i {
            color: var(--danger);
            animation: heartbeat 1.5s infinite;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideInRight {
            from { opacity: 0; transform: translateX(30px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-8px); }
        }

        @keyframes heartbeat {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.2); }
        }

        @media (max-width: 1200px) {
            .sidebar { width: 80px; }
            .main-content { margin-left: 80px; }
            .sidebar-header h3 span, .sidebar-header p, .sidebar-menu a span, .sidebar-footer span { display: none; }
            .sidebar:hover { width: 280px; }
            .sidebar:hover .sidebar-header h3 span, .sidebar:hover .sidebar-header p, .sidebar:hover .sidebar-menu a span, .sidebar:hover .sidebar-footer span { display: inline; }
        }

        @media (max-width: 992px) {
            .form-row { grid-template-columns: 1fr; }
            .subject-selection-grid { grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); }
            .grades-grid { grid-template-columns: repeat(auto-fill, minmax(90px, 1fr)); }
            .assignments-grid { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 768px) {
            .header { flex-direction: column; gap: 20px; padding: 20px; }
            .content { padding: 20px; }
            .welcome-banner { flex-direction: column; text-align: center; gap: 20px; padding: 20px; }
            .main-card { padding: 25px; }
            .subject-selection-container { padding: 20px; }
            .class-assignment { padding: 20px; }
            .footer { flex-direction: column; text-align: center; gap: 20px; padding: 20px; }
            .footer-links { flex-wrap: wrap; justify-content: center; gap: 15px; }
            .btn { width: 100%; justify-content: center; margin-bottom: 10px; }
            .subject-selection-grid { grid-template-columns: repeat(2, 1fr); }
            .grades-grid { grid-template-columns: repeat(3, 1fr); }
            .assignments-grid { grid-template-columns: 1fr; }
        }

        @media (max-width: 480px) {
            .sidebar { width: 0; }
            .main-content { margin-left: 0; }
            .sidebar.active { width: 280px; z-index: 1000; }
            .menu-toggle { display: block; position: fixed; top: 20px; left: 20px; z-index: 1001; background: var(--primary-blue); color: white; border: none; padding: 12px; border-radius: 8px; cursor: pointer; font-size: 1.2rem; }
            .header-title h1 { font-size: 1.4rem; }
            .subject-selection-grid { grid-template-columns: 1fr; }
            .grades-grid { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
</head>
<body>
    <button class="menu-toggle" id="menuToggle" style="display: none;">
        <i class="fas fa-bars"></i>
    </button>

    <div class="container">
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h3><i class="fas fa-chalkboard-teacher"></i> <span>EduFlow</span></h3>
                <p><span>Teacher Registration</span></p>
            </div>
            <div class="sidebar-menu">
                <ul>
                    <li><a href="../admin/admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a></li>
                    <li><a href="../student/manage_students.php"><i class="fas fa-user-graduate"></i> <span>Students</span></a></li>
                    <li><a href="manage_teachers.php"><i class="fas fa-chalkboard-teacher"></i> <span>Teachers</span></a></li>
                    <li><a href="create_teacher.php" class="active"><i class="fas fa-user-plus"></i> <span>Create Teacher</span></a></li>
                    <li><a href="../admin/create_admin.php"><i class="fas fa-user-shield"></i> <span>Admins</span></a></li>
                    <li><a href="../index.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
                </ul>
            </div>
            <div class="sidebar-footer">
                <p><i class="fas fa-code"></i> <span>EduFlow v1.0</span></p>
            </div>
        </div>

        <div class="main-content">
            <div class="header">
                <div class="header-title">
                    <h1><i class="fas fa-user-plus"></i> Create Teacher Account</h1>
                </div>
                <div class="header-actions">
                    <div class="user-profile">
                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['username']); ?>&background=00ccff&color=fff&size=128" alt="Admin">
                        <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    </div>
                </div>
            </div>

            <div class="content">
                <div class="welcome-banner">
                    <div class="banner-content">
                        <h2>Register New Teacher</h2>
                        <p>Select subjects and classes with intelligent compatibility checking</p>
                    </div>
                    <div class="banner-icon">
                        <i class="fas fa-chalkboard-teacher"></i>
                    </div>
                </div>

                <div class="main-card">
                    <h2><i class="fas fa-user-plus"></i> Teacher Information</h2>
                    <p>Enter details and select subjects (1 or more).</p>

                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> 
                            <span><?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></span>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle"></i> 
                            <div style="flex: 1;">
                                <span><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></span>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Existing Assignments Display -->
                    <?php if (!empty($existing_assignments)): ?>
                    <div class="assignments-box">
                        <h4><i class="fas fa-exclamation-triangle"></i> Currently Assigned Subject-Class Combinations</h4>
                        <p style="margin-bottom: 15px; color: var(--text-light); font-size: 0.9rem;">
                            <i class="fas fa-info-circle"></i> The following subject-class combinations are already assigned to teachers. You cannot assign the same combination again.
                        </p>
                        <div class="assignments-grid">
                            <?php foreach ($existing_assignments as $teacher): 
                                $teacher_subjects = !empty($teacher['subject_specialization']) ? explode(',', $teacher['subject_specialization']) : [];
                                $teacher_classes = !empty($teacher['assigned_classes']) ? explode(',', $teacher['assigned_classes']) : [];
                                
                                foreach ($teacher_classes as $class):
                                    foreach ($teacher_subjects as $subject):
                            ?>
                                <div class="assignment-item">
                                    <div class="assignment-class"><?php echo htmlspecialchars($class); ?></div>
                                    <div class="assignment-subject"><?php echo htmlspecialchars($subject); ?></div>
                                    <div class="assignment-teacher">Teacher: <?php echo htmlspecialchars($teacher['username']); ?></div>
                                </div>
                            <?php endforeach; endforeach; endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <form method="POST" action="" id="teacherForm">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="first_name">First Name</label>
                                <input type="text" id="first_name" name="first_name" class="form-control" required placeholder="Enter first name">
                            </div>
                            <div class="form-group">
                                <label for="last_name">Last Name</label>
                                <input type="text" id="last_name" name="last_name" class="form-control" required placeholder="Enter last name">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" id="username" name="username" class="form-control" required placeholder="Choose a username">
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" id="password" name="password" class="form-control" required placeholder="Set a password">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" name="email" class="form-control" required placeholder="teacher@school.com">
                        </div>

                        <!-- Subject Selection -->
                        <div class="subject-selection-container">
                            <h3><i class="fas fa-book-open"></i> Select Subjects to Teach</h3>
                            <p style="margin-bottom: 20px; color: var(--text-light);">
                                <i class="fas fa-info-circle"></i> Click to select subjects. Teacher can teach 1 or more subjects.
                            </p>
                            
                            <?php
                            // Define subject categories
                            $core_subjects = ['Somali', 'English', 'Carabi', 'Xisaab', 'Tarbiyo'];
                            $middle_school_subjects = ['Saynis', 'Soshiyal'];
                            $high_school_subjects = ['Physics', 'Biology', 'Chemistry', 'Technology', 'Business', 'Tariikh', 'Jugrafi'];
                            
                            // Combine all subjects
                            $all_subjects = array_merge($core_subjects, $middle_school_subjects, $high_school_subjects);
                            sort($all_subjects);
                            ?>
                            
                            <div class="subject-selection-grid">
                                <?php foreach ($all_subjects as $subject): 
                                    // Determine subject category and level
                                    if (in_array($subject, $core_subjects)) {
                                        $level_class = 'level-core';
                                        $level_text = 'All Levels';
                                        $subject_type = 'core';
                                    } elseif (in_array($subject, $middle_school_subjects)) {
                                        $level_class = 'level-middle-high';
                                        $level_text = 'Middle+High';
                                        $subject_type = 'middle';
                                    } else {
                                        $level_class = 'level-high';
                                        $level_text = 'High School';
                                        $subject_type = 'high';
                                    }
                                ?>
                                    <div class="subject-checkbox" data-subject="<?= htmlspecialchars($subject) ?>" data-type="<?= $subject_type ?>">
                                        <input type="checkbox" name="subject_specialization[]" value="<?= htmlspecialchars($subject) ?>" id="subj_<?= md5($subject) ?>">
                                        <div class="checkmark">
                                            <i class="fas fa-check"></i>
                                        </div>
                                        <div class="subject-icon">
                                            <i class="fas fa-book"></i>
                                        </div>
                                        <label for="subj_<?= md5($subject) ?>"><?= htmlspecialchars($subject) ?></label>
                                        <span class="subject-level <?= $level_class ?>"><?= $level_text ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            
                            <div class="counter-display">
                                <div class="counter-text">Selected Subjects:</div>
                                <div class="counter-number" id="selectedCounter">0</div>
                            </div>
                        </div>

                        <!-- Compatibility Rules -->
                        <div class="rules-box">
                            <h4><i class="fas fa-check-circle"></i> Subject Compatibility Rules</h4>
                            <ul class="rule-list">
                                <li><strong>Core Subjects</strong> (Somali, English, Carabi, Xisaab, Tarbiyo) can be taught at <strong>ALL levels</strong> (Grade 1-12)</li>
                                <li><strong>Middle School Subjects</strong> (Saynis, Soshiyal) can be taught in <strong>Middle AND High School</strong> (Grade 5-12)</li>
                                <li><strong>High School Subjects</strong> (Physics, Biology, Chemistry, etc.) can be taught in <strong>High School only</strong> (Grade 9-12)</li>
                                <li class="warning">Teachers with High School subjects <strong>cannot</strong> teach Primary School (Grade 1-4)</li>
                                <li class="warning"><strong>ONE TEACHER PER SUBJECT-CLASS:</strong> Cannot assign 2 teachers to the same subject in the same class</li>
                                <li><strong>Example:</strong> A teacher with Biology can teach Grade 5 (Saynis) AND Grade 11 (Biology)</li>
                            </ul>
                        </div>

                        <!-- Class Assignment -->
                        <div class="class-assignment">
                            <h3><i class="fas fa-school"></i> Class Assignment (Optional)</h3>
                            <p style="margin-bottom: 20px; color: var(--text-light);">
                                <i class="fas fa-info-circle"></i> Select classes this teacher will be assigned to (optional).
                                <br><small style="color: var(--warning);"><i class="fas fa-exclamation-triangle"></i> Cannot assign subject-class combination that already exists</small>
                            </p>
                            <?php foreach($school_levels as $level_key => $level): ?>
                            <div class="school-level" data-level="<?= $level_key ?>">
                                <h4><?php echo $level['name']; ?></h4>
                                <div class="grades-grid">
                                    <?php foreach($level['grades'] as $grade): 
                                        $grade_id = $level_key . '_' . $grade;
                                    ?>
                                        <div class="grade-checkbox" data-level="<?= $level_key ?>" data-grade="<?= $grade ?>">
                                            <input type="checkbox" name="assigned_classes[]" value="<?php echo $grade; ?>" id="<?php echo $grade_id; ?>">
                                            <label for="<?php echo $grade_id; ?>"><?php echo $grade; ?></label>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            
                            <div class="duplicate-warning" id="duplicateWarning">
                                <div style="display: flex; align-items: center;">
                                    <i class="fas fa-exclamation-triangle warning-icon"></i>
                                    <span class="warning-text" id="duplicateText"></span>
                                </div>
                            </div>
                        </div>

                        <div class="info-box">
                            <h4><i class="fas fa-key"></i> Teacher Login Information</h4>
                            <p>After creation, teacher can login with:<br>
                            • <strong>Username:</strong> Set above<br>
                            • <strong>Password:</strong> Set above<br>
                            • <strong>Note:</strong> System automatically checks subject-class compatibility and prevents duplicate assignments.</p>
                        </div>

                        <div style="display: flex; gap: 15px; margin-top: 30px;">
                            <button type="submit" class="btn btn-primary" id="submitBtn">
                                <i class="fas fa-user-plus"></i> Create Teacher Account
                            </button>
                            <a href="../admin/admin_dashboard.php" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <div class="footer">
                <div class="footer-links">
                    <a href="../admin/admin_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
                    <a href="#"><i class="fas fa-question-circle"></i> Help</a>
                    <a href="../index.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
                <div class="footer-copyright">
                    <i class="fas fa-heart"></i>
                    2023 EduFlow Teacher Registration System. All rights reserved.
                </div>
            </div>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const menuToggle = document.getElementById('menuToggle');
            const sidebar = document.getElementById('sidebar');
            
            if (window.innerWidth <= 480) {
                menuToggle.style.display = 'block';
                menuToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
                document.addEventListener('click', (e) => {
                    if (!sidebar.contains(e.target) && !menuToggle.contains(e.target) && window.innerWidth <= 480) {
                        sidebar.classList.remove('active');
                    }
                });
            }
            
            window.addEventListener('resize', function() {
                if (window.innerWidth > 480) {
                    menuToggle.style.display = 'none';
                    sidebar.classList.remove('active');
                } else {
                    menuToggle.style.display = 'block';
                }
            });

            // Subject selection functionality
            const subjectCheckboxes = document.querySelectorAll('.subject-checkbox');
            const gradeCheckboxes = document.querySelectorAll('.grade-checkbox');
            const counter = document.getElementById('selectedCounter');
            const submitBtn = document.getElementById('submitBtn');
            const teacherForm = document.getElementById('teacherForm');
            const duplicateWarning = document.getElementById('duplicateWarning');
            const duplicateText = document.getElementById('duplicateText');
            
            // Existing assignments from PHP
            const existingAssignments = <?php echo json_encode($assignment_map); ?>;
            
            // Initialize counter
            updateCounter();
            
            // Add click event to each subject checkbox
            subjectCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('click', function(e) {
                    const input = this.querySelector('input[type="checkbox"]');
                    input.checked = !input.checked;
                    
                    if (input.checked) {
                        this.classList.add('selected');
                    } else {
                        this.classList.remove('selected');
                    }
                    
                    updateCounter();
                    updateSubmitButton();
                    checkDuplicateAssignments();
                });
            });
            
            // Add click event to each grade checkbox
            gradeCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('click', function(e) {
                    const input = this.querySelector('input[type="checkbox"]');
                    input.checked = !input.checked;
                    
                    // Update UI
                    if (input.checked) {
                        this.style.background = 'rgba(0, 204, 255, 0.1)';
                        this.style.borderColor = 'var(--primary-blue)';
                    } else {
                        this.style.background = '';
                        this.style.borderColor = '#eaeaea';
                    }
                    
                    checkDuplicateAssignments();
                });
            });
            
            // Check for duplicate assignments
            function checkDuplicateAssignments() {
                const selectedSubjects = Array.from(document.querySelectorAll('.subject-checkbox input[type="checkbox"]:checked'))
                    .map(input => input.value);
                const selectedClasses = Array.from(document.querySelectorAll('.grade-checkbox input[type="checkbox"]:checked'))
                    .map(input => input.value);
                
                // Clear previous warnings
                duplicateWarning.classList.remove('show');
                duplicateText.textContent = '';
                
                // Mark grade checkboxes with existing assignments
                gradeCheckboxes.forEach(checkbox => {
                    checkbox.classList.remove('assigned');
                });
                
                // Check for duplicates
                let hasDuplicates = false;
                let duplicateMessages = [];
                
                selectedClasses.forEach(classItem => {
                    selectedSubjects.forEach(subject => {
                        // Check if this combination exists in existing assignments
                        const existingAssignment = existingAssignments.find(assignment => 
                            assignment.class === classItem && assignment.subject === subject
                        );
                        
                        if (existingAssignment) {
                            hasDuplicates = true;
                            duplicateMessages.push(`<strong>${subject}</strong> in <strong>${classItem}</strong> is already assigned to <strong>${existingAssignment.teacher}</strong>`);
                            
                            // Mark the grade checkbox
                            const gradeCheckbox = document.querySelector(`.grade-checkbox[data-grade="${classItem}"]`);
                            if (gradeCheckbox) {
                                gradeCheckbox.classList.add('assigned');
                            }
                        }
                    });
                });
                
                // Show warning if duplicates found
                if (hasDuplicates) {
                    duplicateText.innerHTML = 'Duplicate assignments detected:<br>' + duplicateMessages.join('<br>');
                    duplicateWarning.classList.add('show');
                }
                
                return hasDuplicates;
            }
            
            // Update counter display
            function updateCounter() {
                const checkedBoxes = document.querySelectorAll('.subject-checkbox input[type="checkbox"]:checked');
                counter.textContent = checkedBoxes.length;
                
                // Update counter color based on count
                if (checkedBoxes.length === 0) {
                    counter.style.background = '#ff4757';
                } else if (checkedBoxes.length === 1) {
                    counter.style.background = '#ff9d00';
                } else {
                    counter.style.background = '#00cc7a';
                }
            }
            
            // Update submit button state
            function updateSubmitButton() {
                const checkedBoxes = document.querySelectorAll('.subject-checkbox input[type="checkbox"]:checked');
                
                if (checkedBoxes.length === 0) {
                    submitBtn.innerHTML = '<i class="fas fa-exclamation-circle"></i> Select at least 1 subject';
                    submitBtn.style.opacity = '0.7';
                    submitBtn.style.cursor = 'not-allowed';
                    submitBtn.setAttribute('disabled', 'disabled');
                } else {
                    submitBtn.innerHTML = `<i class="fas fa-user-plus"></i> Create Teacher Account (${checkedBoxes.length} subjects)`;
                    submitBtn.style.opacity = '1';
                    submitBtn.style.cursor = 'pointer';
                    submitBtn.removeAttribute('disabled');
                }
            }
            
            // Form validation
            teacherForm.addEventListener('submit', function(e) {
                const checkedBoxes = document.querySelectorAll('.subject-checkbox input[type="checkbox"]:checked');
                
                if (checkedBoxes.length === 0) {
                    e.preventDefault();
                    alert('Please select at least one subject for the teacher.');
                    return false;
                }
                
                // Check for duplicate assignments
                const hasDuplicates = checkDuplicateAssignments();
                if (hasDuplicates) {
                    e.preventDefault();
                    alert('Cannot create teacher with duplicate subject-class assignments. Please review the warnings above.');
                    return false;
                }
                
                // Show loading state
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating Account...';
                submitBtn.setAttribute('disabled', 'disabled');
            });
            
            // Auto-hide alerts
            document.querySelectorAll('.alert').forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    alert.style.transform = 'translateX(30px)';
                    setTimeout(() => alert.style.display = 'none', 500);
                }, 8000);
            });
            
            // Initialize button state
            updateSubmitButton();
        });
    </script>
</body>
</html>