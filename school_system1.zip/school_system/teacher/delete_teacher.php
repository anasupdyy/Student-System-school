<?php
session_start();
require_once '../db.php';

// 1. Check admin auth
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../index.php');
    exit();
}

// 2. Validate teacher ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error'] = "Invalid teacher ID.";
    header('Location: manage_teachers.php');
    exit();
}

$teacher_id = (int)$_GET['id'];

// 3. Ka soo qaado user_id (si aan u delete gareyno users table)
$stmt = $pdo->prepare("SELECT user_id FROM teachers WHERE id = ?");
$stmt->execute([$teacher_id]);
$user_id = $stmt->fetchColumn();

if (!$user_id) {
    $_SESSION['error'] = "Teacher not found.";
    header('Location: manage_teachers.php');
    exit();
}

// 4. Dallo (CASCADE waa in la dhigay database-ka, laakiin waxaan dalinaynaa)
try {
    // Dallo teacher record
    $pdo->prepare("DELETE FROM teachers WHERE id = ?")->execute([$teacher_id]);
    
    // Dallo user account
    $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$user_id]);

    $_SESSION['success'] = "✅ Teacher deleted successfully!";
} catch (Exception $e) {
    $_SESSION['error'] = "❌ Error: Unable to delete teacher. " . $e->getMessage();
}

// 5. Return
header('Location: manage_teachers.php');
exit();
?>