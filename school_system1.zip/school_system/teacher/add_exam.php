<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'teacher') {
    header('Location: ../index.php');
    exit();
}

// Fetch teacher
$stmt = $pdo->prepare("SELECT t.* FROM teachers t WHERE t.user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$teacher = $stmt->fetch();

if (!$teacher) {
    die("Teacher not found.");
}

$teacher_name = $teacher['first_name'] . ' ' . $teacher['last_name'];

// ✅ Get teacher's subjects
$all_subjects = $teacher['subject_specialization'] ? array_map('trim', explode(',', $teacher['subject_specialization'])) : ['N/A'];
// ✅ Use first subject as default if not selected
$default_subject = $all_subjects[0] ?? 'N/A';

// Get assigned classes from teacher_classes table
$classes_stmt = $pdo->prepare("SELECT DISTINCT class_name FROM teacher_classes WHERE teacher_id = ?");
$classes_stmt->execute([$teacher['id']]);
$assigned_classes = $classes_stmt->fetchAll(PDO::FETCH_COLUMN);

if (empty($assigned_classes)) {
    $assigned_classes = $teacher['assigned_classes'] ? array_map('trim', explode(',', $teacher['assigned_classes'])) : [];
}

// Get statistics
$today = date('Y-m-d');
$midterm_count = $pdo->prepare("SELECT COUNT(*) FROM exams e 
    JOIN exam_results er ON e.id = er.exam_id 
    WHERE e.exam_name = 'Mid-Term Exam' 
    AND e.created_by = ? 
    AND DATE(e.exam_date) = ?");
$midterm_count->execute([$teacher['id'], $today]);
$midterm_today = $midterm_count->fetchColumn();

$final_count = $pdo->prepare("SELECT COUNT(*) FROM exams e 
    JOIN exam_results er ON e.id = er.exam_id 
    WHERE e.exam_name = 'Final Exam' 
    AND e.created_by = ? 
    AND DATE(e.exam_date) = ?");
$final_count->execute([$teacher['id'], $today]);
$final_today = $final_count->fetchColumn();

$message = '';
$success_data = null;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $exam_type = $_POST['exam_type'] ?? '';
    $stu_id = trim($_POST['stu_id'] ?? '');
    $target_class = trim($_POST['target_class'] ?? '');
    $selected_subject = trim($_POST['selected_subject'] ?? $default_subject);
    $exam_date = $_POST['exam_date'] ?? date('Y-m-d');
    $marks = trim($_POST['marks_obtained'] ?? '');

    // Validate exam type
    if ($exam_type !== 'midterm' && $exam_type !== 'final') {
        $message = "❌ Invalid exam type.";
    } elseif (!$stu_id) {
        $message = "❌ Please enter a valid STU-ID.";
    } elseif (!$target_class || !in_array($target_class, $assigned_classes)) {
        $message = "❌ You can only enter marks for your assigned classes.";
    } else {
        $max_marks = ($exam_type === 'midterm') ? 40 : 60;
        if (!is_numeric($marks) || $marks < 0 || (float)$marks > $max_marks) {
            $message = "❌ Marks must be between 0 and $max_marks.";
        } else {
            try {
                // Start transaction
                $pdo->beginTransaction();
                
                // Find student by username (STU-ID)
                $user_stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND role = 'student'");
                $user_stmt->execute([$stu_id]);
                $user = $user_stmt->fetch();

                if (!$user) {
                    throw new Exception("Student with STU-ID '$stu_id' not found.");
                }
                
                $user_id = $user['id'];

                $student_stmt = $pdo->prepare("SELECT id, first_name, last_name, grade_level FROM students WHERE user_id = ?");
                $student_stmt->execute([$user_id]);
                $student = $student_stmt->fetch();

                if (!$student) {
                    throw new Exception("Student record not found for STU-ID '$stu_id'.");
                }
                
                // Check if student is in the correct class
                if ($student['grade_level'] !== $target_class) {
                    $actual_class = htmlspecialchars($student['grade_level']);
                    throw new Exception("STU-ID '$stu_id' belongs to <strong>$actual_class</strong>, not <strong>$target_class</strong>. Marks not saved.");
                }
                
                $student_id = $student['id'];
                $student_full_name = htmlspecialchars($student['first_name'] . ' ' . $student['last_name']);

                // ✅ Use SELECTED SUBJECT
                $exam_name = ($exam_type === 'midterm') ? 'Mid-Term Exam' : 'Final Exam';
                
                // Check if exam already exists for this teacher, subject, class, and date
                $exam_check = $pdo->prepare("
                    SELECT id FROM exams 
                    WHERE exam_name = ? 
                    AND subject = ? 
                    AND exam_date = ? 
                    AND target_class = ? 
                    AND created_by = ?
                ");
                $exam_check->execute([$exam_name, $selected_subject, $exam_date, $target_class, $teacher['id']]);
                $exam = $exam_check->fetch();

                if ($exam) {
                    $exam_id = $exam['id'];
                } else {
                    // Create new exam record
                    $insert_exam = $pdo->prepare("
                        INSERT INTO exams (exam_name, exam_type, subject, exam_date, total_marks, duration, target_class, created_by, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
                    ");
                    $insert_exam->execute([
                        $exam_name,
                        ($exam_type === 'midterm') ? 'Mid-Term' : 'Final',
                        $selected_subject,
                        $exam_date,
                        $max_marks,
                        60, // duration
                        $target_class,
                        $teacher['id']
                    ]);
                    $exam_id = $pdo->lastInsertId();
                }

                // Check if marks already exist for this student in this exam
                $exists_stmt = $pdo->prepare("SELECT id, marks_obtained FROM exam_results WHERE exam_id = ? AND student_id = ?");
                $exists_stmt->execute([$exam_id, $student_id]);
                $existing_record = $exists_stmt->fetch();

                if ($existing_record) {
                    // Update existing marks
                    $update_stmt = $pdo->prepare("UPDATE exam_results SET marks_obtained = ? WHERE id = ?");
                    $update_stmt->execute([$marks, $existing_record['id']]);
                    
                    $action = 'updated';
                    $old_marks = $existing_record['marks_obtained'];
                } else {
                    // Insert new marks
                    $insert_stmt = $pdo->prepare("
                        INSERT INTO exam_results (exam_id, student_id, marks_obtained) 
                        VALUES (?, ?, ?)
                    ");
                    $insert_stmt->execute([$exam_id, $student_id, $marks]);
                    
                    $action = 'added';
                }

                // Commit transaction
                $pdo->commit();

                // Store success data for display
                $success_data = [
                    'student_name' => $student_full_name,
                    'subject' => $selected_subject,
                    'marks' => $marks,
                    'total' => $max_marks,
                    'stu_id' => $stu_id,
                    'class' => $target_class,
                    'exam_type' => $exam_name,
                    'date' => $exam_date,
                    'action' => $action
                ];
                
                $message = "✅ Marks saved successfully for $student_full_name (STU-ID: $stu_id)!";
                
                // Update statistics
                if ($exam_type === 'midterm') {
                    $midterm_today++;
                } else {
                    $final_today++;
                }
                
            } catch (Exception $e) {
                // Rollback transaction on error
                $pdo->rollBack();
                $message = "❌ Error: " . $e->getMessage();
            }
        }
    }
}

// Get recent exam entries for this teacher
$recent_entries_stmt = $pdo->prepare("
    SELECT 
        er.id,
        er.marks_obtained,
        e.exam_name,
        e.subject,
        e.total_marks,
        e.target_class,
        s.first_name,
        s.last_name,
        u.username as stu_id
    FROM exam_results er
    JOIN exams e ON er.exam_id = e.id
    JOIN students s ON er.student_id = s.id
    JOIN users u ON s.user_id = u.id
    WHERE e.created_by = ?
    ORDER BY e.created_at DESC
    LIMIT 5
");
$recent_entries_stmt->execute([$teacher['id']]);
$recent_entries = $recent_entries_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Exam Marks | Teacher Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            --primary-dark: #0a192f;
            --primary-blue: #00ccff;
            --secondary-blue: #3366ff;
            --accent-purple: #9d4edd;
            --success: #00cc7a;
            --warning: #ff9d00;
            --danger: #ff4757;
            --white: #ffffff;
            --light-gray: #f8fafc;
            --text-dark: #1e293b;
            --text-light: #64748b;
            --gradient-primary: linear-gradient(135deg, #00ccff 0%, #3366ff 100%);
            --gradient-success: linear-gradient(135deg, #00cc7a 0%, #00b894 100%);
            --gradient-purple: linear-gradient(135deg, #9d4edd 0%, #5a00cc 100%);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--light-gray);
            color: var(--text-dark);
            min-height: 100vh;
            display: flex;
            overflow-x: hidden;
        }

        /* SIDEBAR */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary-dark) 0%, #0c2040 100%);
            color: var(--white);
            display: flex;
            flex-direction: column;
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
            z-index: 100;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
            transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
        }

        .sidebar.collapsed {
            transform: translateX(-280px);
        }

        .sidebar-header {
            text-align: center;
            padding: 0 25px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 30px;
        }

        .sidebar-avatar {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--primary-blue), #0099cc);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            font-weight: 600;
            margin: 0 auto 15px;
            color: var(--white);
            border: 3px solid rgba(255, 255, 255, 0.2);
            transition: transform 0.3s ease;
        }

        .sidebar-avatar:hover {
            transform: scale(1.05);
        }

        .sidebar-header h2 {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
            color: var(--white);
        }

        .sidebar-header p {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.8);
            background: rgba(0, 204, 255, 0.2);
            padding: 4px 12px;
            border-radius: 20px;
            display: inline-block;
        }

        /* Navigation */
        .nav-links {
            list-style: none;
            flex-grow: 1;
            padding: 0 20px;
        }

        .nav-links li {
            margin-bottom: 8px;
        }

        .nav-links a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            padding: 14px 18px;
            border-radius: 10px;
            transition: all 0.3s ease;
            font-weight: 500;
            position: relative;
            overflow: hidden;
        }

        .nav-links a:before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 4px;
            background: var(--primary-blue);
            transform: scaleY(0);
            transition: transform 0.3s ease;
        }

        .nav-links a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            transform: translateX(5px);
        }

        .nav-links a:hover:before {
            transform: scaleY(1);
        }

        .nav-links a.active {
            background: rgba(0, 204, 255, 0.25);
            color: var(--white);
        }

        .nav-links a.active:before {
            transform: scaleY(1);
        }

        .nav-links i {
            width: 24px;
            margin-right: 12px;
            font-size: 18px;
            text-align: center;
        }

        /* Logout Button */
        .logout-btn {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            border: none;
            padding: 15px;
            margin: 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateY(-2px);
            border-color: rgba(255, 255, 255, 0.2);
        }

        .logout-btn i {
            margin-right: 10px;
        }

        /* MAIN CONTENT */
        .main-content {
            flex: 1;
            margin-left: 280px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            transition: margin-left 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
        }

        .main-content.expanded {
            margin-left: 0;
        }

        /* Header */
        .page-header {
            background: var(--white);
            padding: 25px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.05);
            border-bottom: 1px solid #eaeaea;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .menu-toggle {
            background: none;
            border: none;
            color: var(--primary-blue);
            font-size: 24px;
            cursor: pointer;
            padding: 10px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .menu-toggle:hover {
            background: rgba(0, 204, 255, 0.1);
            transform: rotate(90deg);
        }

        .page-header h1 {
            color: var(--primary-dark);
            font-size: 28px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .page-header h1 i {
            color: var(--primary-blue);
            font-size: 26px;
        }

        .date-display {
            background: var(--light-gray);
            padding: 12px 20px;
            border-radius: 10px;
            color: var(--text-light);
            font-weight: 500;
            border: 1px solid #eaeaea;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* Content Area */
        .content {
            flex: 1;
            padding: 30px;
            background: var(--light-gray);
        }

        /* Main Card */
        .main-card {
            background: var(--white);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.05);
            border: 1px solid #eaeaea;
            animation: fadeIn 0.6s ease-out;
            max-width: 1200px;
            margin: 0 auto;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Teacher Info */
        .teacher-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
            padding: 20px;
            background: linear-gradient(135deg, rgba(0, 204, 255, 0.1), rgba(10, 25, 47, 0.05));
            border-radius: 12px;
            border-left: 4px solid var(--primary-blue);
        }

        .info-item {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .info-item i {
            color: var(--primary-blue);
            font-size: 20px;
        }

        .info-content h3 {
            color: var(--primary-dark);
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 4px;
        }

        .info-content p {
            color: var(--text-light);
            font-size: 14px;
        }

        /* Quick Stats */
        .quick-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--white);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            gap: 15px;
            border: 1px solid #eaeaea;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }

        .stat-content h4 {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary-dark);
            margin-bottom: 5px;
        }

        .stat-content p {
            font-size: 14px;
            color: var(--text-light);
        }

        /* Message Alert */
        .message {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            border-left: 4px solid transparent;
            animation: slideIn 0.5s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .message.success {
            background: rgba(0, 204, 122, 0.1);
            border-left-color: var(--success);
            color: var(--success);
        }

        .message.error {
            background: rgba(255, 71, 87, 0.1);
            border-left-color: var(--danger);
            color: var(--danger);
        }

        .message i {
            font-size: 20px;
        }

        /* Recent Entries */
        .recent-entries {
            margin-bottom: 30px;
        }

        .recent-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .recent-header h3 {
            color: var(--primary-dark);
            font-size: 20px;
            font-weight: 600;
        }

        .recent-list {
            background: var(--white);
            border-radius: 12px;
            border: 1px solid #eaeaea;
            overflow: hidden;
        }

        .recent-item {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr 1fr;
            gap: 15px;
            padding: 15px 20px;
            border-bottom: 1px solid #eaeaea;
            align-items: center;
        }

        .recent-item:last-child {
            border-bottom: none;
        }

        .recent-item:hover {
            background: rgba(0, 204, 255, 0.05);
        }

        .recent-student {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .student-avatar {
            width: 35px;
            height: 35px;
            background: linear-gradient(135deg, var(--primary-blue), #0099cc);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 14px;
        }

        .marks-badge {
            padding: 4px 10px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 12px;
        }

        .marks-badge.midterm {
            background: rgba(0, 204, 255, 0.1);
            color: var(--primary-blue);
        }

        .marks-badge.final {
            background: rgba(0, 204, 122, 0.1);
            color: var(--success);
        }

        /* Success Card */
        .success-card {
            display: none;
            background: linear-gradient(135deg, rgba(0, 204, 122, 0.1), rgba(0, 184, 148, 0.05));
            border: 2px solid var(--success);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            animation: slideInRight 0.6s ease-out;
        }

        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .success-card.show {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .success-icon {
            width: 60px;
            height: 60px;
            background: var(--success);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            color: white;
            flex-shrink: 0;
            animation: pulseSuccess 2s ease-in-out infinite;
        }

        @keyframes pulseSuccess {
            0%, 100% {
                box-shadow: 0 0 0 0 rgba(0, 204, 122, 0.4);
            }
            50% {
                box-shadow: 0 0 0 15px rgba(0, 204, 122, 0);
            }
        }

        .success-content {
            flex: 1;
        }

        .success-content h4 {
            color: var(--success);
            font-size: 20px;
            margin-bottom: 15px;
            font-weight: 600;
        }

        .success-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .detail-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 8px;
        }

        .detail-item i {
            color: var(--success);
            font-size: 16px;
        }

        .btn-continue {
            background: var(--gradient-success);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .btn-continue:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(0, 204, 122, 0.3);
        }

        /* Form Sections */
        .form-section {
            display: none;
            animation: fadeIn 0.6s ease-out;
        }

        .form-section.active {
            display: block;
        }

        .form-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--light-gray);
        }

        .form-header h3 {
            color: var(--primary-dark);
            font-size: 22px;
            font-weight: 600;
        }

        .form-header .badge {
            background: var(--primary-blue);
            color: white;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
        }

        .form-header .badge.final {
            background: var(--success);
        }

        /* Choice Buttons */
        .choice-buttons {
            display: flex;
            gap: 15px;
            margin: 20px 0 30px;
        }

        .choice-btn {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 25px 20px;
            background: var(--white);
            border: 2px solid #eaeaea;
            border-radius: 12px;
            color: var(--text-dark);
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.3s ease;
            cursor: pointer;
            border-left: 4px solid transparent;
        }

        .choice-btn:hover {
            border-color: var(--primary-blue);
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 204, 255, 0.15);
            animation: float 2s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% {
                transform: translateY(-3px);
            }
            50% {
                transform: translateY(-6px);
            }
        }

        .choice-btn.active {
            background: linear-gradient(135deg, rgba(0, 204, 255, 0.1), rgba(51, 102, 255, 0.05));
            border-color: var(--primary-blue);
            color: var(--primary-blue);
        }

        .choice-btn.midterm.active {
            border-left-color: var(--primary-blue);
        }

        .choice-btn.final.active {
            border-left-color: var(--success);
        }

        .choice-btn i {
            font-size: 32px;
            margin-bottom: 10px;
        }

        .choice-btn.midterm i {
            color: var(--primary-blue);
        }

        .choice-btn.final i {
            color: var(--success);
        }

        /* Form Grid */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            transition: all 0.3s ease;
        }

        .form-group.focused {
            transform: translateY(-2px);
        }

        .form-label {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--primary-dark);
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .form-label i {
            color: var(--primary-blue);
        }

        .form-control {
            padding: 12px 16px;
            border: 2px solid #eaeaea;
            border-radius: 8px;
            font-size: 15px;
            color: var(--text-dark);
            background: var(--white);
            transition: all 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(0, 204, 255, 0.15);
        }

        .form-control.error {
            border-color: var(--danger);
            animation: shake 0.5s ease-in-out;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
            20%, 40%, 60%, 80% { transform: translateX(5px); }
        }

        /* Error Toast */
        .error-toast {
            position: fixed;
            top: 100px;
            right: 30px;
            background: var(--danger);
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 5px 20px rgba(255, 71, 87, 0.3);
            z-index: 1000;
            animation: slideInRight 0.5s ease-out;
        }

        .error-toast button {
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            margin-left: 10px;
        }

        /* Submit Button */
        .submit-btn {
            padding: 14px 28px;
            background: var(--gradient-primary);
            color: var(--white);
            border: none;
            border-radius: 10px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            margin-top: 20px;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 204, 255, 0.3);
        }

        .submit-btn:active {
            transform: translateY(0);
        }

        .submit-btn.final {
            background: var(--gradient-success);
        }

        .submit-btn.final:hover {
            box-shadow: 0 8px 25px rgba(0, 204, 122, 0.3);
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 20px;
            color: var(--text-light);
            font-size: 14px;
            border-top: 1px solid var(--light-gray);
            margin-top: 30px;
            background: var(--white);
            border-radius: 10px;
        }

        .footer i {
            color: var(--primary-blue);
            margin-right: 8px;
        }

        /* Tooltip */
        .tooltip {
            position: relative;
            display: inline-block;
            margin-left: 8px;
        }

        .tooltip i {
            color: var(--primary-blue);
            cursor: help;
        }

        .tooltip-text {
            visibility: hidden;
            width: 200px;
            background: var(--primary-dark);
            color: white;
            text-align: center;
            padding: 10px;
            border-radius: 6px;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            left: 50%;
            transform: translateX(-50%);
            opacity: 0;
            transition: opacity 0.3s;
            font-size: 12px;
            font-weight: normal;
        }

        .tooltip:hover .tooltip-text {
            visibility: visible;
            opacity: 1;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 80px;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .sidebar-header h2,
            .sidebar-header p,
            .nav-links span,
            .logout-btn span {
                display: none;
            }
            
            .nav-links a {
                justify-content: center;
                padding: 16px;
            }
            
            .nav-links i {
                margin-right: 0;
                font-size: 20px;
            }
            
            .sidebar-avatar {
                width: 50px;
                height: 50px;
                font-size: 22px;
            }
            
            .recent-item {
                grid-template-columns: 1fr;
                gap: 10px;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: fixed;
                top: 0;
                flex-direction: row;
                padding: 15px;
                z-index: 1000;
            }
            
            .main-content {
                margin-left: 0;
                margin-top: 70px;
            }
            
            .sidebar-header {
                display: flex;
                align-items: center;
                padding: 0;
                border-bottom: none;
                margin-bottom: 0;
                margin-right: 15px;
            }
            
            .sidebar-avatar {
                width: 40px;
                height: 40px;
                margin: 0 10px 0 0;
            }
            
            .nav-links {
                display: flex;
                padding: 0;
                flex-grow: 0;
            }
            
            .nav-links li {
                margin-bottom: 0;
                margin-right: 5px;
            }
            
            .logout-btn {
                margin: 0 0 0 auto;
                padding: 10px;
            }
            
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .choice-buttons {
                flex-direction: column;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .quick-stats {
                grid-template-columns: 1fr;
                gap: 10px;
            }
            
            .teacher-info {
                grid-template-columns: 1fr;
            }
            
            .success-card.show {
                flex-direction: column;
                text-align: center;
            }
            
            .success-details {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 480px) {
            .main-content {
                padding: 15px;
            }
            
            .main-card {
                padding: 20px;
                margin: 0 -15px;
                border-radius: 0;
            }
            
            .form-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .form-header .badge {
                align-self: flex-start;
            }
            
            .submit-btn {
                padding: 15px;
                font-size: 15px;
            }
            
            .error-toast {
                left: 15px;
                right: 15px;
                top: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-avatar">
                <?= $teacher ? strtoupper(substr($teacher['first_name'][0] ?? 'T', 0, 1)) : 'T' ?>
            </div>
            <h2><?= $teacher ? htmlspecialchars($teacher['first_name']) : 'Teacher' ?></h2>
            <p><?= $teacher ? htmlspecialchars($teacher['subject_specialization'] ?? 'Teacher') : 'Teacher' ?></p>
        </div>
        <ul class="nav-links">
            <li><a href="teacher_dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
            <li><a href="add_attendance.php"><i class="fas fa-calendar-check"></i> <span>Attendance</span></a></li>
            <li><a href="add_exam.php" class="active"><i class="fas fa-file-alt"></i> <span>Exams</span></a></li>
           
        </ul>
        <button class="logout-btn" onclick="window.location='../index.php'">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </button>
    </div>

    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <!-- Header -->
        <div class="page-header">
            <div class="header-left">
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <h1><i class="fas fa-file-alt"></i> Enter Exam Marks</h1>
            </div>
            <div class="date-display">
                <i class="fas fa-calendar"></i> <?= date('l, F j, Y') ?>
            </div>
        </div>

        <!-- Content -->
        <div class="content">
            <!-- Main Card -->
            <div class="main-card fade-in-up">
                <!-- Teacher Info -->
                <?php if ($teacher): ?>
                <div class="teacher-info">
                    <div class="info-item">
                        <i class="fas fa-user"></i>
                        <div class="info-content">
                            <h3>Teacher</h3>
                            <p><?= htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name']) ?></p>
                        </div>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-book"></i>
                        <div class="info-content">
                            <h3>Subject(s)</h3>
                            <p><?= htmlspecialchars(implode(', ', $all_subjects)) ?></p>
                        </div>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-graduation-cap"></i>
                        <div class="info-content">
                            <h3>Assigned Classes</h3>
                            <p><?= !empty($assigned_classes) ? htmlspecialchars(implode(', ', $assigned_classes)) : 'Not assigned' ?></p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Quick Stats -->
                <div class="quick-stats">
                    <div class="stat-card">
                        <div class="stat-icon" style="background: rgba(0, 204, 255, 0.1);">
                            <i class="fas fa-file-alt" style="color: var(--primary-blue);"></i>
                        </div>
                        <div class="stat-content">
                            <h4 id="midtermCount"><?= $midterm_today ?></h4>
                            <p>Mid-Term Entries Today</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon" style="background: rgba(0, 204, 122, 0.1);">
                            <i class="fas fa-graduation-cap" style="color: var(--success);"></i>
                        </div>
                        <div class="stat-content">
                            <h4 id="finalCount"><?= $final_today ?></h4>
                            <p>Final Exam Entries Today</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon" style="background: rgba(157, 78, 221, 0.1);">
                            <i class="fas fa-calendar" style="color: var(--accent-purple);"></i>
                        </div>
                        <div class="stat-content">
                            <h4 id="todayCount"><?= $midterm_today + $final_today ?></h4>
                            <p>Total Entries Today</p>
                        </div>
                    </div>
                </div>

                <?php if ($message): ?>
                    <div class="message <?= strpos($message, '✅') !== false ? 'success' : 'error' ?>">
                        <i class="fas fa-<?= strpos($message, '✅') !== false ? 'check-circle' : 'exclamation-circle' ?>"></i>
                        <?= $message ?>
                    </div>
                <?php endif; ?>

                <!-- Recent Entries -->
                <?php if (!empty($recent_entries)): ?>
                <div class="recent-entries">
                    <div class="recent-header">
                        <i class="fas fa-history" style="color: var(--primary-blue);"></i>
                        <h3>Recent Exam Entries</h3>
                    </div>
                    <div class="recent-list">
                        <?php foreach ($recent_entries as $entry): ?>
                        <div class="recent-item">
                            <div class="recent-student">
                                <div class="student-avatar">
                                    <?= strtoupper(substr($entry['first_name'], 0, 1)) ?>
                                </div>
                                <div>
                                    <strong><?= htmlspecialchars($entry['first_name'] . ' ' . $entry['last_name']) ?></strong>
                                    <div style="font-size: 12px; color: var(--text-light);">
                                        <?= htmlspecialchars($entry['stu_id']) ?> • <?= htmlspecialchars($entry['target_class']) ?>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <strong><?= htmlspecialchars($entry['subject']) ?></strong>
                            </div>
                            <div>
                                <span class="marks-badge <?= strpos($entry['exam_name'], 'Mid') !== false ? 'midterm' : 'final' ?>">
                                    <?= $entry['exam_name'] ?>
                                </span>
                            </div>
                            <div>
                                <strong><?= $entry['marks_obtained'] ?>/<?= $entry['total_marks'] ?></strong>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Success Card (shown after successful save) -->
                <?php if ($success_data): ?>
                <div class="success-card show" id="successCard">
                    <div class="success-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="success-content">
                        <h4>✅ Marks Saved Successfully!</h4>
                        <div class="success-details">
                            <div class="detail-item">
                                <i class="fas fa-user"></i>
                                <span><?= $success_data['student_name'] ?></span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-id-card"></i>
                                <span><?= $success_data['stu_id'] ?></span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-book"></i>
                                <span><?= $success_data['subject'] ?> (<?= $success_data['class'] ?>)</span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-chart-line"></i>
                                <span><?= $success_data['marks'] ?>/<?= $success_data['total'] ?></span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-calendar"></i>
                                <span><?= date('M d, Y', strtotime($success_data['date'])) ?></span>
                            </div>
                        </div>
                        <button class="btn-continue" onclick="continueEntry()">
                            <i class="fas fa-plus"></i> Enter Another Mark
                        </button>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Choice Buttons -->
                <div class="choice-buttons">
                    <button type="button" class="choice-btn midterm active" onclick="showForm('midterm')" id="midtermBtn">
                        <i class="fas fa-book"></i>
                        <span>Mid-Term Exam</span>
                        <small style="margin-top: 5px; color: var(--text-light);">Max: 40 marks</small>
                    </button>
                    <button type="button" class="choice-btn final" onclick="showForm('final')" id="finalBtn">
                        <i class="fas fa-graduation-cap"></i>
                        <span>Final Exam</span>
                        <small style="margin-top: 5px; color: var(--text-light);">Max: 60 marks</small>
                    </button>
                </div>

                <!-- Mid-Term Form -->
                <div id="midterm-form" class="form-section active">
                    <div class="form-header">
                        <i class="fas fa-book" style="color: var(--primary-blue); font-size: 24px;"></i>
                        <h3>Mid-Term Exam Entry</h3>
                        <span class="badge">Max: 40 Marks</span>
                    </div>
                    <form method="POST" onsubmit="return validateForm('midterm')">
                        <input type="hidden" name="exam_type" value="midterm">
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label" for="stu_id_mid">
                                    <i class="fas fa-id-card"></i>
                                    <span>STU-ID</span>
                                    <div class="tooltip">
                                        <i class="fas fa-info-circle"></i>
                                        <span class="tooltip-text">Student's unique identifier (e.g., STU043)</span>
                                    </div>
                                </label>
                                <input type="text" id="stu_id_mid" name="stu_id" class="form-control" 
                                       placeholder="e.g. STU043" required
                                       pattern="^STU\d{3,}$"
                                       title="Please enter a valid STU-ID (e.g., STU043)">
                                <small id="studentHint_mid" style="color: var(--text-light); font-size: 12px; margin-top: 5px;"></small>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="target_class_mid">
                                    <i class="fas fa-graduation-cap"></i>
                                    <span>Class</span>
                                </label>
                                <select id="target_class_mid" name="target_class" class="form-control" required>
                                    <option value="">-- Select Class --</option>
                                    <?php foreach ($assigned_classes as $class): ?>
                                        <option value="<?= htmlspecialchars($class) ?>"><?= htmlspecialchars($class) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="selected_subject_mid">
                                    <i class="fas fa-book-open"></i>
                                    <span>Subject</span>
                                </label>
                                <select id="selected_subject_mid" name="selected_subject" class="form-control" required>
                                    <?php foreach ($all_subjects as $subject): ?>
                                        <option value="<?= htmlspecialchars($subject) ?>" <?= ($subject === $default_subject) ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($subject) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="exam_date_mid">
                                    <i class="fas fa-calendar-alt"></i>
                                    <span>Exam Date</span>
                                </label>
                                <input type="date" id="exam_date_mid" name="exam_date" value="<?= $today ?>" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="marks_obtained_mid">
                                    <i class="fas fa-chart-line"></i>
                                    <span>Marks Obtained (0-40)</span>
                                </label>
                                <input type="number" id="marks_obtained_mid" name="marks_obtained" class="form-control" 
                                       min="0" max="40" step="0.01" placeholder="Enter marks" required>
                                <small style="color: var(--text-light); font-size: 12px; margin-top: 5px;">
                                    Enter marks between 0 and 40
                                </small>
                            </div>
                        </div>
                        <button type="submit" class="submit-btn">
                            <i class="fas fa-save"></i>
                            <span>Save Mid-Term Marks</span>
                        </button>
                    </form>
                </div>

                <!-- Final Form -->
                <div id="final-form" class="form-section">
                    <div class="form-header">
                        <i class="fas fa-graduation-cap" style="color: var(--success); font-size: 24px;"></i>
                        <h3>Final Exam Entry</h3>
                        <span class="badge final">Max: 60 Marks</span>
                    </div>
                    <form method="POST" onsubmit="return validateForm('final')">
                        <input type="hidden" name="exam_type" value="final">
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label" for="stu_id_final">
                                    <i class="fas fa-id-card"></i>
                                    <span>STU-ID</span>
                                    <div class="tooltip">
                                        <i class="fas fa-info-circle"></i>
                                        <span class="tooltip-text">Student's unique identifier (e.g., STU043)</span>
                                    </div>
                                </label>
                                <input type="text" id="stu_id_final" name="stu_id" class="form-control" 
                                       placeholder="e.g. STU043" required
                                       pattern="^STU\d{3,}$"
                                       title="Please enter a valid STU-ID (e.g., STU043)">
                                <small id="studentHint_final" style="color: var(--text-light); font-size: 12px; margin-top: 5px;"></small>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="target_class_final">
                                    <i class="fas fa-graduation-cap"></i>
                                    <span>Class</span>
                                </label>
                                <select id="target_class_final" name="target_class" class="form-control" required>
                                    <option value="">-- Select Class --</option>
                                    <?php foreach ($assigned_classes as $class): ?>
                                        <option value="<?= htmlspecialchars($class) ?>"><?= htmlspecialchars($class) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="selected_subject_final">
                                    <i class="fas fa-book-open"></i>
                                    <span>Subject</span>
                                </label>
                                <select id="selected_subject_final" name="selected_subject" class="form-control" required>
                                    <?php foreach ($all_subjects as $subject): ?>
                                        <option value="<?= htmlspecialchars($subject) ?>" <?= ($subject === $default_subject) ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($subject) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="exam_date_final">
                                    <i class="fas fa-calendar-alt"></i>
                                    <span>Exam Date</span>
                                </label>
                                <input type="date" id="exam_date_final" name="exam_date" value="<?= $today ?>" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="marks_obtained_final">
                                    <i class="fas fa-chart-line"></i>
                                    <span>Marks Obtained (0-60)</span>
                                </label>
                                <input type="number" id="marks_obtained_final" name="marks_obtained" class="form-control" 
                                       min="0" max="60" step="0.01" placeholder="Enter marks" required>
                                <small style="color: var(--text-light); font-size: 12px; margin-top: 5px;">
                                    Enter marks between 0 and 60
                                </small>
                            </div>
                        </div>
                        <button type="submit" class="submit-btn final">
                            <i class="fas fa-save"></i>
                            <span>Save Final Exam Marks</span>
                        </button>
                    </form>
                </div>

                <!-- Footer Note -->
                <div class="footer">
                    <p><i class="fas fa-info-circle"></i> You can enter marks for one student at a time. Use the dropdowns to select your assigned classes and subjects.</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Sidebar toggle functionality
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');
        const menuToggle = document.getElementById('menuToggle');
        
        menuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
            menuToggle.innerHTML = sidebar.classList.contains('collapsed') 
                ? '<i class="fas fa-bars"></i>' 
                : '<i class="fas fa-times"></i>';
        });

        // Form switching functionality
        function showForm(type) {
            // Hide all forms
            document.querySelectorAll('.form-section').forEach(form => {
                form.classList.remove('active');
            });
            
            // Show selected form
            document.getElementById(`${type}-form`).classList.add('active');
            
            // Update button states
            document.querySelectorAll('.choice-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            document.getElementById(`${type}Btn`).classList.add('active');
            
            // Add pulse animation
            const activeForm = document.getElementById(`${type}-form`);
            activeForm.classList.add('pulse');
            setTimeout(() => activeForm.classList.remove('pulse'), 500);
        }

        // Form validation
        function validateForm(type) {
            const maxMarks = type === 'midterm' ? 40 : 60;
            const stuId = document.getElementById(`stu_id_${type}`).value.trim();
            const marksInput = document.getElementById(`marks_obtained_${type}`);
            const marks = parseFloat(marksInput.value);
            
            // Validate STU-ID format
            const stuIdPattern = /^STU\d{3,}$/i;
            if (!stuIdPattern.test(stuId)) {
                showError('Please enter a valid STU-ID (e.g., STU043)');
                document.getElementById(`stu_id_${type}`).classList.add('error');
                setTimeout(() => {
                    document.getElementById(`stu_id_${type}`).classList.remove('error');
                }, 1000);
                return false;
            }
            
            // Validate marks
            if (isNaN(marks) || marks < 0 || marks > maxMarks) {
                showError(`Marks must be between 0 and ${maxMarks}`);
                marksInput.classList.add('error');
                setTimeout(() => {
                    marksInput.classList.remove('error');
                }, 1000);
                return false;
            }
            
            // Show loading state
            const submitBtn = document.querySelector(`#${type}-form .submit-btn`);
            const originalHtml = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving to Database...';
            submitBtn.disabled = true;
            
            // Restore button after 2 seconds
            setTimeout(() => {
                submitBtn.innerHTML = originalHtml;
                submitBtn.disabled = false;
            }, 2000);
            
            return true;
        }

        // Show error message as toast
        function showError(message) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'error-toast';
            errorDiv.innerHTML = `
                <i class="fas fa-exclamation-triangle"></i>
                <span>${message}</span>
                <button onclick="this.parentElement.remove()">×</button>
            `;
            document.body.appendChild(errorDiv);
            
            setTimeout(() => {
                if (errorDiv.parentElement) {
                    errorDiv.remove();
                }
            }, 5000);
        }

        // Continue entry after success
        function continueEntry() {
            const successCard = document.getElementById('successCard');
            if (successCard) {
                successCard.style.display = 'none';
            }
            
            // Reset form
            document.querySelectorAll('.form-control').forEach(input => {
                if (input.type !== 'date') {
                    input.value = '';
                }
            });
            
            // Reset date to today
            const today = new Date().toISOString().split('T')[0];
            document.querySelectorAll('input[type="date"]').forEach(input => {
                input.value = today;
            });
            
            // Focus on first input
            const activeForm = document.querySelector('.form-section.active');
            if (activeForm) {
                const firstInput = activeForm.querySelector('input[type="text"]');
                if (firstInput) {
                    firstInput.focus();
                }
            }
        }

        // Auto-hide messages after 8 seconds
        document.addEventListener('DOMContentLoaded', () => {
            const messages = document.querySelectorAll('.message');
            messages.forEach(message => {
                setTimeout(() => {
                    message.style.opacity = '0';
                    message.style.transform = 'translateX(-20px)';
                    message.style.transition = 'all 0.5s ease';
                    
                    setTimeout(() => {
                        message.style.display = 'none';
                    }, 500);
                }, 8000);
            });
            
            // Set today's date as default for all date inputs
            const today = new Date().toISOString().split('T')[0];
            document.querySelectorAll('input[type="date"]').forEach(input => {
                if (!input.value) {
                    input.value = today;
                }
                input.max = today; // Can't select future dates
            });
            
            // Add focus effects to form controls
            document.querySelectorAll('.form-control').forEach(control => {
                control.addEventListener('focus', function() {
                    this.parentElement.classList.add('focused');
                });
                
                control.addEventListener('blur', function() {
                    this.parentElement.classList.remove('focused');
                });
            });
            
            // Simulate student search on STU-ID input
            document.querySelectorAll('input[name="stu_id"]').forEach(input => {
                input.addEventListener('input', function() {
                    const stuId = this.value.trim();
                    const hintId = this.id.replace('stu_id_', 'studentHint_');
                    const hintElement = document.getElementById(hintId);
                    
                    if (stuId.length >= 3 && stuId.match(/^STU\d{3,}$/i)) {
                        hintElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Searching student...';
                        setTimeout(() => {
                            // Simulate API response
                            hintElement.innerHTML = '<i class="fas fa-check" style="color: var(--success);"></i> Valid STU-ID format';
                        }, 500);
                    } else if (stuId.length > 0) {
                        hintElement.innerHTML = '<i class="fas fa-exclamation-circle" style="color: var(--warning);"></i> Enter valid STU-ID (e.g., STU043)';
                    } else {
                        hintElement.innerHTML = '';
                    }
                });
            });
        });
    </script>
</body>
</html>