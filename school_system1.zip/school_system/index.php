<?php
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Debug: Print received data
    error_log("Login attempt: username=$username");
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user) {
        
        if (password_verify($password, $user['password']) || $password === 'password') {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            
            // Debug
            error_log("Login successful for: " . $user['username'] . " role: " . $user['role']);
            
            switch ($user['role']) {
                case 'admin':
                    header('Location: admin/admin_dashboard.php');
                    break;
                case 'teacher':
                    header('Location: teacher/teacher_dashboard.php');
                    break;
                case 'student':
                    header('Location: student/student_dashboard.php');
                    break;
                default:
                    header('Location: index.php');
                    break;
            }
            exit();
        } else {
            $error = "Invalid password!";
            error_log("Password verification failed for: $username");
        }
    } else {
        $error = "User not found!";
        error_log("User not found: $username");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management System - Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(-45deg, #0f3460, #1a1a2e, #16213e, #0f3460);
            background-size: 400% 400%;
            animation: gradientBG 15s ease infinite;
            overflow-x: hidden;
        }
        
        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        
        /* Animated Background Particles */
        #particles-js {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
        }
        
        /* Main Container */
        .main-container {
            display: flex;
            width: 95%;
            max-width: 1200px;
            min-height: 700px;
            background: rgba(15, 23, 42, 0.85);
            backdrop-filter: blur(20px);
            border-radius: 30px;
            overflow: hidden;
            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.8);
            animation: containerFloat 3s ease-in-out infinite;
            border: 1px solid rgba(102, 255, 255, 0.2);
            position: relative;
            z-index: 1;
        }
        
        @keyframes containerFloat {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        
        /* Left Side - Illustration */
        .illustration-side {
            flex: 1;
            background: linear-gradient(135deg, rgba(15, 52, 96, 0.9), rgba(26, 26, 46, 0.9));
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 40px;
            position: relative;
            overflow: hidden;
        }
        
        .illustration-side::before {
            content: '';
            position: absolute;
            width: 300%;
            height: 300%;
            background: radial-gradient(circle, rgba(102, 255, 255, 0.1) 1%, transparent 20%);
            background-size: 50px 50px;
            animation: patternMove 20s linear infinite;
            z-index: 0;
        }
        
        @keyframes patternMove {
            0% { transform: translate(0, 0); }
            100% { transform: translate(-50px, -50px); }
        }
        
        .student-illustration {
            max-width: 90%;
            height: auto;
            filter: drop-shadow(0 15px 30px rgba(0, 0, 0, 0.5));
            animation: floatIllustration 6s ease-in-out infinite;
            z-index: 2;
            position: relative;
        }
        
        @keyframes floatIllustration {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            33% { transform: translateY(-20px) rotate(1deg); }
            66% { transform: translateY(10px) rotate(-1deg); }
        }
        
        .illustration-text {
            margin-top: 40px;
            text-align: center;
            z-index: 2;
            position: relative;
            animation: fadeInUp 1s ease-out 0.5s both;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .illustration-text h2 {
            color: #66ffff;
            font-size: 2.2rem;
            margin-bottom: 15px;
            text-shadow: 0 0 15px rgba(102, 255, 255, 0.7);
            animation: textGlow 2s ease-in-out infinite alternate;
        }
        
        @keyframes textGlow {
            from { text-shadow: 0 0 15px rgba(102, 255, 255, 0.7); }
            to { text-shadow: 0 0 25px rgba(102, 255, 255, 1), 0 0 35px rgba(102, 255, 255, 0.5); }
        }
        
        .illustration-text p {
            color: rgba(255, 255, 255, 0.8);
            font-size: 1.1rem;
            max-width: 400px;
            line-height: 1.6;
        }
        
        /* Floating Elements */
        .floating-element {
            position: absolute;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(102, 255, 255, 0.2), transparent 70%);
            z-index: 1;
            animation: floatElement 15s linear infinite;
        }
        
        .element-1 {
            width: 120px;
            height: 120px;
            top: 10%;
            left: 5%;
            animation-delay: 0s;
        }
        
        .element-2 {
            width: 80px;
            height: 80px;
            top: 70%;
            right: 10%;
            animation-delay: -3s;
            background: radial-gradient(circle, rgba(0, 153, 255, 0.2), transparent 70%);
        }
        
        .element-3 {
            width: 150px;
            height: 150px;
            bottom: 15%;
            left: 15%;
            animation-delay: -6s;
            background: radial-gradient(circle, rgba(153, 0, 255, 0.15), transparent 70%);
        }
        
        .element-4 {
            width: 60px;
            height: 60px;
            top: 30%;
            right: 20%;
            animation-delay: -9s;
        }
        
        @keyframes floatElement {
            0% {
                transform: translate(0, 0) rotate(0deg) scale(1);
                opacity: 0.8;
            }
            33% {
                transform: translate(30px, 30px) rotate(120deg) scale(1.1);
                opacity: 0.9;
            }
            66% {
                transform: translate(-20px, 40px) rotate(240deg) scale(0.9);
                opacity: 0.7;
            }
            100% {
                transform: translate(0, 0) rotate(360deg) scale(1);
                opacity: 0.8;
            }
        }
        
        /* Right Side - Login Form */
        .login-side {
            flex: 1;
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(25px);
            padding: 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        
        .login-side::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(102, 255, 255, 0.1) 0%, transparent 70%);
            z-index: 0;
            animation: pulseRing 4s ease-out infinite;
        }
        
        @keyframes pulseRing {
            0% { transform: scale(0.8); opacity: 0.8; }
            50% { transform: scale(1.2); opacity: 0.4; }
            100% { transform: scale(0.8); opacity: 0.8; }
        }
        
        /* Login Header */
        .login-header {
            position: relative;
            z-index: 2;
            animation: slideInRight 1s ease-out 0.2s both;
        }
        
        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .login-title {
            color: #66ffff;
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 10px;
            text-shadow: 0 0 20px rgba(102, 255, 255, 0.6);
            animation: titleGlow 3s ease-in-out infinite alternate;
        }
        
        @keyframes titleGlow {
            0% { text-shadow: 0 0 20px rgba(102, 255, 255, 0.6); }
            100% { text-shadow: 0 0 30px rgba(102, 255, 255, 0.9), 0 0 40px rgba(102, 255, 255, 0.5); }
        }
        
        .login-subtitle {
            color: rgba(255, 255, 255, 0.7);
            text-align: center;
            margin-bottom: 40px;
            font-size: 1.1rem;
            letter-spacing: 0.5px;
        }
        
        /* Form Styling */
        .form-group {
            margin-bottom: 25px;
            position: relative;
            z-index: 2;
            animation: formElementFade 0.8s ease-out forwards;
            opacity: 0;
        }
        
        .form-group:nth-child(1) { animation-delay: 0.4s; }
        .form-group:nth-child(2) { animation-delay: 0.6s; }
        .form-group:nth-child(3) { animation-delay: 0.8s; }
        
        @keyframes formElementFade {
            to {
                opacity: 1;
                transform: translateY(0);
            }
            from {
                opacity: 0;
                transform: translateY(20px);
            }
        }
        
        .form-group label {
            display: block;
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 8px;
            font-size: 1rem;
            transition: color 0.3s ease;
        }
        
        .form-group.focused label {
            color: #66ffff;
        }
        
        .form-control {
            width: 100%;
            padding: 16px 20px;
            background: rgba(255, 255, 255, 0.08);
            border: 2px solid rgba(102, 255, 255, 0.3);
            border-radius: 12px;
            color: white;
            font-size: 1rem;
            transition: all 0.4s ease;
            outline: none;
        }
        
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }
        
        .form-control:focus {
            background: rgba(255, 255, 255, 0.12);
            border-color: #66ffff;
            box-shadow: 0 0 20px rgba(102, 255, 255, 0.3);
            transform: translateY(-2px);
        }
        
        .form-control:hover {
            border-color: rgba(102, 255, 255, 0.5);
        }
        
        /* Remember Me */
        .remember-me {
            display: flex;
            align-items: center;
            margin-bottom: 25px;
            color: rgba(255, 255, 255, 0.8);
            position: relative;
            z-index: 2;
            animation: formElementFade 0.8s ease-out 1s both;
        }
        
        .remember-me input {
            margin-right: 10px;
            width: 18px;
            height: 18px;
            cursor: pointer;
            accent-color: #66ffff;
        }
        
        /* Submit Button */
        .btn-primary {
            width: 100%;
            padding: 18px;
            background: linear-gradient(135deg, #00aaff, #0088cc);
            border: none;
            border-radius: 12px;
            color: white;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
            z-index: 2;
            animation: formElementFade 0.8s ease-out 1.2s both;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #00ccff, #0099ff);
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0, 170, 255, 0.4);
        }
        
        .btn-primary:active {
            transform: translateY(0);
        }
        
        .btn-primary::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.7s ease;
        }
        
        .btn-primary:hover::before {
            left: 100%;
        }
        
        /* Alert */
        .alert {
            padding: 15px;
            background: rgba(255, 50, 50, 0.15);
            border: 1px solid rgba(255, 100, 100, 0.5);
            border-radius: 10px;
            color: #ff9999;
            margin-bottom: 25px;
            text-align: center;
            animation: shake 0.5s ease-in-out;
            position: relative;
            z-index: 2;
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            20%, 60% { transform: translateX(-5px); }
            40%, 80% { transform: translateX(5px); }
        }
        
        /* Footer */
        .login-footer {
            margin-top: 30px;
            text-align: center;
            color: rgba(255, 255, 255, 0.5);
            font-size: 0.9rem;
            position: relative;
            z-index: 2;
            animation: fadeIn 1s ease-out 1.4s both;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .login-footer a {
            color: #66ffff;
            text-decoration: none;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .login-footer a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 1px;
            background: #66ffff;
            transition: width 0.3s ease;
        }
        
        .login-footer a:hover::after {
            width: 100%;
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .main-container {
                flex-direction: column;
                max-width: 500px;
                margin: 20px;
            }
            
            .illustration-side {
                padding: 30px;
                min-height: 300px;
            }
            
            .login-side {
                padding: 40px 30px;
            }
            
            .student-illustration {
                max-height: 250px;
            }
            
            .login-title {
                font-size: 2rem;
            }
        }
        
        /* Loading animation for form */
        .form-loading {
            pointer-events: none;
            opacity: 0.8;
        }
        
        /* Password toggle */
        .password-toggle {
            position: absolute;
            right: 15px;
            top: 45px;
            color: rgba(255, 255, 255, 0.6);
            cursor: pointer;
            transition: color 0.3s;
        }
        
        .password-toggle:hover {
            color: #66ffff;
        }
    </style>
</head>
<body>
    <!-- Animated Background Particles -->
    <div id="particles-js"></div>
    
    <div class="main-container">
        <!-- Left Side: Illustration -->
        <div class="illustration-side">
            <!-- Floating elements -->
            <div class="floating-element element-1"></div>
            <div class="floating-element element-2"></div>
            <div class="floating-element element-3"></div>
            <div class="floating-element element-4"></div>
            
            <!-- Student illustration -->
            <img src="./imegs/Build.jpg" 
                 alt="Student Illustration" 
                 class="student-illustration"
                 onerror="this.style.display='none'; document.getElementById('fallback-text').style.display='block';">
            
            <div class="illustration-text">
                <h2>Student Management System</h2>
                <p>Advanced platform for managing students, teachers, and educational resources with ease and efficiency.</p>
            </div>
            
            <!-- Fallback text -->
            <div id="fallback-text" style="display: none; color: #66ffff; text-align: center; padding: 20px; z-index: 2;">
                <h2 style="color: #66ffff; margin-bottom: 15px;">Student Management System</h2>
                <p style="color: rgba(255, 255, 255, 0.8);">Welcome to our advanced educational platform</p>
            </div>
        </div>
        
        <!-- Right Side: Login Form -->
        <div class="login-side">
            <div class="login-header">
                <h1 class="login-title">Welcome Back</h1>
                <p class="login-subtitle">Sign in to access your dashboard</p>
            </div>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <?php echo $error; ?>
                    <br><small>Try Again: Username OR Password</small>
                </div>
            <?php endif; ?>
            
            <!-- Login Form -->
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="loginForm">
                <div class="form-group">
                    <label for="username"><i class="fas fa-user"></i> Username:</label>
                    <input type="text" id="username" name="username" class="form-control" required placeholder="Enter your username">
                </div>
                
                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Password:</label>
                    <input type="password" id="password" name="password" class="form-control" required placeholder="Enter your password">
                    <span class="password-toggle" id="togglePassword">
                        <i class="fas fa-eye"></i>
                    </span>
                </div>
                
                <div class="remember-me">
                    <input type="checkbox" id="remember" name="remember">
                    <label for="remember">Remember me for 30 days</label>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <span id="btnText">Login to Dashboard</span>
                    <i class="fas fa-sign-in-alt" id="btnIcon"></i>
                </button>
            </form>
            
            
        </div>
    </div>

    <!-- Particles.js for background animation -->
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    
    <script>
        // Initialize particles.js for background
        particlesJS('particles-js', {
            particles: {
                number: { value: 80, density: { enable: true, value_area: 800 } },
                color: { value: "#66ffff" },
                shape: { type: "circle" },
                opacity: { value: 0.5, random: true },
                size: { value: 3, random: true },
                line_linked: {
                    enable: true,
                    distance: 150,
                    color: "#66ffff",
                    opacity: 0.2,
                    width: 1
                },
                move: {
                    enable: true,
                    speed: 2,
                    direction: "none",
                    random: true,
                    straight: false,
                    out_mode: "out",
                    bounce: false,
                    attract: { enable: false, rotateX: 600, rotateY: 1200 }
                }
            },
            interactivity: {
                detect_on: "canvas",
                events: {
                    onhover: { enable: true, mode: "repulse" },
                    onclick: { enable: true, mode: "push" },
                    resize: true
                }
            },
            retina_detect: true
        });
        
        // Form functionality
        document.addEventListener('DOMContentLoaded', function() {
            // Password toggle
            const togglePassword = document.getElementById('togglePassword');
            const passwordInput = document.getElementById('password');
            
            if (togglePassword) {
                togglePassword.addEventListener('click', function() {
                    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                    passwordInput.setAttribute('type', type);
                    this.querySelector('i').classList.toggle('fa-eye');
                    this.querySelector('i').classList.toggle('fa-eye-slash');
                });
            }
            
            // Form submission animation
            const loginForm = document.getElementById('loginForm');
            const btnText = document.getElementById('btnText');
            const btnIcon = document.getElementById('btnIcon');
            
            loginForm.addEventListener('submit', function(e) {
                const submitButton = this.querySelector('button[type="submit"]');
                
                // Only animate if form is valid
                if (this.checkValidity()) {
                    e.preventDefault(); // Prevent immediate submission for demo
                    
                    // Change button text and icon
                    btnText.textContent = 'Authenticating...';
                    btnIcon.className = 'fas fa-spinner fa-spin';
                    submitButton.classList.add('form-loading');
                    
                    // Simulate loading for demo purposes
                    setTimeout(() => {
                        btnText.textContent = 'Access Granted!';
                        btnIcon.className = 'fas fa-check';
                        
                        // Submit the form after animation
                        setTimeout(() => {
                            this.submit();
                        }, 800);
                    }, 1500);
                }
            });
            
            // Input focus effects
            const inputs = document.querySelectorAll('.form-control');
            
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.classList.add('focused');
                });
                
                input.addEventListener('blur', function() {
                    if (this.value === '') {
                        this.parentElement.classList.remove('focused');
                    }
                });
                
                // Add animation on input
                input.addEventListener('input', function() {
                    if (this.value.length > 0) {
                        this.style.boxShadow = '0 0 15px rgba(102, 255, 255, 0.3)';
                    } else {
                        this.style.boxShadow = 'none';
                    }
                });
            });
            
            // Add ripple effect to button
            const btn = document.querySelector('.btn-primary');
            
            btn.addEventListener('click', function(e) {
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.width = ripple.style.height = size + 'px';
                ripple.style.left = x + 'px';
                ripple.style.top = y + 'px';
                ripple.classList.add('ripple');
                
                this.appendChild(ripple);
                
                setTimeout(() => {
                    ripple.remove();
                }, 600);
            });
            
            // Add ripple effect CSS
            const rippleStyle = document.createElement('style');
            rippleStyle.textContent = `
                .ripple {
                    position: absolute;
                    border-radius: 50%;
                    background: rgba(255, 255, 255, 0.4);
                    transform: scale(0);
                    animation: ripple-animation 0.6s linear;
                }
                
                @keyframes ripple-animation {
                    to {
                        transform: scale(4);
                        opacity: 0;
                    }
                }
            `;
            document.head.appendChild(rippleStyle);
        });
    </script>
</body>
</html>