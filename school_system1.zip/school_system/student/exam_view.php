<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student') {
    header('Location: ../index.php');
    exit();
}

// Get STU-ID and student info
$user = $pdo->prepare("SELECT username FROM users WHERE id = ?");
$user->execute([$_SESSION['user_id']]);
$username = $user->fetchColumn();

$stmt = $pdo->prepare("SELECT id, first_name, last_name, grade_level FROM students WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch();

if (!$student) {
    die("Student profile not found.");
}

$student_id = $student['id'];
$student_name = $student['first_name'] . ' ' . $student['last_name'];
$grade_level = $student['grade_level'];
$stu_id = $username ?? 'N/A';

// Get exam results SEPARATELY for Mid-Term and Final
$midterm_stmt = $pdo->prepare("
    SELECT 
        e.subject,
        e.exam_name,
        e.total_marks,
        er.marks_obtained,
        e.exam_date
    FROM exams e
    JOIN exam_results er ON e.id = er.exam_id AND er.student_id = ?
    WHERE e.target_class = ?
    AND e.exam_type = 'Mid-Term'
    ORDER BY e.subject, e.exam_date
");
$midterm_stmt->execute([$student_id, $grade_level]);
$midterm_exams = $midterm_stmt->fetchAll();

$final_stmt = $pdo->prepare("
    SELECT 
        e.subject,
        e.exam_name,
        e.total_marks,
        er.marks_obtained,
        e.exam_date
    FROM exams e
    JOIN exam_results er ON e.id = er.exam_id AND er.student_id = ?
    WHERE e.target_class = ?
    AND e.exam_type = 'Final'
    ORDER BY e.subject, e.exam_date
");
$final_stmt->execute([$student_id, $grade_level]);
$final_exams = $final_stmt->fetchAll();

// Organize data by subject
$subjects_midterm = [];
$subjects_final = [];

foreach ($midterm_exams as $exam) {
    $subject = $exam['subject'];
    $subjects_midterm[$subject] = [
        'marks' => $exam['marks_obtained'],
        'max' => $exam['total_marks'],
        'date' => $exam['exam_date']
    ];
}

foreach ($final_exams as $exam) {
    $subject = $exam['subject'];
    $subjects_final[$subject] = [
        'marks' => $exam['marks_obtained'],
        'max' => $exam['total_marks'],
        'date' => $exam['exam_date']
    ];
}

// Combine all subjects
$all_subjects = array_unique(array_merge(
    array_keys($subjects_midterm),
    array_keys($subjects_final)
));

// Calculate total and grade for each subject
$subjects_data = [];
foreach ($all_subjects as $subject) {
    $midterm = $subjects_midterm[$subject] ?? null;
    $final = $subjects_final[$subject] ?? null;
    
    $midterm_marks = $midterm ? $midterm['marks'] : null;
    $final_marks = $final ? $final['marks'] : null;
    
    // Calculate total (midterm 40%, final 60%)
    $midterm_score = $midterm_marks ? ($midterm_marks / $midterm['max']) * 40 : 0;
    $final_score = $final_marks ? ($final_marks / $final['max']) * 60 : 0;
    $total_score = $midterm_score + $final_score;
    
    // Determine grade
    $grade = 'N/A';
    if ($midterm_marks !== null || $final_marks !== null) {
        if ($total_score >= 90) $grade = 'A';
        elseif ($total_score >= 80) $grade = 'B';
        elseif ($total_score >= 70) $grade = 'C';
        elseif ($total_score >= 60) $grade = 'D';
        else $grade = 'F';
    }
    
    $subjects_data[$subject] = [
        'midterm' => $midterm,
        'final' => $final,
        'total' => $total_score,
        'grade' => $grade
    ];
}

// Calculate class ranking for each student
$ranking_stmt = $pdo->prepare("
    SELECT 
        er.student_id,
        SUM(CASE 
            WHEN e.exam_type = 'Mid-Term' THEN (er.marks_obtained / e.total_marks) * 40
            WHEN e.exam_type = 'Final' THEN (er.marks_obtained / e.total_marks) * 60
            ELSE 0
        END) as total_percentage,
        COUNT(DISTINCT e.subject) as subjects_count
    FROM exam_results er
    JOIN exams e ON er.exam_id = e.id
    WHERE e.target_class = ?
    GROUP BY er.student_id
    HAVING subjects_count >= 1
    ORDER BY total_percentage DESC
");
$ranking_stmt->execute([$grade_level]);
$rankings = $ranking_stmt->fetchAll();

// Create ranking array
$student_rankings = [];
$rank = 1;
$previous_score = null;
$skip_rank = 0;

foreach ($rankings as $index => $ranking) {
    $current_score = $ranking['total_percentage'];
    
    // Handle tie ranks
    if ($previous_score !== null && $current_score == $previous_score) {
        $skip_rank++;
    } else {
        $rank = $rank + $skip_rank;
        $skip_rank = 0;
    }
    
    $student_rankings[$ranking['student_id']] = [
        'position' => $rank,
        'score' => $current_score
    ];
    
    $rank++;
    $previous_score = $current_score;
}

// Get current student's position
$student_position = $student_rankings[$student_id]['position'] ?? 'N/A';
$class_total_students = count($rankings);

function getGradeColor($grade) {
    switch (strtoupper($grade)) {
        case 'A': return '#10b981'; // Green
        case 'B': return '#3b82f6'; // Blue
        case 'C': return '#f59e0b'; // Orange
        case 'D': return '#ef4444'; // Red
        case 'F': return '#6b7280'; // Gray
        default: return '#64748b';
    }
}

function getGradeClass($grade) {
    $g = strtoupper($grade);
    if ($g === 'A') return 'grade-a';
    if ($g === 'B') return 'grade-b';
    if ($g === 'C') return 'grade-c';
    if ($g === 'D') return 'grade-d';
    if ($g === 'F') return 'grade-f';
    return 'grade-na';
}

// Get statistics
$total_subjects = count($all_subjects);
$average_score = $total_subjects > 0 ? array_sum(array_column($subjects_data, 'total')) / $total_subjects : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Exam Results | Student Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            --primary-dark: #0a192f;
            --primary-blue: #00ccff;
            --accent-purple: #9d4edd;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --white: #ffffff;
            --light-gray: #f8fafc;
            --medium-gray: #e2e8f0;
            --dark-gray: #64748b;
            --text-dark: #1e293b;
            --gradient-blue: linear-gradient(135deg, #00ccff 0%, #3366ff 100%);
            --gradient-purple: linear-gradient(135deg, #9d4edd 0%, #5a00cc 100%);
            --gold: #FFD700;
            --silver: #C0C0C0;
            --bronze: #CD7F32;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--light-gray);
            color: var(--text-dark);
            min-height: 100vh;
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: var(--primary-dark);
            color: var(--white);
            padding: 25px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            text-align: center;
            padding: 0 20px 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 25px;
        }

        .student-avatar {
            width: 70px;
            height: 70px;
            background: var(--gradient-blue);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: 600;
            margin: 0 auto 15px;
            color: var(--white);
            border: 3px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar-header h3 {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.7);
            background: rgba(0, 204, 255, 0.2);
            padding: 4px 12px;
            border-radius: 20px;
            display: inline-block;
        }

        /* Navigation */
        .nav-links {
            list-style: none;
            padding: 0 20px;
        }

        .nav-links li {
            margin-bottom: 5px;
        }

        .nav-links a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            padding: 14px 18px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .nav-links a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            transform: translateX(5px);
        }

        .nav-links a.active {
            background: rgba(0, 204, 255, 0.25);
            color: var(--white);
        }

        .nav-links i {
            width: 22px;
            margin-right: 12px;
            font-size: 18px;
        }

        /* Logout Button */
        .logout-btn {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            border: none;
            padding: 14px;
            margin: 20px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateY(-2px);
        }

        .logout-btn i {
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 30px;
        }

        /* Header */
        .page-header {
            background: var(--white);
            padding: 25px 30px;
            border-radius: 15px;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-header h1 {
            color: var(--primary-dark);
            font-size: 28px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .page-header h1 i {
            color: var(--primary-blue);
            font-size: 26px;
        }

        .student-info {
            display: flex;
            flex-direction: column;
            gap: 10px;
            text-align: right;
        }

        .student-id {
            background: var(--gradient-blue);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 14px;
        }

        .student-class {
            color: var(--dark-gray);
            font-size: 14px;
        }

        /* Quick Stats */
        .quick-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--white);
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            gap: 15px;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            color: white;
        }

        .stat-icon.midterm {
            background: var(--gradient-blue);
        }

        .stat-icon.final {
            background: var(--gradient-purple);
        }

        .stat-icon.position {
            background: linear-gradient(135deg, var(--gold) 0%, #FFA500 100%);
        }

        .stat-icon.average {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        }

        .stat-icon.total {
            background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
        }

        .stat-content h3 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-content p {
            font-size: 14px;
            color: var(--dark-gray);
        }

        /* Position Styles */
        .position-number {
            font-size: 28px;
            font-weight: 800;
        }

        .position-1 { color: var(--gold); text-shadow: 0 0 10px rgba(255, 215, 0, 0.3); }
        .position-2 { color: var(--silver); text-shadow: 0 0 10px rgba(192, 192, 192, 0.3); }
        .position-3 { color: var(--bronze); text-shadow: 0 0 10px rgba(205, 127, 50, 0.3); }
        .position-other { color: var(--primary-dark); }

        /* Results Table */
        .results-section {
            background: var(--white);
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            padding: 30px;
            margin-bottom: 30px;
        }

        .section-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--light-gray);
        }

        .section-header h2 {
            color: var(--primary-dark);
            font-size: 22px;
            font-weight: 600;
        }

        .section-header i {
            color: var(--primary-blue);
            font-size: 24px;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 900px;
        }

        thead {
            background: linear-gradient(135deg, var(--primary-dark) 0%, #0c2040 100%);
        }

        th {
            padding: 18px 20px;
            text-align: left;
            color: white;
            font-weight: 600;
            font-size: 15px;
            border: none;
        }

        th:first-child {
            border-radius: 10px 0 0 0;
        }

        th:last-child {
            border-radius: 0 10px 0 0;
        }

        tbody tr {
            border-bottom: 1px solid var(--medium-gray);
            transition: all 0.3s ease;
        }

        tbody tr:hover {
            background: rgba(0, 204, 255, 0.05);
        }

        td {
            padding: 18px 20px;
            text-align: left;
            font-size: 15px;
        }

        .subject-cell {
            font-weight: 600;
            color: var(--primary-dark);
        }

        .marks-cell {
            font-weight: 600;
            font-size: 16px;
        }

        .midterm-cell {
            color: #00ccff;
        }

        .final-cell {
            color: #9d4edd;
        }

        .total-cell {
            color: var(--primary-dark);
            font-weight: 700;
            font-size: 17px;
        }

        .grade-cell {
            font-weight: 700;
            font-size: 16px;
        }

        .grade-badge {
            padding: 6px 14px;
            border-radius: 20px;
            font-weight: 700;
            font-size: 14px;
            display: inline-block;
            min-width: 50px;
            text-align: center;
        }

        .grade-a { 
            background: rgba(16, 185, 129, 0.15); 
            color: var(--success);
            border: 1px solid rgba(16, 185, 129, 0.3);
        }
        .grade-b { 
            background: rgba(59, 130, 246, 0.15); 
            color: #3b82f6;
            border: 1px solid rgba(59, 130, 246, 0.3);
        }
        .grade-c { 
            background: rgba(245, 158, 11, 0.15); 
            color: var(--warning);
            border: 1px solid rgba(245, 158, 11, 0.3);
        }
        .grade-d { 
            background: rgba(239, 68, 68, 0.15); 
            color: var(--danger);
            border: 1px solid rgba(239, 68, 68, 0.3);
        }
        .grade-f { 
            background: rgba(107, 114, 128, 0.15); 
            color: #6b7280;
            border: 1px solid rgba(107, 114, 128, 0.3);
        }
        .grade-na { 
            background: rgba(100, 116, 139, 0.15); 
            color: var(--dark-gray);
            border: 1px solid rgba(100, 116, 139, 0.3);
        }

        /* Class Average Styles */
        .class-avg-cell {
            font-weight: 600;
            font-size: 16px;
        }

        .above-avg { color: var(--success); }
        .below-avg { color: var(--danger); }
        .equal-avg { color: var(--warning); }

        .comparison-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            margin-top: 5px;
        }

        .above-avg-badge { 
            background: rgba(16, 185, 129, 0.15); 
            color: var(--success);
        }
        .below-avg-badge { 
            background: rgba(239, 68, 68, 0.15); 
            color: var(--danger);
        }
        .equal-avg-badge { 
            background: rgba(245, 158, 11, 0.15); 
            color: var(--warning);
        }

        /* Status Indicators */
        .status-pending {
            color: var(--warning);
            background: rgba(245, 158, 11, 0.15);
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 13px;
            display: inline-block;
        }

        .status-completed {
            color: var(--success);
            background: rgba(16, 185, 129, 0.15);
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 13px;
            display: inline-block;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--dark-gray);
        }

        .empty-state i {
            font-size: 48px;
            margin-bottom: 20px;
            color: var(--medium-gray);
        }

        .empty-state h3 {
            font-size: 20px;
            margin-bottom: 10px;
            color: var(--text-dark);
        }

        .empty-state p {
            font-size: 15px;
            max-width: 400px;
            margin: 0 auto;
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 20px;
            color: var(--dark-gray);
            font-size: 14px;
            background: var(--white);
            border-radius: 10px;
            margin-top: 30px;
        }

        .footer i {
            color: var(--primary-blue);
            margin-right: 8px;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .sidebar {
                width: 80px;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .sidebar-header h3,
            .sidebar-header p,
            .nav-links span,
            .logout-btn span {
                display: none;
            }
            
            .nav-links a {
                justify-content: center;
                padding: 15px;
            }
            
            .nav-links i {
                margin-right: 0;
                font-size: 20px;
            }
            
            .student-avatar {
                width: 50px;
                height: 50px;
                font-size: 20px;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                flex-direction: row;
                padding: 15px;
            }
            
            .main-content {
                margin-left: 0;
                margin-top: 20px;
            }
            
            .sidebar-header {
                display: flex;
                align-items: center;
                padding: 0;
                border-bottom: none;
                margin-bottom: 0;
                margin-right: 15px;
            }
            
            .student-avatar {
                width: 40px;
                height: 40px;
                margin: 0 10px 0 0;
            }
            
            .nav-links {
                display: flex;
                padding: 0;
                flex-grow: 0;
            }
            
            .nav-links li {
                margin-bottom: 0;
                margin-right: 5px;
            }
            
            .logout-btn {
                margin: 0 0 0 auto;
                padding: 10px;
            }
            
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .student-info {
                text-align: left;
            }
            
            .quick-stats {
                grid-template-columns: 1fr;
            }
            
            .table-container {
                margin: 0 -15px;
                padding: 0 15px;
            }
        }

        @media (max-width: 480px) {
            .main-content {
                padding: 15px;
            }
            
            .page-header {
                padding: 20px;
            }
            
            .results-section {
                padding: 20px;
            }
            
            th, td {
                padding: 12px 15px;
            }
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="student-avatar">
                <?= strtoupper(substr($student_name[0] ?? 'S', 0, 1)) ?>
            </div>
            <h3><?= htmlspecialchars($student_name) ?></h3>
            <p>Student</p>
        </div>
        
        <ul class="nav-links">
            <li><a href="student_dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
            <li><a href="my_exams.php" class="active"><i class="fas fa-file-alt"></i> <span>My Exams</span></a></li>
            <li><a href="student_attendance.php"><i class="fas fa-calendar-check"></i> <span>Attendance</span></a></li>
            <li><a href="profile.php"><i class="fas fa-user-cog"></i> <span>Profile</span></a></li>
        </ul>
        
        <button class="logout-btn" onclick="window.location='../index.php'">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </button>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="page-header">
            <h1><i class="fas fa-chart-line"></i> My Exam Results</h1>
            <div class="student-info">
                <div class="student-id">
                    <i class="fas fa-id-card"></i> <?= htmlspecialchars($stu_id) ?>
                </div>
                <div class="student-class">
                    <i class="fas fa-graduation-cap"></i> <?= htmlspecialchars($grade_level) ?>
                </div>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="quick-stats">
            <div class="stat-card">
                <div class="stat-icon midterm">
                    <i class="fas fa-book"></i>
                </div>
                <div class="stat-content">
                    <h3><?= count($midterm_exams) ?></h3>
                    <p>Mid-Term Exams</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon final">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <div class="stat-content">
                    <h3><?= count($final_exams) ?></h3>
                    <p>Final Exams</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon position">
                    <i class="fas fa-trophy"></i>
                </div>
                <div class="stat-content">
                    <h3 class="position-number 
                        <?php if ($student_position == 1): ?>position-1
                        <?php elseif ($student_position == 2): ?>position-2
                        <?php elseif ($student_position == 3): ?>position-3
                        <?php else: ?>position-other<?php endif; ?>">
                        <?php if ($student_position !== 'N/A'): ?>
                            <?= $student_position ?>
                            <small style="font-size: 14px; color: var(--dark-gray);">/ <?= $class_total_students ?></small>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </h3>
                    <p>Class Position</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon average">
                    <i class="fas fa-calculator"></i>
                </div>
                <div class="stat-content">
                    <h3><?= number_format($average_score, 1) ?>%</h3>
                    <p>Average Score</p>
                </div>
            </div>
        </div>

        <!-- Results Table -->
        <div class="results-section">
            <div class="section-header">
                <i class="fas fa-table"></i>
                <h2>Subject-wise Results</h2>
            </div>
            
            <?php if (!empty($subjects_data)): ?>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Subject</th>
                                <th>Mid-Term Exam</th>
                                <th>Final Exam</th>
                                <th>Total Score</th>
                                <th>Grade</th>
                                <th>Class Avg</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($subjects_data as $subject => $data): ?>
                                <?php
                                $midterm_status = $data['midterm'] ? 'completed' : 'pending';
                                $final_status = $data['final'] ? 'completed' : 'pending';
                                $overall_status = ($data['midterm'] || $data['final']) ? 'completed' : 'pending';
                                
                                // Calculate subject average for the class
                                $subject_avg_stmt = $pdo->prepare("
                                    SELECT 
                                        AVG(CASE 
                                            WHEN e.exam_type = 'Mid-Term' THEN (er.marks_obtained / e.total_marks) * 40
                                            WHEN e.exam_type = 'Final' THEN (er.marks_obtained / e.total_marks) * 60
                                            ELSE 0
                                        END) as class_average
                                    FROM exam_results er
                                    JOIN exams e ON er.exam_id = e.id
                                    WHERE e.target_class = ?
                                    AND e.subject = ?
                                ");
                                $subject_avg_stmt->execute([$grade_level, $subject]);
                                $subject_class_avg = $subject_avg_stmt->fetchColumn();
                                $subject_class_avg = $subject_class_avg ? number_format($subject_class_avg, 1) : 'N/A';
                                
                                // Compare student score with class average
                                $comparison = '';
                                $comparison_class = '';
                                $badge_class = '';
                                if ($subject_class_avg !== 'N/A' && $data['total'] > 0) {
                                    $difference = $data['total'] - $subject_class_avg;
                                    if ($difference > 10) {
                                        $comparison = 'Above Average';
                                        $comparison_class = 'above-avg';
                                        $badge_class = 'above-avg-badge';
                                    } elseif ($difference > 0) {
                                        $comparison = 'Above Average';
                                        $comparison_class = 'above-avg';
                                        $badge_class = 'above-avg-badge';
                                    } elseif ($difference < -10) {
                                        $comparison = 'Below Average';
                                        $comparison_class = 'below-avg';
                                        $badge_class = 'below-avg-badge';
                                    } elseif ($difference < 0) {
                                        $comparison = 'Below Average';
                                        $comparison_class = 'below-avg';
                                        $badge_class = 'below-avg-badge';
                                    } else {
                                        $comparison = 'Equal to Average';
                                        $comparison_class = 'equal-avg';
                                        $badge_class = 'equal-avg-badge';
                                    }
                                }
                                ?>
                                <tr>
                                    <td class="subject-cell"><?= htmlspecialchars($subject) ?></td>
                                    
                                    <td class="marks-cell midterm-cell">
                                        <?php if ($data['midterm']): ?>
                                            <?= $data['midterm']['marks'] ?> / <?= $data['midterm']['max'] ?>
                                            <div style="font-size: 12px; color: var(--dark-gray); margin-top: 5px;">
                                                <?= date('M d, Y', strtotime($data['midterm']['date'])) ?>
                                            </div>
                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td class="marks-cell final-cell">
                                        <?php if ($data['final']): ?>
                                            <?= $data['final']['marks'] ?> / <?= $data['final']['max'] ?>
                                            <div style="font-size: 12px; color: var(--dark-gray); margin-top: 5px;">
                                                <?= date('M d, Y', strtotime($data['final']['date'])) ?>
                                            </div>
                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td class="total-cell">
                                        <?= number_format($data['total'], 1) ?> / 100
                                    </td>
                                    
                                    <td class="grade-cell">
                                        <span class="grade-badge <?= getGradeClass($data['grade']) ?>">
                                            <?= $data['grade'] ?>
                                        </span>
                                    </td>
                                    
                                    <!-- Class Average Column -->
                                    <td class="class-avg-cell">
                                        <div class="<?= $comparison_class ?>">
                                            <?= $subject_class_avg ?>%
                                        </div>
                                        <?php if ($comparison): ?>
                                            <div class="comparison-badge <?= $badge_class ?>">
                                                <?= $comparison ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>
                                        <?php if ($overall_status === 'completed'): ?>
                                            <span class="status-completed">
                                                <i class="fas fa-check-circle"></i> Complete
                                            </span>
                                        <?php else: ?>
                                            <span class="status-pending">
                                                <i class="fas fa-clock"></i> Pending
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-file-alt"></i>
                    <h3>No Exam Results Found</h3>
                    <p>Your exam results will appear here once your teachers have entered them into the system.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Footer Note -->
        <div class="footer">
            <p><i class="fas fa-info-circle"></i> 
                <?php if ($student_position == 1): ?>
                    Congratulations! You are ranked #1 in your class! 🏆
                <?php elseif ($student_position == 2): ?>
                    Excellent! You are ranked #2 in your class! 🥈
                <?php elseif ($student_position == 3): ?>
                    Great job! You are ranked #3 in your class! 🥉
                <?php elseif ($student_position !== 'N/A' && $student_position <= 10): ?>
                    Good work! You are in the top 10 of your class (Position <?= $student_position ?>).
                <?php else: ?>
                    These are your official exam results as entered by your teachers.
                <?php endif; ?>
            </p>
        </div>
    </div>

    <script>
        // Auto-refresh page every 60 seconds to check for new results
        setTimeout(() => {
            window.location.reload();
        }, 60000);

        // Highlight rows on hover
        document.querySelectorAll('tbody tr').forEach(row => {
            row.addEventListener('mouseenter', function() {
                this.style.transform = 'translateX(5px)';
            });
            
            row.addEventListener('mouseleave', function() {
                this.style.transform = 'translateX(0)';
            });
        });

        // Add animation to grade badges
        document.querySelectorAll('.grade-badge').forEach(badge => {
            badge.addEventListener('mouseenter', function() {
                this.style.transform = 'scale(1.1)';
                this.style.transition = 'transform 0.2s ease';
            });
            
            badge.addEventListener('mouseleave', function() {
                this.style.transform = 'scale(1)';
            });
        });

        // Add trophy animation for position card
        const positionCard = document.querySelector('.stat-icon.position');
        if (positionCard) {
            positionCard.addEventListener('mouseenter', function() {
                const trophy = this.querySelector('.fa-trophy');
                if (trophy) {
                    trophy.style.transform = 'rotate(15deg) scale(1.2)';
                    trophy.style.transition = 'transform 0.3s ease';
                }
            });
            
            positionCard.addEventListener('mouseleave', function() {
                const trophy = this.querySelector('.fa-trophy');
                if (trophy) {
                    trophy.style.transform = 'rotate(0) scale(1)';
                }
            });
        }

        // Add sparkle effect for top positions
        const positionNumber = document.querySelector('.position-number');
        if (positionNumber) {
            const positionText = positionNumber.textContent;
            if (positionText.includes('1')) {
                // Add gold sparkle effect
                positionNumber.style.position = 'relative';
                positionNumber.innerHTML = positionNumber.innerHTML + 
                    '<span style="position: absolute; top: -5px; right: -5px; font-size: 12px;">✨</span>';
            }
        }

        // Add hover effect to comparison badges
        document.querySelectorAll('.comparison-badge').forEach(badge => {
            badge.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-2px)';
                this.style.boxShadow = '0 4px 8px rgba(0,0,0,0.1)';
                this.style.transition = 'all 0.2s ease';
            });
            
            badge.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
                this.style.boxShadow = 'none';
            });
        });
    </script>
</body>
</html>