<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../index.php');
    exit();
}

// Get all students with their user info
$students = $pdo->query("
    SELECT s.*, u.username, u.email 
    FROM students s 
    JOIN users u ON s.user_id = u.id 
    ORDER BY s.grade_level, s.first_name
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students | EduFlow Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-dark: #0a192f;
            --primary-blue: #00ccff;
            --white: #ffffff;
            --light-gray: #f8fafc;
            --text-dark: #1e293b;
            --text-light: #64748b;
            --success: #00cc7a;
            --warning: #ff9d00;
            --danger: #ff4757;
            --gradient: linear-gradient(135deg, #00ccff 0%, #0099ff 100%);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--light-gray);
            color: var(--text-dark);
            min-height: 100vh;
        }

        /* Layout Container */
        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: var(--primary-dark);
            color: var(--white);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            transition: all 0.3s ease;
            z-index: 100;
            box-shadow: 2px 0 15px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            padding: 25px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(0, 0, 0, 0.2);
        }

        .sidebar-header h3 {
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            color: var(--white);
        }

        .sidebar-header h3 i {
            color: var(--primary-blue);
            font-size: 1.8rem;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .sidebar-menu ul {
            list-style: none;
        }

        .sidebar-menu li {
            margin: 5px 15px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 14px 15px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s ease;
            font-size: 0.95rem;
        }

        .sidebar-menu a:hover {
            background: rgba(0, 204, 255, 0.15);
            color: var(--white);
            transform: translateX(5px);
        }

        .sidebar-menu a.active {
            background: rgba(0, 204, 255, 0.25);
            color: var(--white);
            border-left: 4px solid var(--primary-blue);
        }

        .sidebar-menu a i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
            font-size: 1.2rem;
        }

        .sidebar-menu a.active i {
            color: var(--primary-blue);
        }

        .sidebar-footer {
            position: absolute;
            bottom: 0;
            width: 100%;
            padding: 15px;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            font-size: 0.85rem;
            color: rgba(255, 255, 255, 0.6);
            background: rgba(0, 0, 0, 0.2);
        }

        .sidebar-footer i {
            color: var(--primary-blue);
            margin-right: 8px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Header */
        .header {
            background: var(--white);
            padding: 20px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            border-bottom: 1px solid #eaeaea;
        }

        .header-title h1 {
            font-size: 1.6rem;
            color: var(--primary-dark);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .header-title h1 i {
            color: var(--primary-blue);
            font-size: 1.8rem;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            padding: 10px 20px;
            border-radius: 30px;
            background: var(--light-gray);
            transition: all 0.3s ease;
            cursor: pointer;
            border: 1px solid #eaeaea;
        }

        .user-profile:hover {
            background: #e6f7ff;
            border-color: var(--primary-blue);
            transform: translateY(-2px);
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 12px;
            border: 2px solid var(--primary-blue);
        }

        .user-profile span {
            font-weight: 600;
            color: var(--primary-dark);
        }

        /* Content Area */
        .content {
            flex: 1;
            padding: 30px;
            background: var(--light-gray);
        }

        /* Stats Cards */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--white);
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: 1px solid #eaeaea;
            animation: fadeInUp 0.5s ease-out;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            border-color: var(--primary-blue);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            background: var(--gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 20px;
            color: var(--white);
            font-size: 1.5rem;
            animation: float 3s ease-in-out infinite;
        }

        .stat-content h3 {
            font-size: 2rem;
            color: var(--primary-dark);
            margin-bottom: 5px;
            font-weight: 700;
        }

        .stat-content p {
            color: var(--text-light);
            font-size: 0.95rem;
        }

        /* Page Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-header h2 {
            font-size: 1.5rem;
            color: var(--primary-dark);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .page-header h2 i {
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-size: 1.8rem;
        }

        .search-box {
            position: relative;
            width: 320px;
        }

        .search-box input {
            width: 100%;
            padding: 14px 20px 14px 50px;
            border-radius: 10px;
            border: 2px solid #ddd;
            font-size: 1rem;
            background: var(--white);
            transition: all 0.3s ease;
            color: var(--text-dark);
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(0, 204, 255, 0.15);
        }

        .search-box i {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
            font-size: 1.2rem;
        }

        .search-box input:focus + i {
            color: var(--primary-blue);
        }

        /* Main Card */
        .main-card {
            background: var(--white);
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            margin-bottom: 30px;
            animation: fadeIn 0.8s ease-out;
        }

        .card-header {
            padding: 25px;
            border-bottom: 1px solid #eaeaea;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: linear-gradient(to right, rgba(0, 204, 255, 0.05), rgba(10, 25, 47, 0.05));
        }

        .card-header h3 {
            font-size: 1.3rem;
            color: var(--primary-dark);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .card-header h3 i {
            color: var(--primary-blue);
            font-size: 1.4rem;
        }

        /* Alerts */
        .alert {
            padding: 18px 25px;
            border-radius: 8px;
            margin: 20px 25px;
            display: flex;
            align-items: center;
            gap: 15px;
            animation: slideInRight 0.5s ease-out;
        }

        .alert-success {
            background: rgba(0, 204, 122, 0.1);
            border-left: 4px solid var(--success);
            color: #006644;
        }

        .alert-danger {
            background: rgba(255, 71, 87, 0.1);
            border-left: 4px solid var(--danger);
            color: #cc3342;
        }

        .alert i {
            font-size: 1.3rem;
        }

        .alert-success i {
            color: var(--success);
        }

        .alert-danger i {
            color: var(--danger);
        }

        /* Buttons */
        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            text-decoration: none;
            font-size: 1rem;
            gap: 10px;
        }

        .btn-primary {
            background: var(--gradient);
            color: var(--white);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0, 204, 255, 0.3);
        }

        .btn-danger {
            background: var(--danger);
            color: var(--white);
        }

        .btn-danger:hover {
            background: #ff3344;
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(255, 71, 87, 0.3);
        }

        .btn-sm {
            padding: 8px 16px;
            font-size: 0.9rem;
        }

        /* Table */
        .table-container {
            overflow-x: auto;
            padding: 0 25px 25px;
        }

        .table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            font-size: 1rem;
            min-width: 1000px;
        }

        .table thead {
            background: linear-gradient(to right, rgba(0, 204, 255, 0.1), rgba(10, 25, 47, 0.1));
        }

        .table th {
            padding: 18px 20px;
            text-align: left;
            font-weight: 600;
            color: var(--primary-dark);
            border-bottom: 2px solid #eaeaea;
            white-space: nowrap;
        }

        .table td {
            padding: 18px 20px;
            border-bottom: 1px solid #eaeaea;
            color: var(--text-dark);
            vertical-align: middle;
        }

        .table tbody tr {
            transition: all 0.3s ease;
        }

        .table tbody tr:hover {
            background: rgba(0, 204, 255, 0.05);
            transform: translateX(5px);
        }

        .student-id {
            background: rgba(0, 204, 255, 0.1);
            color: var(--primary-dark);
            padding: 6px 12px;
            border-radius: 15px;
            font-family: 'Courier New', monospace;
            font-weight: 600;
            font-size: 0.9rem;
            display: inline-block;
            border: 1px solid rgba(0, 204, 255, 0.3);
        }

        .action-buttons {
            display: flex;
            gap: 10px;
            white-space: nowrap;
        }

        .badge {
            display: inline-block;
            padding: 6px 14px;
            border-radius: 15px;
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .badge-primary {
            background: rgba(0, 153, 255, 0.1);
            color: #0066cc;
            border: 1px solid rgba(0, 153, 255, 0.2);
        }

        .badge-success {
            background: rgba(0, 204, 122, 0.1);
            color: var(--success);
            border: 1px solid rgba(0, 204, 122, 0.2);
        }

        .badge-warning {
            background: rgba(255, 157, 0, 0.1);
            color: var(--warning);
            border: 1px solid rgba(255, 157, 0, 0.2);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 80px 20px;
        }

        .empty-state i {
            font-size: 4.5rem;
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 25px;
            display: inline-block;
            animation: pulse 2s infinite;
        }

        .empty-state h3 {
            color: var(--primary-dark);
            margin-bottom: 15px;
            font-size: 1.8rem;
            font-weight: 600;
        }

        .empty-state p {
            color: var(--text-light);
            margin-bottom: 30px;
            max-width: 400px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.6;
            font-size: 1.1rem;
        }

        /* Footer */
        .footer {
            background: var(--primary-dark);
            padding: 25px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.95rem;
        }

        .footer-links {
            display: flex;
            gap: 25px;
        }

        .footer-links a {
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            transition: color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
        }

        .footer-links a:hover {
            color: var(--primary-blue);
            transform: translateY(-2px);
        }

        .footer-links a i {
            font-size: 1.1rem;
        }

        .footer-copyright {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .footer-copyright i {
            color: var(--danger);
            animation: heartbeat 1.5s infinite;
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes float {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-8px);
            }
        }

        @keyframes pulse {
            0%, 100% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
            }
        }

        @keyframes heartbeat {
            0%, 100% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.2);
            }
        }

        /* Table row animation */
        .table tbody tr {
            animation: fadeInUp 0.5s ease-out forwards;
            animation-delay: calc(var(--i) * 0.05s);
            opacity: 0;
        }

        /* Responsive Styles */
        @media (max-width: 1200px) {
            .sidebar {
                width: 80px;
            }
            
            .sidebar-header h3 span,
            .sidebar-menu a span,
            .sidebar-footer span {
                display: none;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .sidebar:hover {
                width: 250px;
            }
            
            .sidebar:hover .sidebar-header h3 span,
            .sidebar:hover .sidebar-menu a span,
            .sidebar:hover .sidebar-footer span {
                display: inline;
            }
        }

        @media (max-width: 992px) {
            .stats-container {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 20px;
            }
            
            .search-box {
                width: 100%;
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 15px;
                padding: 15px 20px;
                text-align: center;
            }
            
            .content {
                padding: 20px;
            }
            
            .stats-container {
                grid-template-columns: 1fr;
                gap: 15px;
            }
            
            .card-header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
            
            .action-buttons {
                flex-direction: column;
                width: 100%;
            }
            
            .action-buttons a {
                width: 100%;
                justify-content: center;
            }
            
            .footer {
                flex-direction: column;
                text-align: center;
                gap: 20px;
                padding: 20px;
            }
            
            .footer-links {
                flex-wrap: wrap;
                justify-content: center;
                gap: 15px;
            }
            
            .table-container {
                padding: 0 15px 15px;
            }
        }

        @media (max-width: 480px) {
            .sidebar {
                width: 0;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .sidebar.active {
                width: 250px;
                z-index: 1000;
            }
            
            .menu-toggle {
                display: block;
                position: fixed;
                top: 20px;
                left: 20px;
                z-index: 1001;
                background: var(--primary-blue);
                color: white;
                border: none;
                padding: 10px;
                border-radius: 5px;
                cursor: pointer;
                font-size: 1.2rem;
            }
            
            .stat-card {
                flex-direction: column;
                text-align: center;
                padding: 20px;
            }
            
            .stat-icon {
                margin-right: 0;
                margin-bottom: 15px;
            }
            
            .header-title h1 {
                font-size: 1.3rem;
            }
        }
    </style>
</head>
<body>
    <!-- Mobile Menu Toggle -->
    <button class="menu-toggle" id="menuToggle" style="display: none;">
        <i class="fas fa-bars"></i>
    </button>

    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h3><i class="fas fa-graduation-cap"></i> <span>EduFlow</span></h3>
            </div>
            
            <div class="sidebar-menu">
                <ul>
                    <li>
                        <a href="../admin/admin_dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'admin_dashboard.php' ? 'active' : ''; ?>">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="manage_students.php" class="active">
                            <i class="fas fa-user-graduate"></i>
                            <span>Students</span>
                        </a>
                    </li>
                    <li>
                        <a href="../teacher/manage_teachers.php">
                            <i class="fas fa-chalkboard-teacher"></i>
                            <span>Teachers</span>
                        </a>
                    </li>
                    <li>
                        <a href="../courses/manage_courses.php">
                            <i class="fas fa-book-open"></i>
                            <span>Courses</span>
                        </a>
                    </li>
                    <li>
                        <a href="../attendance/manage_attendance.php">
                            <i class="fas fa-calendar-check"></i>
                            <span>Attendance</span>
                        </a>
                    </li>
                    <li>
                        <a href="../grades/manage_grades.php">
                            <i class="fas fa-chart-bar"></i>
                            <span>Grades</span>
                        </a>
                    </li>
                </ul>
            </div>
            
            <div class="sidebar-footer">
                <p><i class="fas fa-code"></i> <span>EduFlow v1.0</span></p>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <div class="header-title">
                    <h1><i class="fas fa-user-graduate"></i> Manage Students</h1>
                </div>
                
                <div class="header-actions">
                    <div class="user-profile">
                        <img src="https://ui-avatars.com/api/?name=Admin+User&background=00ccff&color=fff&size=128" alt="Admin">
                        <span>Admin User</span>
                    </div>
                </div>
            </div>

            <!-- Content -->
            <div class="content">
                <!-- Stats Cards -->
                <div class="stats-container">
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo count($students); ?></h3>
                            <p>Total Students</p>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-layer-group"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php 
                                $grade_levels = array_column($students, 'grade_level');
                                $unique_grades = array_unique($grade_levels);
                                echo count($unique_grades);
                            ?></h3>
                            <p>Grade Levels</p>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-user-check"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo count($students); ?></h3>
                            <p>Active Students</p>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-birthday-cake"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php 
                                $today = new DateTime();
                                $birthdays = 0;
                                foreach ($students as $student) {
                                    $birthDate = new DateTime($student['date_of_birth']);
                                    if ($birthDate->format('m-d') == $today->format('m-d')) {
                                        $birthdays++;
                                    }
                                }
                                echo $birthdays;
                            ?></h3>
                            <p>Birthdays Today</p>
                        </div>
                    </div>
                </div>

                <!-- Page Header -->
                <div class="page-header">
                    <h2><i class="fas fa-list-alt"></i> Student Records</h2>
                    
                    <div class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" id="searchInput" placeholder="Search students by name, ID, grade, or email...">
                    </div>
                </div>

                <!-- Main Card -->
                <div class="main-card">
                    <!-- Card Header -->
                    <div class="card-header">
                        <h3><i class="fas fa-table"></i> Student List</h3>
                        <a href="../student/register_student.php" class="btn btn-primary">
                            <i class="fas fa-plus-circle"></i> Add New Student
                        </a>
                    </div>

                    <!-- Alerts -->
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> 
                            <span><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></span>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle"></i> 
                            <span><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></span>
                        </div>
                    <?php endif; ?>

                    <!-- Table -->
                    <?php if (count($students) > 0): ?>
                        <div class="table-container">
                            <table class="table" id="studentsTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Student Name</th>
                                        <th>Student ID</th>
                                        <th>Grade Level</th>
                                        <th>Date of Birth</th>
                                        <th>Parent Contact</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($students as $index => $student): ?>
                                        <tr style="--i: <?php echo $index; ?>">
                                            <td><?php echo $student['id']; ?></td>
                                            <td>
                                                <div style="font-weight: 600; margin-bottom: 4px; color: var(--primary-dark);">
                                                    <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                                                </div>
                                                <div style="font-size: 0.9rem; color: var(--text-light);">
                                                    <i class="fas fa-envelope" style="margin-right: 5px;"></i>
                                                    <?php echo htmlspecialchars($student['email']); ?>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="student-id">
                                                    <i class="fas fa-id-card" style="margin-right: 5px;"></i>
                                                    <?php echo htmlspecialchars($student['username']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge 
                                                    <?php 
                                                        if ($student['grade_level'] <= 5) echo 'badge-primary';
                                                        elseif ($student['grade_level'] <= 8) echo 'badge-warning';
                                                        else echo 'badge-success';
                                                    ?>">
                                                    <i class="fas fa-graduation-cap" style="margin-right: 5px;"></i>
                                                    Grade <?php echo htmlspecialchars($student['grade_level']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div style="font-weight: 500; margin-bottom: 4px;">
                                                    <?php echo date('M d, Y', strtotime($student['date_of_birth'])); ?>
                                                </div>
                                                <div style="font-size: 0.85rem; color: var(--text-light);">
                                                    <i class="fas fa-birthday-cake" style="margin-right: 5px;"></i>
                                                    Age: <?php 
                                                        $birthDate = new DateTime($student['date_of_birth']);
                                                        $today = new DateTime();
                                                        $age = $today->diff($birthDate)->y;
                                                        echo $age;
                                                    ?> years
                                                </div>
                                            </td>
                                            <td>
                                                <div style="font-weight: 500;">
                                                    <?php echo htmlspecialchars($student['parent_contact']); ?>
                                                </div>
                                                <div style="font-size: 0.85rem; color: var(--text-light);">
                                                    <i class="fas fa-phone" style="margin-right: 5px;"></i>
                                                    Emergency Contact
                                                </div>
                                            </td>
                                            <td class="action-buttons">
                                                <a href="edit_student.php?id=<?php echo $student['id']; ?>" class="btn btn-primary btn-sm">
                                                    <i class="fas fa-edit"></i> Edit
                                                </a>
                                                <a href="delete_student.php?id=<?php echo $student['id']; ?>" class="btn btn-danger btn-sm" 
                                                   onclick="return confirm('Are you sure you want to delete <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>? This action cannot be undone.')">
                                                    <i class="fas fa-trash"></i> Delete
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Summary -->
                        <div style="padding: 20px 25px; border-top: 1px solid #eaeaea; color: var(--text-light); font-size: 0.95rem; display: flex; justify-content: space-between; align-items: center; background: rgba(0, 0, 0, 0.02);">
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <i class="fas fa-info-circle" style="color: var(--primary-blue);"></i>
                                Showing <strong style="color: var(--primary-dark);"><?php echo count($students); ?></strong> student<?php echo count($students) != 1 ? 's' : ''; ?> from the database
                            </div>
                            <div style="display: flex; gap: 10px;">
                                <button class="btn btn-primary btn-sm" onclick="exportToCSV()">
                                    <i class="fas fa-file-export"></i> Export CSV
                                </button>
                                <button class="btn btn-primary btn-sm" onclick="printTable()">
                                    <i class="fas fa-print"></i> Print
                                </button>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-user-graduate"></i>
                            <h3>No Students Found</h3>
                            <p>There are currently no students registered in the system. Click the button below to add your first student and begin managing your educational institution.</p>
                            <a href="../student/register_student.php" class="btn btn-primary" style="padding: 14px 30px;">
                                <i class="fas fa-user-plus"></i> Add Your First Student
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Footer -->
            <div class="footer">
                <div class="footer-links">
                    <a href="../admin/dashboard.php"><i class="fas fa-home"></i> Home</a>
                    <a href="#"><i class="fas fa-question-circle"></i> Help Center</a>
                    <a href="#"><i class="fas fa-cog"></i> Settings</a>
                    <a href="../index.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
                
                <div class="footer-copyright">
                    <i class="fas fa-heart"></i>
                    2023 EduFlow Student Management System. All rights reserved.
                </div>
            </div>
        </div>
    </div>

    <script>
        // Search functionality with debounce
        const searchInput = document.getElementById('searchInput');
        let searchTimeout;
        
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                const filter = this.value.toLowerCase();
                const rows = document.querySelectorAll('#studentsTable tbody tr');
                let visibleCount = 0;
                
                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    if (text.includes(filter)) {
                        row.style.display = '';
                        visibleCount++;
                        // Add animation
                        row.classList.add('animate-row');
                        setTimeout(() => {
                            row.classList.remove('animate-row');
                        }, 300);
                    } else {
                        row.style.display = 'none';
                    }
                });
                
                // Update count
                const countElement = document.querySelector('.footer .student-count') || 
                    document.querySelector('.summary-info');
                if (countElement) {
                    countElement.innerHTML = `Showing <strong>${visibleCount}</strong> of ${rows.length} students`;
                }
            }, 300);
        });
        
        // Export to CSV function
        function exportToCSV() {
            const table = document.getElementById("studentsTable");
            const rows = table.querySelectorAll("tr");
            const csv = [];
            
            for (let i = 0; i < rows.length; i++) {
                const row = [], cols = rows[i].querySelectorAll("td, th");
                
                for (let j = 0; j < cols.length; j++) {
                    // Remove icons and extra elements
                    const col = cols[j].cloneNode(true);
                    const icons = col.querySelectorAll('i');
                    icons.forEach(icon => icon.remove());
                    
                    let data = col.textContent.replace(/(\r\n|\n|\r)/gm, "").replace(/(\s\s)/gm, " ");
                    data = data.replace(/"/g, '""');
                    row.push('"' + data + '"');
                }
                
                csv.push(row.join(","));
            }
            
            const csvString = csv.join("\n");
            const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = `students_${new Date().toISOString().slice(0,10)}.csv`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            
            // Show temporary success message
            showNotification('CSV exported successfully!', 'success');
        }
        
        // Print function
        function printTable() {
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <html>
                <head>
                    <title>Print Student List</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 20px; }
                        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
                        th { background-color: #f2f2f2; }
                        .print-header { text-align: center; margin-bottom: 30px; }
                        .print-date { color: #666; margin-top: 10px; }
                    </style>
                </head>
                <body>
                    <div class="print-header">
                        <h1>Student List - EduFlow</h1>
                        <div class="print-date">Generated on ${new Date().toLocaleDateString()}</div>
                    </div>
                    ${document.getElementById('studentsTable').outerHTML}
                </body>
                </html>
            `);
            printWindow.document.close();
            printWindow.print();
        }
        
        // Auto-hide alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    alert.style.transform = 'translateX(30px)';
                    alert.style.transition = 'all 0.5s ease';
                    
                    setTimeout(() => {
                        alert.style.display = 'none';
                    }, 500);
                }, 5000);
            });
            
            // Add custom animation for table rows
            const style = document.createElement('style');
            style.textContent = `
                @keyframes rowHighlight {
                    0% { background-color: rgba(0, 204, 255, 0.1); }
                    100% { background-color: transparent; }
                }
                .animate-row {
                    animation: rowHighlight 0.5s ease;
                }
            `;
            document.head.appendChild(style);
            
            // Mobile menu toggle
            const menuToggle = document.getElementById('menuToggle');
            const sidebar = document.getElementById('sidebar');
            
            if (window.innerWidth <= 480) {
                menuToggle.style.display = 'block';
                menuToggle.addEventListener('click', () => {
                    sidebar.classList.toggle('active');
                });
                
                // Close sidebar when clicking outside
                document.addEventListener('click', (e) => {
                    if (!sidebar.contains(e.target) && !menuToggle.contains(e.target)) {
                        sidebar.classList.remove('active');
                    }
                });
            }
        });
        
        // Show notification function
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'}"></i>
                <span>${message}</span>
            `;
            
            // Add styles for notification
            const style = document.createElement('style');
            style.textContent = `
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 15px 20px;
                    border-radius: 8px;
                    color: white;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    z-index: 10000;
                    animation: slideInRight 0.3s ease-out;
                    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
                }
                .notification-success {
                    background: var(--success);
                }
                .notification i {
                    font-size: 1.2rem;
                }
            `;
            document.head.appendChild(style);
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.opacity = '0';
                notification.style.transform = 'translateX(100%)';
                notification.style.transition = 'all 0.5s ease';
                setTimeout(() => {
                    document.body.removeChild(notification);
                }, 500);
            }, 3000);
        }
        
        // Window resize handler for responsive menu
        window.addEventListener('resize', function() {
            const menuToggle = document.getElementById('menuToggle');
            if (window.innerWidth > 480) {
                menuToggle.style.display = 'none';
                document.getElementById('sidebar').classList.remove('active');
            } else {
                menuToggle.style.display = 'block';
            }
        });
    </script>
</body>
</html>