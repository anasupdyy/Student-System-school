<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../index.php');
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error'] = "Invalid student ID.";
    header('Location: manage_students.php');
    exit();
}

$student_id = (int)$_GET['id'];

// Ka soo qaado user_id
$stmt = $pdo->prepare("SELECT user_id FROM students WHERE id = ?");
$stmt->execute([$student_id]);
$user_id = $stmt->fetchColumn();

if (!$user_id) {
    $_SESSION['error'] = "Student not found.";
    header('Location: manage_students.php');
    exit();
}

try {
    // Dallo ardayga
    $pdo->prepare("DELETE FROM students WHERE id = ?")->execute([$student_id]);
    // Dallo user account
    $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$user_id]);

    $_SESSION['success'] = "✅ Student deleted successfully!";
} catch (Exception $e) {
    $_SESSION['error'] = "❌ Error: " . $e->getMessage();
}

header('Location: manage_students.php');
exit();
?>