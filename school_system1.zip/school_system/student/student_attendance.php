<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student') {
    header('Location: ../index.php');
    exit();
}

$stmt = $pdo->prepare("SELECT s.* FROM students s WHERE s.user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch();

if (!$student) {
    die("Student profile not found.");
}

$attendance_stmt = $pdo->prepare("
    SELECT date, status 
    FROM attendance 
    WHERE student_id = ? 
    ORDER BY date DESC
");
$attendance_stmt->execute([$student['id']]);
$attendance_records = $attendance_stmt->fetchAll();

// Calculate attendance statistics
$total_days = count($attendance_records);
$present_days = count(array_filter($attendance_records, fn($record) => $record['status'] === 'present'));
$absent_days = $total_days - $present_days;
$attendance_percentage = $total_days > 0 ? round(($present_days / $total_days) * 100, 1) : 0;

// Get attendance summary by month
$monthly_attendance = [];
foreach ($attendance_records as $record) {
    $month = date('F Y', strtotime($record['date']));
    if (!isset($monthly_attendance[$month])) {
        $monthly_attendance[$month] = ['present' => 0, 'absent' => 0, 'total' => 0];
    }
    $monthly_attendance[$month]['total']++;
    if ($record['status'] === 'present') {
        $monthly_attendance[$month]['present']++;
    } else {
        $monthly_attendance[$month]['absent']++;
    }
}

$week_map = [
    'Saturday' => 'Sabti',
    'Sunday' => 'Axad',
    'Monday' => 'Isniin',
    'Tuesday' => 'Talaado',
    'Wednesday' => 'Arbaco',
    'Thursday' => 'Jimco'
];

$attendance_by_day = [];
foreach ($attendance_records as $record) {
    $date = $record['date'];
    $day_en = date('l', strtotime($date));
    $day_local = $week_map[$day_en] ?? $day_en;
    $status = in_array($record['status'], ['present', 'absent']) ? $record['status'] : 'absent';
    $attendance_by_day[] = [
        'day_local' => $day_local,
        'date' => $date,
        'status' => $status
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Attendance - Student Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #0a192f;
            --accent: #00ccff;
            --white: #ffffff;
            --light-bg: #f8fafc;
            --gray: #64748b;
            --light-gray: #e2e8f0;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--white);
            color: #1e293b;
            min-height: 100vh;
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary) 0%, #0c2040 100%);
            color: var(--white);
            display: flex;
            flex-direction: column;
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
            z-index: 100;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            text-align: center;
            padding: 0 25px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 30px;
        }

        .sidebar-avatar {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--accent), #0099cc);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            font-weight: 600;
            margin: 0 auto 15px;
            color: var(--white);
            border: 3px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar-header h2 {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.8);
            background: rgba(0, 204, 255, 0.2);
            padding: 4px 12px;
            border-radius: 20px;
            display: inline-block;
        }

        .nav-links {
            list-style: none;
            flex-grow: 1;
            padding: 0 20px;
        }

        .nav-links li {
            margin-bottom: 8px;
        }

        .nav-links a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            padding: 14px 18px;
            border-radius: 10px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-links a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            transform: translateX(5px);
        }

        .nav-links a.active {
            background: var(--accent);
            color: var(--white);
            box-shadow: 0 4px 12px rgba(0, 204, 255, 0.3);
        }

        .nav-links i {
            width: 24px;
            margin-right: 12px;
            font-size: 18px;
        }

        .logout-btn {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            border: none;
            padding: 15px;
            margin: 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateY(-2px);
            border-color: rgba(255, 255, 255, 0.2);
        }

        .logout-btn i {
            margin-right: 10px;
        }

        /* Main Content */
        .main {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
            background-color: #f8fafc;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--light-gray);
        }

        .header h1 {
            color: var(--primary);
            font-size: 28px;
            font-weight: 700;
            display: flex;
            align-items: center;
        }

        .header h1 i {
            color: var(--accent);
            margin-right: 12px;
            font-size: 26px;
        }

        /* Container */
        .container {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 30px;
        }

        /* Attendance Stats */
        .attendance-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--white);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--light-gray);
            text-align: center;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            border-color: var(--accent);
            box-shadow: 0 10px 25px rgba(0, 204, 255, 0.1);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, rgba(0, 204, 255, 0.1), rgba(0, 204, 255, 0.2));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            color: var(--accent);
            font-size: 24px;
        }

        .stat-value {
            font-size: 36px;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 5px;
        }

        .stat-label {
            color: var(--gray);
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .percentage-display {
            font-size: 48px;
            font-weight: 700;
            color: var(--accent);
            margin: 10px 0;
        }

        /* Attendance Progress */
        .attendance-progress {
            margin: 20px 0;
        }

        .progress-bar {
            height: 10px;
            background: var(--light-gray);
            border-radius: 5px;
            overflow: hidden;
            margin-bottom: 10px;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--accent), #0099cc);
            border-radius: 5px;
            transition: width 1s ease;
        }

        .progress-labels {
            display: flex;
            justify-content: space-between;
            color: var(--gray);
            font-size: 14px;
        }

        /* Card */
        .card {
            background: var(--white);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--light-gray);
            transition: all 0.3s ease;
        }

        .card:hover {
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            border-color: var(--accent);
        }

        .card-title {
            color: var(--primary);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .card-title i {
            color: var(--accent);
        }

        /* Attendance Table */
        .attendance-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        .attendance-table thead {
            background: linear-gradient(90deg, var(--primary), #1a365d);
            color: var(--white);
        }

        .attendance-table th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .attendance-table tbody tr {
            border-bottom: 1px solid var(--light-gray);
            transition: all 0.3s ease;
        }

        .attendance-table tbody tr:hover {
            background-color: var(--light-bg);
        }

        .attendance-table td {
            padding: 15px;
            font-size: 14px;
        }

        .attendance-table td:first-child {
            font-weight: 600;
            color: var(--primary);
        }

        .status-present {
            color: var(--success);
            font-weight: 600;
        }

        .status-absent {
            color: var(--danger);
            font-weight: 600;
        }

        .status-emoji {
            font-size: 18px;
            margin-right: 8px;
        }

        .status-text {
            font-weight: 600;
        }

        /* Chart Container */
        .chart-container {
            width: 100px;
            height: 8px;
            background: var(--light-gray);
            border-radius: 4px;
            overflow: hidden;
        }

        .chart-fill.present {
            background: var(--success);
            height: 100%;
            width: 100%;
        }

        .chart-fill.absent {
            background: var(--danger);
            height: 100%;
            width: 100%;
        }

        /* Monthly Summary */
        .monthly-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .month-card {
            background: var(--white);
            border-radius: 12px;
            padding: 20px;
            border: 1px solid var(--light-gray);
            transition: all 0.3s ease;
        }

        .month-card:hover {
            border-color: var(--accent);
            transform: translateY(-3px);
        }

        .month-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .month-name {
            color: var(--primary);
            font-weight: 600;
            font-size: 16px;
        }

        .month-stats {
            display: flex;
            gap: 15px;
        }

        .month-stat {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .month-value {
            font-weight: 700;
            font-size: 20px;
        }

        .month-value.present {
            color: var(--success);
        }

        .month-value.absent {
            color: var(--danger);
        }

        .month-label {
            font-size: 12px;
            color: var(--gray);
            text-transform: uppercase;
        }

        /* No Data Message */
        .no-data {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray);
        }

        .no-data i {
            font-size: 64px;
            color: var(--accent);
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .no-data p {
            font-size: 18px;
            margin-bottom: 10px;
        }

        /* Footer */
        footer {
            text-align: center;
            padding: 20px;
            color: var(--gray);
            font-size: 14px;
            border-top: 1px solid var(--light-gray);
            margin-top: 40px;
            background: var(--white);
            border-radius: 10px;
        }

        footer i {
            color: var(--accent);
            margin-right: 8px;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 80px;
            }
            
            .main {
                margin-left: 80px;
            }
            
            .sidebar-header h2,
            .sidebar-header p,
            .nav-links span,
            .logout-btn span {
                display: none;
            }
            
            .nav-links a {
                justify-content: center;
                padding: 16px;
            }
            
            .nav-links i {
                margin-right: 0;
                font-size: 20px;
            }
            
            .sidebar-avatar {
                width: 50px;
                height: 50px;
                font-size: 22px;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                flex-direction: row;
                padding: 15px;
            }
            
            .main {
                margin-left: 0;
                padding: 20px;
            }
            
            .sidebar-header {
                display: flex;
                align-items: center;
                padding: 0;
                border-bottom: none;
                margin-bottom: 0;
                margin-right: 15px;
            }
            
            .sidebar-avatar {
                width: 40px;
                height: 40px;
                margin: 0 10px 0 0;
            }
            
            .nav-links {
                display: flex;
                padding: 0;
                flex-grow: 0;
            }
            
            .nav-links li {
                margin-bottom: 0;
                margin-right: 5px;
            }
            
            .logout-btn {
                margin: 0 0 0 auto;
                padding: 10px;
            }
            
            .attendance-stats {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .attendance-table {
                display: block;
                overflow-x: auto;
            }
            
            .attendance-table th,
            .attendance-table td {
                min-width: 120px;
            }
        }

        @media (max-width: 480px) {
            .main {
                padding: 15px;
            }
            
            .attendance-stats {
                grid-template-columns: 1fr;
            }
            
            .card {
                padding: 20px;
            }
            
            .monthly-summary {
                grid-template-columns: 1fr;
            }
            
            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            animation: fadeIn 0.6s ease forwards;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-avatar"><?= strtoupper(substr($student['first_name'][0] ?? 'A', 0, 1)) ?></div>
            <h2><?= htmlspecialchars($student['first_name']) ?></h2>
            <p>Grade <?= htmlspecialchars($student['grade_level'] ?? 'N/A') ?></p>
        </div>
        <ul class="nav-links">
            <li><a href="student_dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
            <li><a href="exam_view.php"><i class="fas fa-file-alt"></i> <span>My Exams</span></a></li>
            <li><a href="student_attendance.php" class="active"><i class="fas fa-calendar-check"></i> <span>Attendance</span></a></li>
            <li><a href="profile.php"><i class="fas fa-user-cog"></i> <span>Profile</span></a></li>
        </ul>
        <button class="logout-btn" onclick="window.location='../index.php'">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </button>
    </div>

    <!-- Main Content -->
    <div class="main">
        <div class="header">
            <h1><i class="fas fa-clipboard-check"></i> My Attendance Records</h1>
        </div>

        <div class="container">
            <!-- Attendance Statistics -->
            <div class="attendance-stats fade-in">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="stat-value"><?= $total_days ?></div>
                    <div class="stat-label">Total Days</div>
                </div>
                
                <div class="stat-card" style="animation-delay: 0.1s">
                    <div class="stat-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-value"><?= $present_days ?></div>
                    <div class="stat-label">Present</div>
                </div>
                
                <div class="stat-card" style="animation-delay: 0.2s">
                    <div class="stat-icon">
                        <i class="fas fa-times-circle"></i>
                    </div>
                    <div class="stat-value"><?= $absent_days ?></div>
                    <div class="stat-label">Absent</div>
                </div>
                
                <div class="stat-card" style="animation-delay: 0.3s">
                    <div class="stat-icon">
                        <i class="fas fa-percentage"></i>
                    </div>
                    <div class="percentage-display"><?= $attendance_percentage ?>%</div>
                    <div class="stat-label">Attendance Rate</div>
                </div>
            </div>

            <!-- Attendance Progress -->
            <div class="card fade-in" style="animation-delay: 0.2s">
                <div class="card-title">
                    <i class="fas fa-chart-line"></i> Overall Attendance
                </div>
                <div class="attendance-progress">
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?= $attendance_percentage ?>%;"></div>
                    </div>
                    <div class="progress-labels">
                        <span>0%</span>
                        <span><?= $attendance_percentage ?>%</span>
                        <span>100%</span>
                    </div>
                </div>
                <div style="text-align: center; margin-top: 15px; color: var(--gray);">
                    Present: <?= $present_days ?> | Absent: <?= $absent_days ?> | Total: <?= $total_days ?>
                </div>
            </div>

            <!-- Monthly Attendance Summary -->
            <?php if (!empty($monthly_attendance)): ?>
            <div class="card fade-in" style="animation-delay: 0.3s">
                <div class="card-title">
                    <i class="fas fa-calendar-month"></i> Monthly Summary
                </div>
                <div class="monthly-summary">
                    <?php 
                    $counter = 0;
                    foreach ($monthly_attendance as $month => $data): 
                        $month_percentage = $data['total'] > 0 ? round(($data['present'] / $data['total']) * 100, 1) : 0;
                    ?>
                    <div class="month-card" style="animation-delay: <?= $counter * 0.1 ?>s">
                        <div class="month-header">
                            <div class="month-name"><?= $month ?></div>
                            <div class="month-percentage" style="color: var(--accent); font-weight: 600;">
                                <?= $month_percentage ?>%
                            </div>
                        </div>
                        <div class="month-stats">
                            <div class="month-stat">
                                <div class="month-value present"><?= $data['present'] ?></div>
                                <div class="month-label">Present</div>
                            </div>
                            <div class="month-stat">
                                <div class="month-value absent"><?= $data['absent'] ?></div>
                                <div class="month-label">Absent</div>
                            </div>
                            <div class="month-stat">
                                <div class="month-value" style="color: var(--primary);"><?= $data['total'] ?></div>
                                <div class="month-label">Total</div>
                            </div>
                        </div>
                    </div>
                    <?php 
                        $counter++;
                    endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Detailed Attendance Table -->
            <div class="card fade-in" style="animation-delay: 0.4s">
                <div class="card-title">
                    <i class="fas fa-calendar-week"></i> Attendance by Day
                </div>

                <?php if (!empty($attendance_by_day)): ?>
                    <table class="attendance-table">
                        <thead>
                            <tr>
                                <th>Maalmaha</th>
                                <th>Taariikh</th>
                                <th>Xaalad</th>
                                <th>Charts</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($attendance_by_day as $rec): ?>
                                <tr>
                                    <td><?= htmlspecialchars($rec['day_local']) ?></td>
                                    <td><?= date('d/M/Y', strtotime($rec['date'])) ?></td>
                                    <td>
                                        <?php if ($rec['status'] === 'present'): ?>
                                            <span class="status-emoji">✅</span>
                                            <span class="status-text status-present">Present</span>
                                        <?php else: ?>
                                            <span class="status-emoji">❌</span>
                                            <span class="status-text status-absent">Absent</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="chart-container">
                                            <div class="chart-fill <?= $rec['status'] ?>"></div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="no-data">
                        <i class="fas fa-clipboard-list"></i>
                        <p>No attendance records found.</p>
                        <p style="font-size: 14px;">Check back later for updates.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Footer -->
        <footer>
            <p>
                <i class="fas fa-school"></i>
                School Management System • Student Portal • <?= date('Y') ?>
            </p>
        </footer>
    </div>

    <script>
        // Animate progress bars on load
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(() => {
                const progressFill = document.querySelector('.progress-fill');
                if (progressFill) {
                    const width = progressFill.style.width;
                    progressFill.style.width = '0%';
                    setTimeout(() => {
                        progressFill.style.width = width;
                    }, 100);
                }
                
                // Add hover effects to cards
                document.querySelectorAll('.stat-card, .month-card').forEach(card => {
                    card.addEventListener('mouseenter', () => {
                        card.style.transform = 'translateY(-5px)';
                    });
                    card.addEventListener('mouseleave', () => {
                        card.style.transform = 'translateY(0)';
                    });
                });
                
                // Add fade-in animations
                const elements = document.querySelectorAll('.fade-in');
                elements.forEach((el, index) => {
                    el.style.opacity = '0';
                    setTimeout(() => {
                        el.style.animation = `fadeIn 0.6s ease ${index * 0.1}s forwards`;
                    }, 100);
                });
            }, 300);
        });
    </script>

</body>
</html>