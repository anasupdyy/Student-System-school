<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../index.php');
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: manage_students.php');
    exit();
}

$student_id = (int)$_GET['id'];

// Ka soo qaado ardayka
$stmt = $pdo->prepare("
    SELECT s.*, u.username, u.email 
    FROM students s 
    JOIN users u ON s.user_id = u.id 
    WHERE s.id = ?
");
$stmt->execute([$student_id]);
$student = $stmt->fetch();

if (!$student) {
    $_SESSION['error'] = "Student not found.";
    header('Location: manage_students.php');
    exit();
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $grade_level = trim($_POST['grade_level']);
    $dob = $_POST['date_of_birth'];
    $parent_contact = trim($_POST['parent_contact']);
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);

    if (empty($first_name) || empty($last_name) || empty($grade_level) || empty($username) || empty($email)) {
        $message = "All fields are required.";
    } else {
        try {
            // Update user
            $pdo->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?")
                ->execute([$username, $email, $student['user_id']]);

            // Update student
            $pdo->prepare("UPDATE students SET first_name = ?, last_name = ?, grade_level = ?, date_of_birth = ?, parent_contact = ? WHERE id = ?")
                ->execute([$first_name, $last_name, $grade_level, $dob, $parent_contact, $student_id]);

            $_SESSION['success'] = "Student updated successfully!";
            header('Location: manage_students.php');
            exit();
        } catch (Exception $e) {
            $message = "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student </title>
     <link rel="stylesheet" href="style_student.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
     <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1><i class="fas fa-user-edit"></i> Edit Student</h1>

        <?php if ($message): ?>
            <div class="message error"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>First Name</label>
                <input type="text" name="first_name" value="<?= htmlspecialchars($student['first_name']) ?>" required>
            </div>
            <div class="form-group">
                <label>Last Name</label>
                <input type="text" name="last_name" value="<?= htmlspecialchars($student['last_name']) ?>" required>
            </div>
            <div class="form-group">
                <label>Grade Level</label>
                <input type="text" name="grade_level" value="<?= htmlspecialchars($student['grade_level']) ?>" required>
            </div>
            <div class="form-group">
                <label>Date of Birth</label>
                <input type="date" name="date_of_birth" value="<?= $student['date_of_birth'] ?>" required>
            </div>
            <div class="form-group">
                <label>Parent Contact</label>
                <input type="text" name="parent_contact" value="<?= htmlspecialchars($student['parent_contact']) ?>" required>
            </div>
            <div class="form-group">
                <label>Student ID (Username)</label>
                <input type="text" name="username" value="<?= htmlspecialchars($student['username']) ?>" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" value="<?= htmlspecialchars($student['email']) ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update Student</button>
            <a href="manage_students.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>