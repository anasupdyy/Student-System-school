<?php
session_start();
require_once '../db.php';

// SESSION VALIDATION SAX AH
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header('Location: ../index.php');
    exit();
}

// Check if user is student
if ($_SESSION['role'] != 'student') {
    // Redirect based on role
    switch($_SESSION['role']) {
        case 'teacher':
            header('Location: ../teacher/teacher_dashboard.php');
            break;
        case 'admin':
            header('Location: ../admin/admin_dashboard.php');
            break;
        default:
            header('Location: ../index.php');
    }
    exit();
}

// Verify session user exists in database
$check_session = $pdo->prepare("SELECT id, username, role FROM users WHERE id = ? AND role = 'student'");
$check_session->execute([$_SESSION['user_id']]);
$session_user = $check_session->fetch();

if (!$session_user) {
    // Destroy invalid session
    session_destroy();
    header('Location: ../index.php?error=invalid_session');
    exit();
}

// Ka soo qaado ardayga with prepared statement
$stmt = $pdo->prepare("
    SELECT s.*, u.username, u.email, u.created_at as account_created 
    FROM students s 
    JOIN users u ON s.user_id = u.id 
    WHERE s.user_id = ? AND u.role = 'student'
");
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch();

if (!$student) {
    // If student record not found but user exists in users table
    $error_msg = "Student profile not found. Please contact administrator.";
    // Optionally log out
    // session_destroy();
    // header('Location: ../index.php?error=profile_not_found');
    // exit();
}

// Calculate age safely
$age = 'N/A';
if (!empty($student['date_of_birth'])) {
    try {
        $birthDate = new DateTime($student['date_of_birth']);
        $today = new DateTime();
        $age = $today->diff($birthDate)->y;
    } catch (Exception $e) {
        $age = 'N/A';
    }
}

// Ka soo qaado attendance-ka (only if student exists)
$attendance = null;
if ($student) {
    $attendance_stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_days,
            SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present_days,
            SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent_days,
            SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late_days
        FROM attendance 
        WHERE student_id = ?
    ");
    $attendance_stmt->execute([$student['id']]);
    $attendance = $attendance_stmt->fetch();
}

// Ka soo qaado exams-ka ugu dambeeyay (only if student exists)
$recent_exams = [];
if ($student) {
    $exams_stmt = $pdo->prepare("
        SELECT e.*, er.marks_obtained 
        FROM exams e 
        LEFT JOIN exam_results er ON e.id = er.exam_id AND er.student_id = ?
        WHERE e.target_class = ?
        ORDER BY e.exam_date DESC 
        LIMIT 5
    ");
    $exams_stmt->execute([$student['id'], $student['grade_level']]);
    $recent_exams = $exams_stmt->fetchAll();
}

// Check for session messages
$message = '';
$message_type = '';
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    $message_type = $_SESSION['message_type'] ?? 'info';
    unset($_SESSION['message']);
    unset($_SESSION['message_type']);
}

// Check for GET parameters (for alerts)
if (isset($_GET['success'])) {
    $message = htmlspecialchars($_GET['success']);
    $message_type = 'success';
} elseif (isset($_GET['error'])) {
    $message = htmlspecialchars($_GET['error']);
    $message_type = 'error';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #0a192f;
            --accent: #00ccff;
            --white: #ffffff;
            --light-bg: #f0f8ff;
            --gray: #64748b;
            --light-gray: #e2e8f0;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #3b82f6;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--white);
            color: #1e293b;
            min-height: 100vh;
            display: flex;
        }

        /* Session Status Bar */
        .session-status {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: linear-gradient(90deg, var(--primary), #1a365d);
            color: white;
            padding: 8px 20px;
            font-size: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .session-info {
            display: flex;
            gap: 15px;
        }

        .session-item {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .session-item i {
            font-size: 12px;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary) 0%, #0c2040 100%);
            color: var(--white);
            display: flex;
            flex-direction: column;
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 30px; /* Adjusted for session bar */
            z-index: 100;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            text-align: center;
            padding: 0 25px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 30px;
        }

        .profile-avatar {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--accent), #0099cc);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            font-weight: 600;
            margin: 0 auto 15px;
            color: var(--white);
            border: 3px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 5px 15px rgba(0, 204, 255, 0.3);
        }

        .profile-name {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .profile-grade {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.8);
            background: rgba(0, 204, 255, 0.2);
            padding: 4px 12px;
            border-radius: 20px;
            display: inline-block;
        }

        .nav-links {
            list-style: none;
            flex-grow: 1;
            padding: 0 20px;
        }

        .nav-links li {
            margin-bottom: 8px;
        }

        .nav-links a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            padding: 14px 18px;
            border-radius: 10px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-links a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            transform: translateX(5px);
        }

        .nav-links a.active {
            background: var(--accent);
            color: var(--white);
            box-shadow: 0 4px 12px rgba(0, 204, 255, 0.3);
        }

        .nav-links i {
            width: 24px;
            margin-right: 12px;
            font-size: 18px;
        }

        .logout-btn {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            border: none;
            padding: 15px;
            margin: 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateY(-2px);
            border-color: rgba(255, 255, 255, 0.2);
        }

        .logout-btn i {
            margin-right: 10px;
        }

        /* Session Timeout Warning */
        .session-warning {
            display: none;
            position: fixed;
            top: 40px;
            right: 20px;
            background: var(--warning);
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            z-index: 1001;
            box-shadow: 0 3px 15px rgba(245, 158, 11, 0.3);
            animation: pulseWarning 2s infinite;
        }

        @keyframes pulseWarning {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        /* Message Alerts */
        .alert-message {
            position: fixed;
            top: 40px;
            left: 50%;
            transform: translateX(-50%);
            padding: 15px 25px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            gap: 12px;
            z-index: 1001;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
            animation: slideDown 0.5s ease;
        }

        @keyframes slideDown {
            from { top: -100px; opacity: 0; }
            to { top: 40px; opacity: 1; }
        }

        .alert-message.success {
            background: var(--success);
            color: white;
            border-left: 4px solid #0a8;
        }

        .alert-message.error {
            background: var(--danger);
            color: white;
            border-left: 4px solid #c00;
        }

        .alert-message.info {
            background: var(--info);
            color: white;
            border-left: 4px solid #06c;
        }

        .alert-message.warning {
            background: var(--warning);
            color: white;
            border-left: 4px solid #d80;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 40px 30px 30px; /* More top padding for session bar */
            background-color: #f8fafc;
            min-height: 100vh;
        }

        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--light-gray);
        }

        .page-title h1 {
            color: var(--primary);
            font-size: 28px;
            font-weight: 700;
            display: flex;
            align-items: center;
        }

        .page-title h1 i {
            color: var(--accent);
            margin-right: 12px;
            font-size: 26px;
        }

        .date-display {
            background: var(--white);
            padding: 10px 20px;
            border-radius: 10px;
            color: var(--gray);
            font-weight: 500;
            border: 1px solid var(--light-gray);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        /* Welcome Banner */
        .welcome-banner {
            background: linear-gradient(135deg, var(--primary), #1a365d);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            color: var(--white);
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 25px rgba(10, 25, 47, 0.2);
        }

        .welcome-banner::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 200px;
            height: 200px;
            background: radial-gradient(circle, rgba(0, 204, 255, 0.2) 0%, transparent 70%);
        }

        .welcome-banner h2 {
            font-size: 28px;
            margin-bottom: 10px;
            position: relative;
            z-index: 1;
        }

        .welcome-banner p {
            color: rgba(255, 255, 255, 0.9);
            font-size: 16px;
            position: relative;
            z-index: 1;
        }

        /* Dashboard Grid */
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        /* Info Cards */
        .info-card {
            background: var(--white);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--light-gray);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .info-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            border-color: var(--accent);
        }

        .info-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
            background: var(--accent);
        }

        .card-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .card-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, rgba(0, 204, 255, 0.1), rgba(0, 204, 255, 0.2));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--accent);
            font-size: 22px;
            margin-right: 15px;
        }

        .card-title {
            color: var(--primary);
            font-size: 18px;
            font-weight: 600;
        }

        .card-content {
            padding-left: 65px;
        }

        .info-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 12px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--light-gray);
        }

        .info-item:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }

        .info-label {
            color: var(--gray);
            font-weight: 500;
        }

        .info-value {
            color: var(--primary);
            font-weight: 600;
            font-size: 16px;
        }

        /* Student ID Card */
        .id-card {
            background: linear-gradient(135deg, var(--primary), #1a365d);
            border-radius: 15px;
            padding: 25px;
            color: var(--white);
            text-align: center;
            border: 2px solid var(--accent);
            box-shadow: 0 10px 25px rgba(10, 25, 47, 0.2);
        }

        .id-card h3 {
            color: var(--accent);
            margin-bottom: 20px;
            font-size: 18px;
            font-weight: 600;
        }

        .id-number {
            font-size: 32px;
            font-weight: 700;
            letter-spacing: 2px;
            margin: 15px 0;
            text-shadow: 0 2px 10px rgba(0, 204, 255, 0.3);
        }

        .id-validity {
            color: rgba(255, 255, 255, 0.8);
            font-size: 14px;
            margin-top: 20px;
        }

        /* Attendance & Exams */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .stats-card {
            background: var(--white);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--light-gray);
        }

        .stats-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .stats-title {
            color: var(--primary);
            font-size: 18px;
            font-weight: 600;
        }

        .attendance-percentage {
            font-size: 36px;
            font-weight: 700;
            color: var(--primary);
            margin: 20px 0;
            text-align: center;
        }

        .attendance-bar {
            height: 8px;
            background: var(--light-gray);
            border-radius: 4px;
            margin: 20px 0;
            overflow: hidden;
        }

        .attendance-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--accent), #0099cc);
            border-radius: 4px;
            transition: width 1s ease;
        }

        .attendance-details {
            display: flex;
            justify-content: space-between;
            color: var(--gray);
            font-size: 14px;
        }

        /* Exams List */
        .exams-list {
            list-style: none;
        }

        .exam-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid var(--light-gray);
            transition: all 0.3s ease;
        }

        .exam-item:hover {
            background: var(--light-bg);
            border-radius: 10px;
        }

        .exam-item:last-child {
            border-bottom: none;
        }

        .exam-info h4 {
            color: var(--primary);
            margin-bottom: 5px;
        }

        .exam-date {
            color: var(--gray);
            font-size: 14px;
        }

        .exam-score {
            background: rgba(0, 204, 255, 0.1);
            color: var(--accent);
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 14px;
        }

        /* Quick Actions */
        .quick-actions {
            background: var(--white);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
            border: 1px solid var(--light-gray);
        }

        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .action-btn {
            background: var(--light-bg);
            border: 2px solid var(--light-gray);
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            color: var(--primary);
            font-weight: 500;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .action-btn:hover {
            background: var(--accent);
            color: var(--white);
            border-color: var(--accent);
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 204, 255, 0.2);
        }

        .action-btn i {
            font-size: 24px;
            margin-bottom: 10px;
            color: var(--accent);
        }

        .action-btn:hover i {
            color: var(--white);
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 20px;
            color: var(--gray);
            font-size: 14px;
            border-top: 1px solid var(--light-gray);
            margin-top: 30px;
        }

        .footer i {
            color: var(--accent);
            margin-right: 8px;
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            animation: fadeIn 0.6s ease forwards;
        }

        /* Session Timeout Modal */
        .session-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }

        .session-modal-content {
            background: white;
            padding: 30px;
            border-radius: 15px;
            text-align: center;
            max-width: 400px;
            animation: modalIn 0.3s ease;
        }

        @keyframes modalIn {
            from { transform: scale(0.8); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 80px;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .sidebar-header h2,
            .sidebar-header p,
            .nav-links span,
            .logout-btn span {
                display: none;
            }
            
            .nav-links a {
                justify-content: center;
                padding: 16px;
            }
            
            .nav-links i {
                margin-right: 0;
                font-size: 20px;
            }
            
            .profile-avatar {
                width: 50px;
                height: 50px;
                font-size: 22px;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                flex-direction: row;
                padding: 15px;
            }
            
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
            
            .sidebar-header {
                display: flex;
                align-items: center;
                padding: 0;
                border-bottom: none;
                margin-bottom: 0;
                margin-right: 15px;
            }
            
            .profile-avatar {
                width: 40px;
                height: 40px;
                margin: 0 10px 0 0;
            }
            
            .nav-links {
                display: flex;
                padding: 0;
                flex-grow: 0;
            }
            
            .nav-links li {
                margin-bottom: 0;
                margin-right: 5px;
            }
            
            .logout-btn {
                margin: 0 0 0 auto;
                padding: 10px;
            }
            
            .dashboard-grid,
            .stats-container {
                grid-template-columns: 1fr;
            }
            
            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }

        @media (max-width: 480px) {
            .main-content {
                padding: 15px;
            }
            
            .welcome-banner h2 {
                font-size: 22px;
            }
            
            .page-title h1 {
                font-size: 24px;
            }
            
            .info-card,
            .stats-card,
            .quick-actions {
                padding: 20px;
            }
            
            .id-number {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <!-- Session Status Bar -->
    <div class="session-status">
        <div class="session-info">
            <div class="session-item">
                <i class="fas fa-user"></i>
                <span>Logged in as: <strong><?= htmlspecialchars($session_user['username'] ?? 'Student') ?></strong></span>
            </div>
            <div class="session-item">
                <i class="fas fa-shield-alt"></i>
                <span>Role: <strong>Student</strong></span>
            </div>
            <div class="session-item">
                <i class="fas fa-clock"></i>
                <span id="sessionTimer">Session: Active</span>
            </div>
        </div>
        <div class="session-item">
            <i class="fas fa-lock"></i>
            <span>Secure Session</span>
        </div>
    </div>

    <!-- Session Warning Modal -->
    <div class="session-modal" id="sessionModal">
        <div class="session-modal-content">
            <h3><i class="fas fa-exclamation-triangle" style="color: var(--warning);"></i> Session Expiring</h3>
            <p style="margin: 15px 0;">Your session will expire in <span id="countdown">60</span> seconds.</p>
            <p style="color: var(--gray); font-size: 14px;">Click "Extend Session" to stay logged in.</p>
            <div style="margin-top: 20px; display: flex; gap: 10px; justify-content: center;">
                <button onclick="extendSession()" style="padding: 10px 20px; background: var(--success); color: white; border: none; border-radius: 5px; cursor: pointer;">
                    <i class="fas fa-sync-alt"></i> Extend Session
                </button>
                <button onclick="logout()" style="padding: 10px 20px; background: var(--danger); color: white; border: none; border-radius: 5px; cursor: pointer;">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </button>
            </div>
        </div>
    </div>

    <!-- Session Warning -->
    <div class="session-warning" id="sessionWarning">
        <i class="fas fa-exclamation-triangle"></i>
        <span>Your session will expire soon!</span>
    </div>

    <!-- Alert Message -->
    <?php if ($message): ?>
    <div class="alert-message <?= $message_type ?>" id="alertMessage">
        <i class="fas fa-<?= 
            $message_type === 'success' ? 'check-circle' : 
            ($message_type === 'error' ? 'exclamation-circle' : 
            ($message_type === 'warning' ? 'exclamation-triangle' : 'info-circle')) 
        ?>"></i>
        <?= $message ?>
    </div>
    <?php endif; ?>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="profile-avatar">
                <?= $student ? strtoupper(substr($student['first_name'][0] ?? 'S', 0, 1)) : 'S' ?>
            </div>
            <div>
                <div class="profile-name"><?= $student ? htmlspecialchars($student['first_name']) : 'Student' ?></div>
                <div class="profile-grade"><?= $student ? 'Grade ' . htmlspecialchars($student['grade_level'] ?? 'N/A') : 'Student' ?></div>
            </div>
        </div>
        
        <ul class="nav-links">
            <li><a href="student_dashboard.php" class="active"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
            <li><a href="exam_view.php"><i class="fas fa-file-alt"></i> <span>My Exams</span></a></li>
            <li><a href="student_attendance.php"><i class="fas fa-calendar-check"></i> <span>Attendance</span></a></li>
            <li><a href="student_profile.php"><i class="fas fa-user-cog"></i> <span>Profile</span></a></li>
            <li><a href="change_password.php"><i class="fas fa-key"></i> <span>Change Password</span></a></li>
        </ul>
        
        <button class="logout-btn" onclick="window.location='../index.php'">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </button>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="page-title">
                <h1><i class="fas fa-graduation-cap"></i> Student Dashboard</h1>
            </div>
            <div class="date-display">
                <i class="fas fa-calendar"></i> <?= date('l, F j, Y') ?>
                <span style="margin-left: 10px; color: var(--accent;">|</span>
                <span style="margin-left: 10px;" id="currentTime"><?= date('h:i A') ?></span>
            </div>
        </div>

        <!-- Welcome Banner -->
        <div class="welcome-banner fade-in">
            <h2>Welcome back, <?= $student ? htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) : 'Student' ?>! 👋</h2>
            <p><?= $student ? 'Here\'s your academic summary and important information' : 'Please complete your profile setup' ?></p>
        </div>

        <!-- Error Message if no student profile -->
        <?php if (!$student): ?>
        <div class="alert-message error" style="position: relative; margin-bottom: 20px;">
            <i class="fas fa-exclamation-circle"></i>
            <strong>Profile Incomplete!</strong> Your student profile is not found. Please contact your administrator.
        </div>
        <?php endif; ?>

        <?php if ($student): ?>
        <!-- Dashboard Grid -->
        <div class="dashboard-grid">
            <!-- Personal Information -->
            <div class="info-card fade-in">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="card-title">Personal Information</div>
                </div>
                <div class="card-content">
                    <div class="info-item">
                        <span class="info-label">Full Name</span>
                        <span class="info-value"><?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Email</span>
                        <span class="info-value"><?= htmlspecialchars($student['email'] ?? 'N/A') ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Username</span>
                        <span class="info-value"><?= htmlspecialchars($student['username'] ?? 'N/A') ?></span>
                    </div>
                </div>
            </div>

            <!-- Parent & Contact Info -->
            <div class="info-card fade-in" style="animation-delay: 0.1s">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="card-title">Parent & Contact</div>
                </div>
                <div class="card-content">
                    <div class="info-item">
                        <span class="info-label">Parent Name</span>
                        <span class="info-value"><?= !empty($student['parent_name']) ? htmlspecialchars($student['parent_name']) : 'Not specified' ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Parent Phone</span>
                        <span class="info-value"><?= !empty($student['parent_phone']) ? htmlspecialchars($student['parent_phone']) : 'N/A' ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Age</span>
                        <span class="info-value"><?= $age ?> years</span>
                    </div>
                </div>
            </div>

            <!-- Academic Information -->
            <div class="info-card fade-in" style="animation-delay: 0.2s">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-school"></i>
                    </div>
                    <div class="card-title">Academic Information</div>
                </div>
                <div class="card-content">
                    <div class="info-item">
                        <span class="info-label">Class</span>
                        <span class="info-value">Grade <?= htmlspecialchars($student['grade_level'] ?? 'N/A') ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Section</span>
                        <span class="info-value"><?= !empty($student['section']) ? htmlspecialchars($student['section']) : 'Not assigned' ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Roll Number</span>
                        <span class="info-value"><?= !empty($student['roll_number']) ? htmlspecialchars($student['roll_number']) : 'N/A' ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Section -->
        <div class="stats-container">
            <!-- Student ID Card -->
            <div class="id-card fade-in">
                <div class="card-icon" style="margin: 0 auto 15px; background: rgba(255, 255, 255, 0.2);">
                    <i class="fas fa-id-card"></i>
                </div>
                <h3>STUDENT ID</h3>
                <div class="id-number">
                    <?= !empty($student['student_code']) ? htmlspecialchars($student['student_code']) : 
                          (!empty($student['id']) ? 'STU-' . str_pad($student['id'], 6, '0', STR_PAD_LEFT) : 'N/A') ?>
                </div>
                <div class="id-validity">
                    Account created: <?= !empty($student['account_created']) ? date('M d, Y', strtotime($student['account_created'])) : date('M d, Y') ?>
                </div>
            </div>

            <!-- Attendance Stats -->
            <div class="stats-card fade-in" style="animation-delay: 0.1s">
                <div class="stats-header">
                    <div class="stats-title">Attendance Summary</div>
                    <div class="card-icon" style="margin: 0;">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                </div>
                
                <?php if ($attendance && $attendance['total_days'] > 0): 
                    $attendance_rate = ($attendance['present_days'] / $attendance['total_days']) * 100;
                ?>
                <div class="attendance-percentage"><?= round($attendance_rate, 1) ?>%</div>
                
                <div class="attendance-bar">
                    <div class="attendance-fill" style="width: <?= $attendance_rate ?>%"></div>
                </div>
                
                <div class="attendance-details">
                    <div>
                        <i class="fas fa-check-circle" style="color: var(--success);"></i>
                        <span>Present: <?= $attendance['present_days'] ?? 0 ?></span>
                    </div>
                    <div>
                        <i class="fas fa-times-circle" style="color: var(--danger);"></i>
                        <span>Absent: <?= ($attendance['total_days'] ?? 0) - ($attendance['present_days'] ?? 0) ?></span>
                    </div>
                    <div>
                        <i class="fas fa-calendar" style="color: var(--gray);"></i>
                        <span>Total: <?= $attendance['total_days'] ?? 0 ?></span>
                    </div>
                </div>
                <?php else: ?>
                <div class="attendance-percentage">N/A</div>
                <p style="text-align: center; color: var(--gray);">No attendance records found</p>
                <?php endif; ?>
            </div>

            <!-- Recent Exams -->
            <div class="stats-card fade-in" style="animation-delay: 0.2s">
                <div class="stats-header">
                    <div class="stats-title">Recent Exams</div>
                    <div class="card-icon" style="margin: 0;">
                        <i class="fas fa-clipboard-list"></i>
                    </div>
                </div>
                
                <?php if (!empty($recent_exams)): ?>
                <ul class="exams-list">
                    <?php foreach ($recent_exams as $exam): ?>
                    <li class="exam-item">
                        <div class="exam-info">
                            <h4><?= htmlspecialchars($exam['exam_name']) ?></h4>
                            <div class="exam-date">
                                <?= date('M d, Y', strtotime($exam['exam_date'])) ?>
                                <?php if (!empty($exam['subject'])): ?>
                                <br><small style="color: var(--accent);"><?= htmlspecialchars($exam['subject']) ?></small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if ($exam['marks_obtained'] !== null): 
                            $percentage = $exam['total_marks'] > 0 ? ($exam['marks_obtained'] / $exam['total_marks']) * 100 : 0;
                            $score_color = $percentage >= 80 ? 'var(--success)' : ($percentage >= 50 ? 'var(--warning)' : 'var(--danger)');
                        ?>
                        <div class="exam-score" style="background: rgba(0, 204, 255, 0.1); color: <?= $score_color ?>;">
                            <?= $exam['marks_obtained'] ?>/<?= $exam['total_marks'] ?? 100 ?>
                        </div>
                        <?php else: ?>
                        <div class="exam-score" style="background: rgba(245, 158, 11, 0.1); color: var(--warning);">Pending</div>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php else: ?>
                <p style="text-align: center; color: var(--gray); padding: 20px;">No exam records found</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions fade-in" style="animation-delay: 0.3s">
            <div class="stats-title">Quick Actions</div>
            <div class="actions-grid">
                <a href="exam_view.php" class="action-btn">
                    <i class="fas fa-file-alt"></i>
                    <span>View Exams</span>
                </a>
                <a href="student_attendance.php" class="action-btn">
                    <i class="fas fa-calendar-check"></i>
                    <span>Attendance</span>
                </a>
                <a href="student_profile.php" class="action-btn">
                    <i class="fas fa-user-edit"></i>
                    <span>Edit Profile</span>
                </a>
                <a href="change_password.php" class="action-btn">
                    <i class="fas fa-key"></i>
                    <span>Change Password</span>
                </a>
            </div>
        </div>
        <?php endif; ?>

        <!-- Footer -->
        <div class="footer">
            <p><i class="fas fa-school"></i> School Management System • Student Portal • <?= date('Y') ?></p>
            <p style="font-size: 12px; margin-top: 5px; color: var(--gray);">
                Session ID: <?= session_id() ?> • Last login: <?= date('Y-m-d H:i:s') ?>
            </p>
        </div>
    </div>

    <script>
        // Session timeout configuration (30 minutes)
        const SESSION_TIMEOUT = 30 * 60; // 30 minutes in seconds
        const WARNING_TIME = 5 * 60; // 5 minutes before timeout
        let idleTime = 0;
        let sessionTimer;

        // Initialize session timer
        function initSessionTimer() {
            // Reset timer on user activity
            document.addEventListener('mousemove', resetTimer);
            document.addEventListener('keypress', resetTimer);
            document.addEventListener('click', resetTimer);
            document.addEventListener('scroll', resetTimer);
            
            // Start timer
            sessionTimer = setInterval(checkSession, 1000);
        }

        function resetTimer() {
            idleTime = 0;
            document.getElementById('sessionWarning').style.display = 'none';
            document.getElementById('sessionModal').style.display = 'none';
        }

        function checkSession() {
            idleTime++;
            
            // Update session timer display
            const minutesLeft = Math.floor((SESSION_TIMEOUT - idleTime) / 60);
            const secondsLeft = (SESSION_TIMEOUT - idleTime) % 60;
            document.getElementById('sessionTimer').textContent = 
                `Session: ${minutesLeft}:${secondsLeft.toString().padStart(2, '0')}`;
            
            // Show warning 5 minutes before timeout
            if (idleTime >= SESSION_TIMEOUT - WARNING_TIME && idleTime < SESSION_TIMEOUT) {
                document.getElementById('sessionWarning').style.display = 'block';
            }
            
            // Show modal 60 seconds before timeout
            if (idleTime >= SESSION_TIMEOUT - 60) {
                document.getElementById('sessionModal').style.display = 'flex';
                updateCountdown();
            }
            
            // Auto-logout when timeout reached
            if (idleTime >= SESSION_TIMEOUT) {
                logout();
            }
        }

        function updateCountdown() {
            const secondsLeft = SESSION_TIMEOUT - idleTime;
            document.getElementById('countdown').textContent = secondsLeft;
            
            if (secondsLeft > 0) {
                setTimeout(updateCountdown, 1000);
            }
        }

        function extendSession() {
            // Send AJAX request to extend session
            fetch('extend_session.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        idleTime = 0;
                        document.getElementById('sessionModal').style.display = 'none';
                        document.getElementById('sessionWarning').style.display = 'none';
                        showAlert('Session extended successfully!', 'success');
                    }
                })
                .catch(error => {
                    console.error('Error extending session:', error);
                });
        }

        function logout() {
            window.location.href = '../logout.php';
        }

        function confirmLogout() {
            if (confirm('Are you sure you want to logout?')) {
                logout();
            }
        }

        // Show alert message
        function showAlert(message, type) {
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert-message ${type}`;
            alertDiv.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
                ${message}
            `;
            
            document.body.appendChild(alertDiv);
            
            // Remove after 5 seconds
            setTimeout(() => {
                alertDiv.style.opacity = '0';
                alertDiv.style.transform = 'translateX(-50%) translateY(-20px)';
                setTimeout(() => alertDiv.remove(), 500);
            }, 5000);
        }

        // Update current time
        function updateCurrentTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit',
                hour12: true 
            });
            document.getElementById('currentTime').textContent = timeString;
        }

        // Auto-hide existing alert messages
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize session timer
            initSessionTimer();
            
            // Update current time every second
            updateCurrentTime();
            setInterval(updateCurrentTime, 1000);
            
            // Auto-hide alert message after 5 seconds
            const alertMessage = document.getElementById('alertMessage');
            if (alertMessage) {
                setTimeout(() => {
                    alertMessage.style.opacity = '0';
                    alertMessage.style.transform = 'translateX(-50%) translateY(-20px)';
                    setTimeout(() => alertMessage.remove(), 500);
                }, 5000);
            }
            
            // Fade in elements with delay
            const elements = document.querySelectorAll('.fade-in');
            elements.forEach((el, index) => {
                el.style.opacity = '0';
                setTimeout(() => {
                    el.style.animation = `fadeIn 0.6s ease ${index * 0.1}s forwards`;
                }, 100);
            });

            // Attendance bar animation
            const attendanceFill = document.querySelector('.attendance-fill');
            if (attendanceFill) {
                attendanceFill.style.width = '0';
                setTimeout(() => {
                    attendanceFill.style.width = attendanceFill.style.width;
                }, 500);
            }

            // Add hover effects
            const cards = document.querySelectorAll('.info-card, .stats-card, .action-btn');
            cards.forEach(card => {
                card.addEventListener('mouseenter', () => {
                    card.style.transform = 'translateY(-5px)';
                });
                card.addEventListener('mouseleave', () => {
                    card.style.transform = 'translateY(0)';
                });
            });
        });

        // Prevent form resubmission on page refresh
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }

        // Detect browser/tab close
        window.addEventListener('beforeunload', function (e) {
            // Optional: Send logout request if needed
            // This is just for detection
        });
    </script>
</body>
</html>