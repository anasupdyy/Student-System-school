<?php
session_start();
require_once '../db.php';

// SESSION VALIDATION
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student') {
    header('Location: ../index.php');
    exit();
}

// Fetch student data with ALL fields
$stmt = $pdo->prepare("
    SELECT s.*, u.username, u.email, u.created_at as account_created,
           u.phone_number 
    FROM students s 
    JOIN users u ON s.user_id = u.id 
    WHERE s.user_id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch();

if (!$student) {
    header('Location: student_dashboard.php');
    exit();
}

$message = '';
$message_type = '';

// Handle profile update ONLY if there's a real change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    // Fetch current data for comparison
    $current = $student;

    // Sanitize inputs
    $first_name = trim($_POST['first_name'] ?? $current['first_name']);
    $last_name = trim($_POST['last_name'] ?? $current['last_name']);
    $email = trim($_POST['email'] ?? $current['email']);
    $phone_number = trim($_POST['phone_number'] ?? $current['phone_number']);
    $father_name = trim($_POST['father_name'] ?? $current['father_name']);
    $mother_name = trim($_POST['mother_name'] ?? $current['mother_name']);
    $parent_phone = trim($_POST['parent_phone'] ?? $current['parent_phone']);
    $address = trim($_POST['address'] ?? $current['address']);
    $date_of_birth = $_POST['date_of_birth'] ?? $current['date_of_birth'];
    $gender = $_POST['gender'] ?? $current['gender'];
    $grade_level = trim($_POST['grade_level'] ?? $current['grade_level']);
    $school_level = $_POST['school_level'] ?? $current['school_level'];
    $section = trim($_POST['section'] ?? $current['section']);
    $roll_number = trim($_POST['roll_number'] ?? $current['roll_number']);

    // Validation
    if (empty($first_name) || empty($last_name) || empty($email)) {
        $message = "❌ First name, last name and email are required.";
        $message_type = 'error';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "❌ Please enter a valid email address.";
        $message_type = 'error';
    } else {
        // Check if ANY field has changed
        $has_changed = (
            $first_name !== $current['first_name'] ||
            $last_name !== $current['last_name'] ||
            $email !== $current['email'] ||
            $phone_number !== $current['phone_number'] ||
            $father_name !== $current['father_name'] ||
            $mother_name !== $current['mother_name'] ||
            $parent_phone !== $current['parent_phone'] ||
            $address !== $current['address'] ||
            $date_of_birth !== $current['date_of_birth'] ||
            $gender !== $current['gender'] ||
            $grade_level !== $current['grade_level'] ||
            $school_level !== $current['school_level'] ||
            $section !== $current['section'] ||
            $roll_number !== $current['roll_number']
        );

        if ($has_changed) {
            try {
                $pdo->beginTransaction();

                // Update users table
                $update_user = $pdo->prepare("
                    UPDATE users 
                    SET email = ?, phone_number = ?, updated_at = NOW() 
                    WHERE id = ?
                ");
                $update_user->execute([$email, $phone_number, $_SESSION['user_id']]);

                // Update students table
                $update_student = $pdo->prepare("
                    UPDATE students 
                    SET first_name = ?, last_name = ?, 
                        father_name = ?, mother_name = ?, 
                        parent_phone = ?, address = ?, 
                        date_of_birth = ?, gender = ?,
                        grade_level = ?, school_level = ?,
                        section = ?, roll_number = ?,
                        updated_at = NOW()
                    WHERE user_id = ?
                ");
                $update_student->execute([
                    $first_name, $last_name,
                    $father_name, $mother_name,
                    $parent_phone, $address,
                    $date_of_birth, $gender,
                    $grade_level, $school_level,
                    $section, $roll_number,
                    $_SESSION['user_id']
                ]);

                $pdo->commit();

                // Refresh data
                $stmt->execute([$_SESSION['user_id']]);
                $student = $stmt->fetch();

                $message = "✅ Profile updated successfully!";
                $message_type = 'success';
            } catch (Exception $e) {
                $pdo->rollBack();
                $message = "❌ Error updating profile.";
                $message_type = 'error';
            }
        } else {
            // No change detected
            $message = "ℹ️ No changes detected.";
            $message_type = 'info';
        }
    }
}

// Calculate age
$age = 'N/A';
if (!empty($student['date_of_birth'])) {
    try {
        $birthDate = new DateTime($student['date_of_birth']);
        $today = new DateTime();
        $age = $today->diff($birthDate)->y;
    } catch (Exception $e) {
        $age = 'N/A';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | Student Portal</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #0a192f;
            --accent: #00ccff;
            --white: #ffffff;
            --light-bg: #f0f8ff;
            --gray: #64748b;
            --light-gray: #e2e8f0;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #3b82f6;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background-color: var(--white);
            color: #1e293b;
            min-height: 100vh;
            display: flex;
        }
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary) 0%, #0c2040 100%);
            color: var(--white);
            display: flex;
            flex-direction: column;
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
            z-index: 100;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
        }
        .sidebar-header {
            text-align: center;
            padding: 0 25px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 30px;
        }
        .profile-avatar-sidebar {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--accent), #0099cc);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            font-weight: 600;
            margin: 0 auto 15px;
            color: var(--white);
            border: 3px solid rgba(255, 255, 255, 0.2);
        }
        .sidebar-header h2 {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        .sidebar-header p {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.8);
            background: rgba(0, 204, 255, 0.2);
            padding: 4px 12px;
            border-radius: 20px;
            display: inline-block;
        }
        .nav-links {
            list-style: none;
            flex-grow: 1;
            padding: 0 20px;
        }
        .nav-links li { margin-bottom: 8px; }
        .nav-links a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            padding: 14px 18px;
            border-radius: 10px;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        .nav-links a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            transform: translateX(5px);
        }
        .nav-links a.active {
            background: var(--accent);
            color: var(--white);
            box-shadow: 0 4px 12px rgba(0, 204, 255, 0.3);
        }
        .nav-links i { width: 24px; margin-right: 12px; font-size: 18px; }
        .logout-btn {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            border: none;
            padding: 15px;
            margin: 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateY(-2px);
            border-color: rgba(255, 255, 255, 0.2);
        }
        .logout-btn i { margin-right: 10px; }
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
            background-color: #f8fafc;
            min-height: 100vh;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--light-gray);
        }
        .page-header h1 {
            color: var(--primary);
            font-size: 28px;
            font-weight: 700;
            display: flex;
            align-items: center;
        }
        .page-header h1 i {
            color: var(--accent);
            margin-right: 12px;
            font-size: 26px;
        }
        .back-btn {
            background: var(--light-bg);
            color: var(--primary);
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            border: 1px solid var(--light-gray);
        }
        .back-btn:hover {
            background: var(--accent);
            color: white;
            border-color: var(--accent);
            transform: translateY(-2px);
        }
        .profile-container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .message {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            border-left: 4px solid transparent;
            animation: slideIn 0.5s ease-out;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-20px); }
            to { opacity: 1; transform: translateX(0); }
        }
        .message.success {
            background: rgba(16, 185, 129, 0.1);
            border-left-color: var(--success);
            color: var(--success);
        }
        .message.error {
            background: rgba(239, 68, 68, 0.1);
            border-left-color: var(--danger);
            color: var(--danger);
        }
        .message.info {
            background: rgba(59, 130, 246, 0.1);
            border-left-color: var(--info);
            color: var(--info);
        }
        .message i { font-size: 20px; }
        .profile-header {
            background: white;
            border-radius: 15px;
            padding: 40px;
            margin-bottom: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--light-gray);
            display: flex;
            align-items: center;
            gap: 40px;
            position: relative;
        }
        @media (max-width: 768px) {
            .profile-header {
                flex-direction: column;
                text-align: center;
                padding: 30px 20px;
            }
        }
        .profile-photo-section {
            text-align: center;
        }
        .profile-photo-container {
            position: relative;
            width: 180px;
            height: 180px;
            margin: 0 auto 20px;
        }
        .profile-photo {
            width: 180px;
            height: 180px;
            border-radius: 50%;
            object-fit: cover;
            border: 5px solid white;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
            background: linear-gradient(135deg, var(--accent), #0099cc);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 60px;
            font-weight: 600;
        }
        .photo-info {
            color: var(--gray);
            font-size: 14px;
            margin-top: 10px;
        }
        .profile-info { flex: 1; }
        .profile-title {
            color: var(--primary);
            font-size: 32px;
            margin-bottom: 10px;
            font-weight: 700;
        }
        .profile-subtitle {
            color: var(--accent);
            font-size: 18px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .profile-subtitle i { font-size: 16px; }
        .profile-stats {
            display: flex;
            gap: 30px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        .stat-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 15px;
            background: var(--light-bg);
            border-radius: 10px;
            min-width: 120px;
        }
        .stat-value {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 5px;
        }
        .stat-label {
            color: var(--gray);
            font-size: 14px;
            text-align: center;
        }
        .profile-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            background: white;
            padding: 10px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--light-gray);
        }
        .tab-btn {
            flex: 1;
            padding: 15px 20px;
            background: none;
            border: none;
            border-radius: 8px;
            color: var(--gray);
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        .tab-btn:hover {
            background: var(--light-bg);
            color: var(--primary);
        }
        .tab-btn.active {
            background: var(--accent);
            color: white;
            box-shadow: 0 4px 12px rgba(0, 204, 255, 0.2);
        }
        .tab-btn i { font-size: 18px; }
        .tab-content {
            display: none;
            animation: fadeIn 0.5s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .tab-content.active { display: block; }
        .form-card {
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--light-gray);
            margin-bottom: 30px;
        }
        .form-card h3 {
            color: var(--primary);
            font-size: 22px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .form-card h3 i { color: var(--accent); }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
        }
        .form-group { margin-bottom: 20px; }
        .form-label {
            display: block;
            color: var(--primary);
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .form-label i { color: var(--accent); font-size: 16px; }
        .form-control {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid var(--light-gray);
            border-radius: 8px;
            font-size: 15px;
            color: var(--primary);
            background: white;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(0, 204, 255, 0.1);
        }
        .form-control:disabled {
            background: var(--light-bg);
            color: var(--gray);
            cursor: not-allowed;
        }
        select.form-control {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%2364748b' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14L2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 16px center;
            background-size: 16px;
            padding-right: 40px;
        }
        .form-help {
            color: var(--gray);
            font-size: 13px;
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            flex-wrap: wrap;
        }
        .btn {
            padding: 14px 28px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border: 2px solid transparent;
            text-decoration: none;
        }
        .btn-primary {
            background: var(--accent);
            color: white;
        }
        .btn-primary:hover {
            background: #0099cc;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 204, 255, 0.2);
        }
        .btn-secondary {
            background: white;
            color: var(--gray);
            border-color: var(--light-gray);
        }
        .btn-secondary:hover {
            background: var(--light-bg);
            color: var(--primary);
            border-color: var(--accent);
        }
        .footer {
            text-align: center;
            padding: 20px;
            color: var(--gray);
            font-size: 14px;
            margin-top: 40px;
            border-top: 1px solid var(--light-gray);
        }
        .footer i { color: var(--accent); margin-right: 8px; }
        @media (max-width: 1200px) {
            .sidebar { width: 80px; }
            .main-content { margin-left: 80px; }
            .sidebar-header h2, .sidebar-header p, .nav-links span, .logout-btn span { display: none; }
            .nav-links a { justify-content: center; padding: 16px; }
            .nav-links i { margin-right: 0; font-size: 20px; }
            .profile-avatar-sidebar { width: 50px; height: 50px; font-size: 22px; }
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                flex-direction: row;
                padding: 15px;
            }
            .main-content { margin-left: 0; padding: 20px; }
            .sidebar-header {
                display: flex;
                align-items: center;
                padding: 0;
                border-bottom: none;
                margin-bottom: 0;
                margin-right: 15px;
            }
            .profile-avatar-sidebar { width: 40px; height: 40px; margin: 0 10px 0 0; }
            .nav-links {
                display: flex;
                padding: 0;
                flex-grow: 0;
            }
            .nav-links li { margin-bottom: 0; margin-right: 5px; }
            .logout-btn { margin: 0 0 0 auto; padding: 10px; }
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            .profile-tabs { flex-direction: column; }
            .form-grid { grid-template-columns: 1fr; }
            .btn-group { flex-direction: column; }
            .btn { width: 100%; justify-content: center; }
            .profile-stats { justify-content: center; }
        }
        @media (max-width: 480px) {
            .main-content { padding: 15px; }
            .profile-header { padding: 20px 15px; }
            .profile-title { font-size: 24px; }
            .profile-photo-container { width: 150px; height: 150px; }
            .profile-photo { width: 150px; height: 150px; font-size: 50px; }
            .form-card { padding: 25px 20px; }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="profile-avatar-sidebar">
                <?= strtoupper(substr($student['first_name'][0] ?? 'S', 0, 1)) ?>
            </div>
            <div>
                <h2><?= htmlspecialchars($student['first_name'] ?? 'Student') ?></h2>
                <p>Grade <?= htmlspecialchars($student['grade_level'] ?? 'N/A') ?></p>
            </div>
        </div>
        <ul class="nav-links">
            <li><a href="student_dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
            <li><a href="exam_view.php"><i class="fas fa-file-alt"></i> <span>My Exams</span></a></li>
            <li><a href="student_attendance.php"><i class="fas fa-calendar-check"></i> <span>Attendance</span></a></li>
            <li><a href="profile.php" class="active"><i class="fas fa-user-cog"></i> <span>Profile</span></a></li>
            <li><a href="change_password.php"><i class="fas fa-key"></i> <span>Change Password</span></a></li>
        </ul>
        <button class="logout-btn" onclick="window.location='../index.php'">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </button>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="page-header">
            <h1><i class="fas fa-user-circle"></i> My Profile</h1>
            <a href="student_dashboard.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>

        <div class="profile-container">
            <div class="profile-header">
                <div class="profile-photo-section">
                    <div class="profile-photo-container">
                        <div class="profile-photo">
                            <?= strtoupper(substr($student['first_name'][0] ?? 'S', 0, 1)) ?>
                        </div>
                    </div>
                    <p class="photo-info">Profile photo cannot be changed</p>
                </div>
                <div class="profile-info">
                    <h1 class="profile-title">
                        <?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?>
                    </h1>
                    <div class="profile-subtitle">
                        <i class="fas fa-graduation-cap"></i>
                        <?php if (!empty($student['school_level'])): ?>
                            <?= htmlspecialchars($student['school_level']) ?> |
                        <?php endif; ?>
                        Grade <?= htmlspecialchars($student['grade_level'] ?? 'N/A') ?>
                        <?php if (!empty($student['section'])): ?>
                            | Section <?= htmlspecialchars($student['section']) ?>
                        <?php endif; ?>
                    </div>
                    <div class="profile-stats">
                        <div class="stat-item">
                            <div class="stat-value"><?= $age ?></div>
                            <div class="stat-label">Age</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value">
                                <?= !empty($student['gender']) ? ucfirst(htmlspecialchars($student['gender'])) : 'N/A' ?>
                            </div>
                            <div class="stat-label">Gender</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value">
                                <?= !empty($student['roll_number']) ? htmlspecialchars($student['roll_number']) : 'N/A' ?>
                            </div>
                            <div class="stat-label">Roll Number</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value">
                                <?= !empty($student['student_code']) ? htmlspecialchars($student['student_code']) : 
                                      (!empty($student['id']) ? 'STUDENT-' . str_pad($student['id'], 6, '0', STR_PAD_LEFT) : 'N/A') ?>
                            </div>
                            <div class="stat-label">Student ID</div>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($message): ?>
                <div class="message <?= $message_type ?>">
                    <i class="fas fa-<?= $message_type === 'success' ? 'check-circle' : ($message_type === 'info' ? 'info-circle' : 'exclamation-circle') ?>"></i>
                    <?= $message ?>
                </div>
            <?php endif; ?>

            <!-- Tabs -->
            <div class="profile-tabs">
                <button class="tab-btn active" onclick="showTab('personal')">
                    <i class="fas fa-user-edit"></i>
                    <span>Personal Information</span>
                </button>
                <button class="tab-btn" onclick="showTab('account')">
                    <i class="fas fa-id-card"></i>
                    <span>Account Information</span>
                </button>
                <button class="tab-btn" onclick="showTab('academic')">
                    <i class="fas fa-graduation-cap"></i>
                    <span>Academic Details</span>
                </button>
            </div>

            <!-- Personal Information Tab -->
            <div class="tab-content active" id="personalTab">
                <form method="POST">
                    <div class="form-card">
                        <h3><i class="fas fa-user-edit"></i> Personal Information</h3>
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label" for="first_name">
                                    <i class="fas fa-user"></i>
                                    <span>First Name *</span>
                                </label>
                                <input type="text" 
                                       id="first_name" 
                                       name="first_name" 
                                       class="form-control" 
                                       value="<?= htmlspecialchars($student['first_name'] ?? '') ?>"
                                       required>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="last_name">
                                    <i class="fas fa-user"></i>
                                    <span>Last Name *</span>
                                </label>
                                <input type="text" 
                                       id="last_name" 
                                       name="last_name" 
                                       class="form-control" 
                                       value="<?= htmlspecialchars($student['last_name'] ?? '') ?>"
                                       required>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="email">
                                    <i class="fas fa-envelope"></i>
                                    <span>Email *</span>
                                </label>
                                <input type="email" 
                                       id="email" 
                                       name="email" 
                                       class="form-control" 
                                       value="<?= htmlspecialchars($student['email'] ?? '') ?>"
                                       required>
                                <div class="form-help">
                                    <i class="fas fa-info-circle"></i>
                                    Used for login and notifications
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="phone_number">
                                    <i class="fas fa-phone"></i>
                                    <span>Phone Number</span>
                                </label>
                                <input type="tel" 
                                       id="phone_number" 
                                       name="phone_number" 
                                       class="form-control" 
                                       value="<?= htmlspecialchars($student['phone_number'] ?? '') ?>"
                                       placeholder="+252 61 123 4567">
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="gender">
                                    <i class="fas fa-venus-mars"></i>
                                    <span>Gender</span>
                                </label>
                                <select id="gender" name="gender" class="form-control">
                                    <option value="">Select Gender</option>
                                    <option value="male" <?= ($student['gender'] ?? '') == 'male' ? 'selected' : '' ?>>Male</option>
                                    <option value="female" <?= ($student['gender'] ?? '') == 'female' ? 'selected' : '' ?>>Female</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="date_of_birth">
                                    <i class="fas fa-birthday-cake"></i>
                                    <span>Date of Birth</span>
                                </label>
                                <input type="date" 
                                       id="date_of_birth" 
                                       name="date_of_birth" 
                                       class="form-control" 
                                       value="<?= htmlspecialchars($student['date_of_birth'] ?? '') ?>"
                                       max="<?= date('Y-m-d') ?>">
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="address">
                                    <i class="fas fa-home"></i>
                                    <span>Address</span>
                                </label>
                                <textarea id="address" 
                                          name="address" 
                                          class="form-control" 
                                          rows="3"
                                          placeholder="Enter your full address"><?= htmlspecialchars($student['address'] ?? '') ?></textarea>
                            </div>
                        </div>
                        <h3 style="margin-top: 40px; margin-bottom: 25px;">
                            <i class="fas fa-users"></i> Parent/Guardian Information
                        </h3>
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label" for="father_name">
                                    <i class="fas fa-male"></i>
                                    <span>Father's Name</span>
                                </label>
                                <input type="text" 
                                       id="father_name" 
                                       name="father_name" 
                                       class="form-control" 
                                       value="<?= htmlspecialchars($student['father_name'] ?? '') ?>">
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="mother_name">
                                    <i class="fas fa-female"></i>
                                    <span>Mother's Name</span>
                                </label>
                                <input type="text" 
                                       id="mother_name" 
                                       name="mother_name" 
                                       class="form-control" 
                                       value="<?= htmlspecialchars($student['mother_name'] ?? '') ?>">
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="parent_phone">
                                    <i class="fas fa-phone-alt"></i>
                                    <span>Parent Phone</span>
                                </label>
                                <input type="tel" 
                                       id="parent_phone" 
                                       name="parent_phone" 
                                       class="form-control" 
                                       value="<?= htmlspecialchars($student['parent_phone'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="btn-group">
                            <button type="submit" name="update_profile" class="btn btn-primary">
                                <i class="fas fa-save"></i>
                                <span>Save Changes</span>
                            </button>
                            <button type="reset" class="btn btn-secondary">
                                <i class="fas fa-redo"></i>
                                <span>Reset Form</span>
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Account Information Tab -->
            <div class="tab-content" id="accountTab">
                <div class="form-card">
                    <h3><i class="fas fa-id-card"></i> Account Information</h3>
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">
                                <i class="fas fa-user"></i>
                                <span>Username</span>
                            </div>
                            <div class="info-value"><?= htmlspecialchars($student['username'] ?? 'N/A') ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">
                                <i class="fas fa-envelope"></i>
                                <span>Email</span>
                            </div>
                            <div class="info-value"><?= htmlspecialchars($student['email'] ?? 'N/A') ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">
                                <i class="fas fa-calendar-plus"></i>
                                <span>Account Created</span>
                            </div>
                            <div class="info-value">
                                <?= !empty($student['account_created']) ? date('M d, Y', strtotime($student['account_created'])) : 'N/A' ?>
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">
                                <i class="fas fa-shield-alt"></i>
                                <span>Account Status</span>
                            </div>
                            <div class="info-value" style="color: var(--success);">
                                <i class="fas fa-check-circle"></i> Active
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">
                                <i class="fas fa-user-tag"></i>
                                <span>Role</span>
                            </div>
                            <div class="info-value">Student</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">
                                <i class="fas fa-key"></i>
                                <span>Password</span>
                            </div>
                            <div class="info-value">
                                <a href="change_password.php" class="btn btn-secondary" style="padding: 8px 16px;">
                                    <i class="fas fa-edit"></i>
                                    Change Password
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Academic Details Tab -->
            <div class="tab-content" id="academicTab">
                <div class="form-card">
                    <h3><i class="fas fa-graduation-cap"></i> Academic Details</h3>
                    <form method="POST">
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label" for="grade_level">
                                    <i class="fas fa-graduation-cap"></i>
                                    <span>Grade Level *</span>
                                </label>
                                <input type="text" 
                                       id="grade_level" 
                                       name="grade_level" 
                                       class="form-control" 
                                       value="<?= htmlspecialchars($student['grade_level'] ?? '') ?>"
                                       placeholder="e.g., 10, 11, 12"
                                       required>
                                <div class="form-help">
                                    <i class="fas fa-info-circle"></i>
                                    Enter your grade level (10, 11, 12, etc.)
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="school_level">
                                    <i class="fas fa-school"></i>
                                    <span>School Level</span>
                                </label>
                                <select id="school_level" name="school_level" class="form-control">
                                    <option value="">Select Level</option>
                                    <option value="Primary School" <?= ($student['school_level'] ?? '') == 'Primary School' ? 'selected' : '' ?>>Primary School</option>
                                    <option value="Middle School" <?= ($student['school_level'] ?? '') == 'Middle School' ? 'selected' : '' ?>>Middle School</option>
                                    <option value="High School" <?= ($student['school_level'] ?? '') == 'High School' ? 'selected' : '' ?>>High School</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="section">
                                    <i class="fas fa-chalkboard"></i>
                                    <span>Section</span>
                                </label>
                                <input type="text" 
                                       id="section" 
                                       name="section" 
                                       class="form-control" 
                                       value="<?= htmlspecialchars($student['section'] ?? '') ?>"
                                       placeholder="e.g., A, B, C">
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="roll_number">
                                    <i class="fas fa-list-ol"></i>
                                    <span>Roll Number</span>
                                </label>
                                <input type="text" 
                                       id="roll_number" 
                                       name="roll_number" 
                                       class="form-control" 
                                       value="<?= htmlspecialchars($student['roll_number'] ?? '') ?>"
                                       placeholder="e.g., 01, 02, 03">
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="student_code">
                                    <i class="fas fa-id-card"></i>
                                    <span>Student Code</span>
                                </label>
                                <input type="text" 
                                       id="student_code" 
                                       class="form-control" 
                                       value="<?= !empty($student['student_code']) ? htmlspecialchars($student['student_code']) : 
                                              (!empty($student['id']) ? 'STUDENT-' . str_pad($student['id'], 6, '0', STR_PAD_LEFT) : 'N/A') ?>"
                                       disabled>
                                <div class="form-help">
                                    <i class="fas fa-info-circle"></i>
                                    Assigned by system, cannot be changed
                                </div>
                            </div>
                        </div>
                        <div class="btn-group">
                            <button type="submit" name="update_profile" class="btn btn-primary">
                                <i class="fas fa-save"></i>
                                <span>Save Academic Details</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="footer">
            <p><i class="fas fa-school"></i> School Management System • Student Profile • <?= date('Y') ?></p>
        </div>
    </div>

    <script>
        function showTab(tabName) {
            document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            document.getElementById(tabName + 'Tab').classList.add('active');
            event.currentTarget.classList.add('active');
        }

        document.addEventListener('DOMContentLoaded', function() {
            const messages = document.querySelectorAll('.message');
            messages.forEach(message => {
                setTimeout(() => {
                    message.style.opacity = '0';
                    message.style.transform = 'translateX(-20px)';
                    message.style.transition = 'all 0.5s ease';
                    setTimeout(() => message.style.display = 'none', 500);
                }, 8000);
            });

            const dobInput = document.getElementById('date_of_birth');
            if (dobInput) {
                dobInput.max = new Date().toISOString().split('T')[0];
            }

            const forms = document.querySelectorAll('form');
            forms.forEach(form => {
                form.addEventListener('submit', function(e) {
                    const submitBtn = this.querySelector('button[type="submit"]');
                    if (submitBtn && !submitBtn.disabled) {
                        const originalHtml = submitBtn.innerHTML;
                        const originalText = submitBtn.querySelector('span')?.textContent || 'Saving...';
                        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>' + originalText + '</span>';
                        submitBtn.disabled = true;
                        setTimeout(() => {
                            if (submitBtn.disabled) {
                                submitBtn.innerHTML = originalHtml;
                                submitBtn.disabled = false;
                                alert('Submission is taking too long. Please try again.');
                            }
                        }, 10000);
                    }
                });
            });

            showTab('personal');
        });

        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>