<?php
session_start();
require_once '../db.php';

// SESSION VALIDATION
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student') {
    header('Location: ../index.php');
    exit();
}

// Ka soo qaado ardayga
$stmt = $pdo->prepare("
    SELECT s.*, u.username, u.email 
    FROM students s 
    JOIN users u ON s.user_id = u.id 
    WHERE s.user_id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch();

if (!$student) {
    header('Location: student_dashboard.php');
    exit();
}

$message = '';
$message_type = '';

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Validate inputs
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $message = "❌ All fields are required.";
        $message_type = 'error';
    } elseif ($new_password !== $confirm_password) {
        $message = "❌ New passwords do not match.";
        $message_type = 'error';
    } elseif (strlen($new_password) < 8) {
        $message = "❌ Password must be at least 8 characters long.";
        $message_type = 'error';
    } else {
        // Verify current password
        $user_stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
        $user_stmt->execute([$_SESSION['user_id']]);
        $user = $user_stmt->fetch();

        if (!$user) {
            $message = "❌ User not found.";
            $message_type = 'error';
        } elseif (!password_verify($current_password, $user['password'])) {
            $message = "❌ Current password is incorrect.";
            $message_type = 'error';
        } else {
            // Check if password history table exists
            $table_exists = $pdo->query("SHOW TABLES LIKE 'password_history'")->fetch();
            
            // Update password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            try {
                // Start transaction
                $pdo->beginTransaction();
                
                // Update password in users table
                $update_stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                $update_stmt->execute([$hashed_password, $_SESSION['user_id']]);
                
                // Log the password change if table exists
                if ($table_exists) {
                    $log_stmt = $pdo->prepare("
                        INSERT INTO password_history (user_id, changed_at) 
                        VALUES (?, NOW())
                    ");
                    $log_stmt->execute([$_SESSION['user_id']]);
                }
                
                // Commit transaction
                $pdo->commit();
                
                $message = "✅ Password changed successfully!";
                $message_type = 'success';
                
                // Clear form
                $_POST = [];
                
            } catch (Exception $e) {
                // Rollback transaction on error
                $pdo->rollBack();
                $message = "❌ Error: " . $e->getMessage();
                $message_type = 'error';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password | Student Portal</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #0a192f;
            --accent: #00ccff;
            --white: #ffffff;
            --light-bg: #f0f8ff;
            --gray: #64748b;
            --light-gray: #e2e8f0;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #3b82f6;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--white);
            color: #1e293b;
            min-height: 100vh;
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary) 0%, #0c2040 100%);
            color: var(--white);
            display: flex;
            flex-direction: column;
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
            z-index: 100;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            text-align: center;
            padding: 0 25px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 30px;
        }

        .profile-avatar {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--accent), #0099cc);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            font-weight: 600;
            margin: 0 auto 15px;
            color: var(--white);
            border: 3px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar-header h2 {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.8);
            background: rgba(0, 204, 255, 0.2);
            padding: 4px 12px;
            border-radius: 20px;
            display: inline-block;
        }

        .nav-links {
            list-style: none;
            flex-grow: 1;
            padding: 0 20px;
        }

        .nav-links li {
            margin-bottom: 8px;
        }

        .nav-links a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            padding: 14px 18px;
            border-radius: 10px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-links a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            transform: translateX(5px);
        }

        .nav-links a.active {
            background: var(--accent);
            color: var(--white);
            box-shadow: 0 4px 12px rgba(0, 204, 255, 0.3);
        }

        .nav-links i {
            width: 24px;
            margin-right: 12px;
            font-size: 18px;
        }

        .logout-btn {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
            border: none;
            padding: 15px;
            margin: 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateY(-2px);
            border-color: rgba(255, 255, 255, 0.2);
        }

        .logout-btn i {
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
            background-color: #f8fafc;
            min-height: 100vh;
        }

        /* Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--light-gray);
        }

        .page-header h1 {
            color: var(--primary);
            font-size: 28px;
            font-weight: 700;
            display: flex;
            align-items: center;
        }

        .page-header h1 i {
            color: var(--accent);
            margin-right: 12px;
            font-size: 26px;
        }

        .back-btn {
            background: var(--light-bg);
            color: var(--primary);
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            border: 1px solid var(--light-gray);
        }

        .back-btn:hover {
            background: var(--accent);
            color: white;
            border-color: var(--accent);
            transform: translateY(-2px);
        }

        /* Password Change Card */
        .password-card {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            border: 1px solid var(--light-gray);
            animation: fadeIn 0.6s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .card-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .card-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, rgba(0, 204, 255, 0.1), rgba(0, 153, 255, 0.1));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            color: var(--accent);
            font-size: 32px;
            border: 2px dashed var(--accent);
        }

        .card-header h2 {
            color: var(--primary);
            font-size: 24px;
            margin-bottom: 10px;
        }

        .card-header p {
            color: var(--gray);
            font-size: 16px;
        }

        /* Message */
        .message {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            border-left: 4px solid transparent;
            animation: slideIn 0.5s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .message.success {
            background: rgba(16, 185, 129, 0.1);
            border-left-color: var(--success);
            color: var(--success);
        }

        .message.error {
            background: rgba(239, 68, 68, 0.1);
            border-left-color: var(--danger);
            color: var(--danger);
        }

        .message i {
            font-size: 20px;
        }

        /* Form */
        .form-group {
            margin-bottom: 25px;
        }

        .form-label {
            display: block;
            color: var(--primary);
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-label i {
            color: var(--accent);
        }

        .form-control {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid var(--light-gray);
            border-radius: 8px;
            font-size: 15px;
            color: var(--primary);
            background: white;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(0, 204, 255, 0.1);
        }

        .password-wrapper {
            position: relative;
        }

        .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--gray);
            cursor: pointer;
            font-size: 18px;
            transition: color 0.3s ease;
        }

        .toggle-password:hover {
            color: var(--accent);
        }

        /* Password Strength Meter */
        .password-strength {
            margin-top: 10px;
        }

        .strength-meter {
            height: 6px;
            background: var(--light-gray);
            border-radius: 3px;
            overflow: hidden;
            margin-bottom: 8px;
        }

        .strength-fill {
            height: 100%;
            width: 0%;
            border-radius: 3px;
            transition: all 0.3s ease;
        }

        .strength-text {
            font-size: 13px;
            color: var(--gray);
            display: flex;
            justify-content: space-between;
        }

        /* Password Requirements */
        .requirements {
            background: rgba(0, 204, 255, 0.05);
            border-radius: 10px;
            padding: 20px;
            margin-top: 30px;
            border-left: 4px solid var(--accent);
        }

        .requirements h4 {
            color: var(--primary);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
        }

        .requirements ul {
            list-style: none;
            padding-left: 0;
        }

        .requirements li {
            margin-bottom: 8px;
            color: var(--gray);
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
        }

        .requirements li i {
            color: var(--gray);
            font-size: 12px;
        }

        .requirements li.valid i {
            color: var(--success);
        }

        /* Buttons */
        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            padding: 14px 28px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border: 2px solid transparent;
            text-decoration: none;
            flex: 1;
        }

        .btn-primary {
            background: var(--accent);
            color: white;
        }

        .btn-primary:hover {
            background: #0099cc;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 204, 255, 0.2);
        }

        .btn-secondary {
            background: white;
            color: var(--gray);
            border-color: var(--light-gray);
        }

        .btn-secondary:hover {
            background: var(--light-bg);
            color: var(--primary);
            border-color: var(--accent);
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 20px;
            color: var(--gray);
            font-size: 14px;
            margin-top: 40px;
            border-top: 1px solid var(--light-gray);
        }

        .footer i {
            color: var(--accent);
            margin-right: 8px;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 80px;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .sidebar-header h2,
            .sidebar-header p,
            .nav-links span,
            .logout-btn span {
                display: none;
            }
            
            .nav-links a {
                justify-content: center;
                padding: 16px;
            }
            
            .nav-links i {
                margin-right: 0;
                font-size: 20px;
            }
            
            .profile-avatar {
                width: 50px;
                height: 50px;
                font-size: 22px;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                flex-direction: row;
                padding: 15px;
            }
            
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
            
            .sidebar-header {
                display: flex;
                align-items: center;
                padding: 0;
                border-bottom: none;
                margin-bottom: 0;
                margin-right: 15px;
            }
            
            .profile-avatar {
                width: 40px;
                height: 40px;
                margin: 0 10px 0 0;
            }
            
            .nav-links {
                display: flex;
                padding: 0;
                flex-grow: 0;
            }
            
            .nav-links li {
                margin-bottom: 0;
                margin-right: 5px;
            }
            
            .logout-btn {
                margin: 0 0 0 auto;
                padding: 10px;
            }
            
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .password-card {
                padding: 30px 20px;
            }
            
            .btn-group {
                flex-direction: column;
            }
        }

        @media (max-width: 480px) {
            .main-content {
                padding: 15px;
            }
            
            .card-header h2 {
                font-size: 20px;
            }
            
            .requirements {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="profile-avatar">
                <?= strtoupper(substr($student['first_name'][0] ?? 'S', 0, 1)) ?>
            </div>
            <div>
                <h2><?= htmlspecialchars($student['first_name'] ?? 'Student') ?></h2>
                <p>Grade <?= htmlspecialchars($student['grade_level'] ?? 'N/A') ?></p>
            </div>
        </div>
        
        <ul class="nav-links">
            <li><a href="student_dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
            <li><a href="exam_view.php"><i class="fas fa-file-alt"></i> <span>My Exams</span></a></li>
            <li><a href="student_attendance.php"><i class="fas fa-calendar-check"></i> <span>Attendance</span></a></li>
            <li><a href="profile.php"><i class="fas fa-user-cog"></i> <span>Profile</span></a></li>
            <li><a href="change_password.php" class="active"><i class="fas fa-key"></i> <span>Change Password</span></a></li>
        </ul>
        
        <button class="logout-btn" onclick="window.location='../index.php'">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </button>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="page-header">
            <h1><i class="fas fa-key"></i> Change Password</h1>
            <a href="student_dashboard.php" class="back-btn">
                <i class="fas fa-arrow-left"></i>
                Back to Dashboard
            </a>
        </div>

        <!-- Password Change Card -->
        <div class="password-card">
            <div class="card-header">
                <div class="card-icon">
                    <i class="fas fa-lock"></i>
                </div>
                <h2>Update Your Password</h2>
                <p>Keep your account secure with a strong password</p>
            </div>

            <?php if ($message): ?>
                <div class="message <?= $message_type ?>">
                    <i class="fas fa-<?= $message_type === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                    <?= $message ?>
                </div>
            <?php endif; ?>

            <form method="POST" id="passwordForm">
                <div class="form-group">
                    <label class="form-label" for="current_password">
                        <i class="fas fa-lock"></i>
                        <span>Current Password</span>
                    </label>
                    <div class="password-wrapper">
                        <input type="password" 
                               id="current_password" 
                               name="current_password" 
                               class="form-control" 
                               placeholder="Enter your current password"
                               required>
                        <button type="button" class="toggle-password" onclick="togglePassword('current_password')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="new_password">
                        <i class="fas fa-key"></i>
                        <span>New Password</span>
                    </label>
                    <div class="password-wrapper">
                        <input type="password" 
                               id="new_password" 
                               name="new_password" 
                               class="form-control" 
                               placeholder="Enter new password"
                               required
                               onkeyup="checkPasswordStrength()">
                        <button type="button" class="toggle-password" onclick="togglePassword('new_password')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    
                    <!-- Password Strength Meter -->
                    <div class="password-strength" id="passwordStrength" style="display: none;">
                        <div class="strength-meter">
                            <div class="strength-fill" id="strengthFill"></div>
                        </div>
                        <div class="strength-text">
                            <span id="strengthText">Password strength</span>
                            <span id="strengthScore">0%</span>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="confirm_password">
                        <i class="fas fa-check-circle"></i>
                        <span>Confirm New Password</span>
                    </label>
                    <div class="password-wrapper">
                        <input type="password" 
                               id="confirm_password" 
                               name="confirm_password" 
                               class="form-control" 
                               placeholder="Confirm new password"
                               required
                               onkeyup="checkPasswordMatch()">
                        <button type="button" class="toggle-password" onclick="togglePassword('confirm_password')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <div id="passwordMatch" style="margin-top: 8px; font-size: 14px; display: none;"></div>
                </div>

                <!-- Password Requirements -->
                <div class="requirements">
                    <h4><i class="fas fa-shield-alt"></i> Password Requirements</h4>
                    <ul>
                        <li id="reqLength"><i class="fas fa-circle"></i> At least 8 characters long</li>
                        <li id="reqUppercase"><i class="fas fa-circle"></i> Contains uppercase letter</li>
                        <li id="reqLowercase"><i class="fas fa-circle"></i> Contains lowercase letter</li>
                        <li id="reqNumber"><i class="fas fa-circle"></i> Contains number</li>
                        <li id="reqSpecial"><i class="fas fa-circle"></i> Contains special character</li>
                    </ul>
                </div>

                <div class="btn-group">
                    <button type="submit" class="btn btn-primary" id="submitBtn">
                        <i class="fas fa-save"></i>
                        <span>Change Password</span>
                    </button>
                    <button type="reset" class="btn btn-secondary" onclick="resetForm()">
                        <i class="fas fa-redo"></i>
                        <span>Reset Form</span>
                    </button>
                </div>
            </form>

            <!-- Security Tips -->
            <div class="footer">
                <p><i class="fas fa-lightbulb"></i> 
                    <strong>Security Tips:</strong> Use a unique password that you don't use elsewhere. 
                    Consider using a password manager.
                </p>
            </div>
        </div>
    </div>

    <script>
        // Toggle password visibility
        function togglePassword(fieldId) {
            const field = document.getElementById(fieldId);
            const toggleBtn = field.nextElementSibling;
            const icon = toggleBtn.querySelector('i');
            
            if (field.type === 'password') {
                field.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                field.type = 'password';
                icon.className = 'fas fa-eye';
            }
        }

        // Check password strength
        function checkPasswordStrength() {
            const password = document.getElementById('new_password').value;
            const strengthDiv = document.getElementById('passwordStrength');
            const strengthFill = document.getElementById('strengthFill');
            const strengthText = document.getElementById('strengthText');
            const strengthScore = document.getElementById('strengthScore');
            
            if (password.length === 0) {
                strengthDiv.style.display = 'none';
                return;
            }
            
            strengthDiv.style.display = 'block';
            
            // Check requirements
            const hasLength = password.length >= 8;
            const hasUppercase = /[A-Z]/.test(password);
            const hasLowercase = /[a-z]/.test(password);
            const hasNumber = /[0-9]/.test(password);
            const hasSpecial = /[^A-Za-z0-9]/.test(password);
            
            // Update requirement indicators
            updateRequirement('reqLength', hasLength);
            updateRequirement('reqUppercase', hasUppercase);
            updateRequirement('reqLowercase', hasLowercase);
            updateRequirement('reqNumber', hasNumber);
            updateRequirement('reqSpecial', hasSpecial);
            
            // Calculate strength score
            let score = 0;
            if (hasLength) score += 20;
            if (hasUppercase) score += 20;
            if (hasLowercase) score += 20;
            if (hasNumber) score += 20;
            if (hasSpecial) score += 20;
            
            // Update UI
            strengthFill.style.width = score + '%';
            strengthScore.textContent = score + '%';
            
            // Set color based on score
            if (score < 40) {
                strengthFill.style.background = '#ef4444'; // red
                strengthText.textContent = 'Weak';
                strengthText.style.color = '#ef4444';
            } else if (score < 80) {
                strengthFill.style.background = '#f59e0b'; // orange
                strengthText.textContent = 'Fair';
                strengthText.style.color = '#f59e0b';
            } else {
                strengthFill.style.background = '#10b981'; // green
                strengthText.textContent = 'Strong';
                strengthText.style.color = '#10b981';
            }
        }
        
        function updateRequirement(elementId, isValid) {
            const element = document.getElementById(elementId);
            const icon = element.querySelector('i');
            
            if (isValid) {
                element.classList.add('valid');
                icon.className = 'fas fa-check-circle';
                icon.style.color = '#10b981';
            } else {
                element.classList.remove('valid');
                icon.className = 'fas fa-circle';
                icon.style.color = '#64748b';
            }
        }
        
        // Check password match
        function checkPasswordMatch() {
            const password = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const matchDiv = document.getElementById('passwordMatch');
            
            if (confirmPassword.length === 0) {
                matchDiv.style.display = 'none';
                return;
            }
            
            matchDiv.style.display = 'block';
            
            if (password === confirmPassword && password.length > 0) {
                matchDiv.innerHTML = '<i class="fas fa-check-circle" style="color: #10b981;"></i> Passwords match';
                matchDiv.style.color = '#10b981';
            } else if (password.length > 0) {
                matchDiv.innerHTML = '<i class="fas fa-times-circle" style="color: #ef4444;"></i> Passwords do not match';
                matchDiv.style.color = '#ef4444';
            }
        }
        
        // Reset form
        function resetForm() {
            document.getElementById('passwordStrength').style.display = 'none';
            document.getElementById('passwordMatch').style.display = 'none';
            
            // Reset requirement indicators
            const requirements = ['reqLength', 'reqUppercase', 'reqLowercase', 'reqNumber', 'reqSpecial'];
            requirements.forEach(id => {
                const element = document.getElementById(id);
                element.classList.remove('valid');
                const icon = element.querySelector('i');
                icon.className = 'fas fa-circle';
                icon.style.color = '#64748b';
            });
        }
        
        // Form validation
        document.getElementById('passwordForm').addEventListener('submit', function(e) {
            const currentPassword = document.getElementById('current_password').value;
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (newPassword !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match. Please confirm your new password.');
                return false;
            }
            
            if (newPassword.length < 8) {
                e.preventDefault();
                alert('Password must be at least 8 characters long.');
                return false;
            }
            
            // Check if new password is same as current
            if (currentPassword === newPassword) {
                e.preventDefault();
                alert('New password must be different from current password.');
                return false;
            }
            
            // Show loading state
            const submitBtn = document.getElementById('submitBtn');
            const originalHtml = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Changing Password...';
            submitBtn.disabled = true;
            
            // Re-enable button after 3 seconds (in case submission fails)
            setTimeout(() => {
                submitBtn.innerHTML = originalHtml;
                submitBtn.disabled = false;
            }, 3000);
        });
        
        // Auto-hide messages after 8 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const message = document.querySelector('.message');
            if (message) {
                setTimeout(() => {
                    message.style.opacity = '0';
                    message.style.transform = 'translateX(-20px)';
                    message.style.transition = 'all 0.5s ease';
                    
                    setTimeout(() => {
                        message.style.display = 'none';
                    }, 500);
                }, 8000);
            }
            
            // Focus on current password field
            document.getElementById('current_password').focus();
        });
    </script>
</body>
</html>