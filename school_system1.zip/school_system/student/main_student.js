// ====== GLOBAL FUNCTIONS ======

// Search students function
function searchStudents() {
    var input = document.getElementById("searchInput");
    var filter = input.value.toLowerCase();
    var table = document.getElementById("studentsTable");
    var tr = table.getElementsByTagName("tr");
    
    for (var i = 1; i < tr.length; i++) {
        var td = tr[i].getElementsByTagName("td");
        var found = false;
        
        for (var j = 0; j < td.length; j++) {
            if (td[j]) {
                if (td[j].textContent.toLowerCase().indexOf(filter) > -1) {
                    found = true;
                    break;
                }
            }
        }
        
        if (found) {
            tr[i].style.display = "";
            tr[i].classList.add("animate__animated", "animate__fadeIn");
        } else {
            tr[i].style.display = "none";
        }
    }
}

// Confirm delete function
function confirmDelete(event, studentName) {
    if (!confirm(`Are you sure you want to delete ${studentName}?`)) {
        event.preventDefault();
        return false;
    }
    return true;
}

// Trigger chart animation on load
function animateCharts() {
    setTimeout(() => {
        document.querySelectorAll('.chart-fill').forEach(bar => {
            const width = bar.style.width;
            bar.style.width = '0%';
            setTimeout(() => {
                bar.style.width = width;
                bar.style.transition = 'width 1.2s cubic-bezier(0.22, 0.61, 0.36, 1)';
            }, 100);
        });
    }, 300);
}

// Form validation
function validateStudentForm() {
    const firstName = document.getElementById('first_name');
    const lastName = document.getElementById('last_name');
    const dob = document.getElementById('date_of_birth');
    const grade = document.getElementById('grade_level');
    const parentContact = document.getElementById('parent_contact');
    
    let isValid = true;
    
    // Reset error states
    [firstName, lastName, dob, grade, parentContact].forEach(field => {
        field.style.borderColor = '#e9ecef';
        const errorMsg = field.nextElementSibling;
        if (errorMsg && errorMsg.classList.contains('error-message')) {
            errorMsg.remove();
        }
    });
    
    // Validate first name
    if (!firstName.value.trim()) {
        showError(firstName, 'First name is required');
        isValid = false;
    }
    
    // Validate last name
    if (!lastName.value.trim()) {
        showError(lastName, 'Last name is required');
        isValid = false;
    }
    
    // Validate date of birth
    if (!dob.value) {
        showError(dob, 'Date of birth is required');
        isValid = false;
    } else {
        const birthDate = new Date(dob.value);
        const today = new Date();
        if (birthDate >= today) {
            showError(dob, 'Date of birth must be in the past');
            isValid = false;
        }
    }
    
    // Validate grade level
    if (!grade.value) {
        showError(grade, 'Please select a grade level');
        isValid = false;
    }
    
    // Validate parent contact
    if (!parentContact.value.trim()) {
        showError(parentContact, 'Parent contact information is required');
        isValid = false;
    }
    
    return isValid;
}

function showError(field, message) {
    field.style.borderColor = '#ef476f';
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.style.color = '#ef476f';
    errorDiv.style.fontSize = '0.85rem';
    errorDiv.style.marginTop = '5px';
    errorDiv.textContent = message;
    field.parentNode.appendChild(errorDiv);
}

// Toggle sidebar on mobile
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const main = document.querySelector('.main');
    
    if (sidebar.style.width === '80px' || sidebar.style.width === '') {
        sidebar.style.width = '240px';
        main.style.marginLeft = '240px';
        // Show text in sidebar
        document.querySelectorAll('.nav-links a span').forEach(span => {
            span.style.display = 'inline';
        });
        document.querySelector('.sidebar h2').style.display = 'block';
        document.querySelector('.sidebar p').style.display = 'block';
    } else {
        sidebar.style.width = '80px';
        main.style.marginLeft = '80px';
        // Hide text in sidebar
        document.querySelectorAll('.nav-links a span').forEach(span => {
            span.style.display = 'none';
        });
        document.querySelector('.sidebar h2').style.display = 'none';
        document.querySelector('.sidebar p').style.display = 'none';
    }
}

// Calculate attendance percentage
function calculateAttendancePercentage(presentDays, totalDays) {
    if (totalDays === 0) return 0;
    return Math.round((presentDays / totalDays) * 100);
}

// Show notification
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        </div>
        <button class="notification-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // Add styles if not already added
    if (!document.getElementById('notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                border-radius: 10px;
                box-shadow: 0 5px 15px rgba(0,0,0,0.2);
                z-index: 9999;
                display: flex;
                align-items: center;
                justify-content: space-between;
                min-width: 300px;
                max-width: 400px;
                animation: slideInRight 0.3s ease, fadeOut 0.3s ease 4.7s forwards;
            }
            .notification-success {
                background: linear-gradient(135deg, #06d6a0, #00b894);
                color: white;
                border-left: 5px solid #00a085;
            }
            .notification-error {
                background: linear-gradient(135deg, #ef476f, #e8416f);
                color: white;
                border-left: 5px solid #d6305f;
            }
            .notification-content {
                display: flex;
                align-items: center;
                gap: 10px;
                flex: 1;
            }
            .notification-close {
                background: transparent;
                border: none;
                color: white;
                cursor: pointer;
                font-size: 1.2rem;
                padding: 0 0 0 10px;
            }
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes fadeOut {
                from { opacity: 1; }
                to { opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Format date
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Calculate grade from marks
function calculateGrade(marks, totalMarks) {
    const percentage = (marks / totalMarks) * 100;
    
    if (percentage >= 90) return 'A';
    if (percentage >= 80) return 'B';
    if (percentage >= 70) return 'C';
    if (percentage >= 60) return 'D';
    return 'F';
}

// Debounce function for search
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Initialize page
function initPage() {
    // Add event listeners for search
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('keyup', debounce(searchStudents, 300));
    }
    
    // Animate charts if they exist
    if (document.querySelector('.chart-fill')) {
        animateCharts();
    }
    
    // Add hover effects to table rows
    const tableRows = document.querySelectorAll('.table tbody tr');
    tableRows.forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.style.transform = 'translateX(5px)';
            this.style.boxShadow = '0 5px 15px rgba(0, 153, 255, 0.1)';
        });
        
        row.addEventListener('mouseleave', function() {
            this.style.transform = 'translateX(0)';
            this.style.boxShadow = 'none';
        });
    });
    
    // Add form validation
    const forms = document.querySelectorAll('form[method="POST"]');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (this.id === 'studentForm' || this.querySelector('#first_name')) {
                if (!validateStudentForm()) {
                    e.preventDefault();
                    showNotification('Please fill in all required fields correctly', 'error');
                }
            }
        });
    });
    
    // Add loading animation to buttons
    const submitButtons = document.querySelectorAll('button[type="submit"]');
    submitButtons.forEach(button => {
        button.addEventListener('click', function() {
            if (this.form && this.form.checkValidity()) {
                this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
                this.disabled = true;
                setTimeout(() => {
                    this.innerHTML = this.getAttribute('data-original-text') || 'Submit';
                    this.disabled = false;
                }, 3000);
            }
        });
    });
    
    // Add copy username functionality
    const usernameBadges = document.querySelectorAll('.username-badge');
    usernameBadges.forEach(badge => {
        badge.style.cursor = 'pointer';
        badge.title = 'Click to copy';
        badge.addEventListener('click', function() {
            const text = this.textContent;
            navigator.clipboard.writeText(text).then(() => {
                const originalText = this.textContent;
                this.textContent = 'Copied!';
                this.style.background = 'linear-gradient(135deg, #06d6a0, #00b894)';
                setTimeout(() => {
                    this.textContent = originalText;
                    this.style.background = 'linear-gradient(135deg, #0099ff, #66ffff)';
                }, 1500);
            });
        });
    });
    
    // Mobile menu toggle
    const menuToggle = document.createElement('button');
    menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
    menuToggle.className = 'menu-toggle';
    menuToggle.style.position = 'fixed';
    menuToggle.style.top = '15px';
    menuToggle.style.left = '15px';
    menuToggle.style.zIndex = '1001';
    menuToggle.style.background = 'linear-gradient(135deg, #0099ff, #66ffff)';
    menuToggle.style.color = 'white';
    menuToggle.style.border = 'none';
    menuToggle.style.borderRadius = '8px';
    menuToggle.style.padding = '10px 15px';
    menuToggle.style.fontSize = '1.2rem';
    menuToggle.style.display = 'none';
    menuToggle.style.cursor = 'pointer';
    menuToggle.onclick = toggleSidebar;
    
    document.body.appendChild(menuToggle);
    
    // Show/hide menu toggle based on screen size
    function checkScreenSize() {
        if (window.innerWidth <= 768) {
            menuToggle.style.display = 'block';
            document.querySelector('.sidebar').style.width = '80px';
            document.querySelector('.main').style.marginLeft = '80px';
            document.querySelectorAll('.nav-links a span').forEach(span => {
                span.style.display = 'none';
            });
            document.querySelector('.sidebar h2').style.display = 'none';
            document.querySelector('.sidebar p').style.display = 'none';
        } else {
            menuToggle.style.display = 'none';
            document.querySelector('.sidebar').style.width = '240px';
            document.querySelector('.main').style.marginLeft = '240px';
            document.querySelectorAll('.nav-links a span').forEach(span => {
                span.style.display = 'inline';
            });
            document.querySelector('.sidebar h2').style.display = 'block';
            document.querySelector('.sidebar p').style.display = 'block';
        }
    }
    
    window.addEventListener('resize', checkScreenSize);
    checkScreenSize();
    
    // Add smooth scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Add current year to footer
    const yearElements = document.querySelectorAll('.current-year');
    yearElements.forEach(element => {
        element.textContent = new Date().getFullYear();
    });
}

// Run initialization when DOM is loaded
document.addEventListener('DOMContentLoaded', initPage);

// Export functions for use in other scripts
window.SchoolMS = {
    searchStudents,
    confirmDelete,
    animateCharts,
    validateStudentForm,
    toggleSidebar,
    calculateAttendancePercentage,
    showNotification,
    formatDate,
    calculateGrade,
    initPage
};